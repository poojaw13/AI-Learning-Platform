# Adaptive Learning Platform (Final Year Project)

An intelligent E-Learning system that personalizes content difficulty based on user performance using AI.

## 🚀 Features
- **Adaptive Learning**: Dynamic Difficulty Adjustment (DDA) powered by AI.
- **AI Tutor**: Real-time chatbot for personalized assistance.
- **Gamification**: XP, Levels, and Quizzes.
- **Course Management**: Instructor Dashboard for content creation.
- **Certificates**: Automated PDF generation upon completion.

## 🛠 Tech Stack
- **Frontend**: React, TypeScript, Tailwind CSS, Vite
- **Backend**: Node.js, Express, Prisma (SQLite)
- **AI Service**: Python, FastAPI, Scikit-Learn

## 📦 Installation & Setup

### Prerequisites
- Node.js (v18+)
- Python (v3.9+)

### 1. Install Dependencies
```bash
# Root dependencies (and workspaces)
npm install

# AI Service dependencies
cd packages/ai-service
pip install -r requirements.txt
cd ../..
```

### 2. Database Setup
```bash
# Generate Prisma Client & Push Schema
cd packages/backend
npx prisma generate
npx prisma db push

# Seed Data (Test Course)
npx ts-node prisma/seed.ts
cd ../..
```

### 3. Run the Application
You can start all services (Frontend, Backend, AI) with a single command:
```bash
npm run start:all
```
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:4000
- **AI Service**: http://localhost:8000

## 🧪 Verification Steps
1. Open http://localhost:5173.
2. Click **"View Demo Course"** or **Login** with:
   - **Email**: `teacher@example.com`
   - **Password**: `password123`
3. Navigate to **"Intro to Python"**.
4. Take the **Quiz** (Lesson 2).
5. Watch your **XP** grow and **AI Recommendations** appear.
6. Chat with the **AI Bot** (Bottom Right).
7. Download your **Certificate**.
