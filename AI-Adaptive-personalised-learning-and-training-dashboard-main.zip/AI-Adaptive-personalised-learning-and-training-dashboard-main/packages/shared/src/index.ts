export interface User {
    id: string;
    email: string;
    name?: string;
    role: 'STUDENT' | 'TEACHER' | 'ADMIN';
    avatar?: string;
}

export interface AuthResponse {
    token: string;
    user: User;
}
