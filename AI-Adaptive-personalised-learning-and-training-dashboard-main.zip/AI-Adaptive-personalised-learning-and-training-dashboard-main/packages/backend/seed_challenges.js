
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const POOL_EASY = [
    { id: "101", title: "Validate Palindrome", xp: 10 },
    { id: "102", title: "Two Sum", xp: 15 },
    { id: "103", title: "Valid Parentheses", xp: 10 },
    { id: "104", title: "Climbing Stairs", xp: 15 },
    { id: "105", title: "Merge Sorted Array", xp: 15 },
    { id: "106", title: "Maximum Depth of Binary Tree", xp: 10 },
    { id: "107", title: "Best Time to Buy and Sell Stock", xp: 15 },
    { id: "108", title: "Single Number", xp: 15 },
    { id: "109", title: "Linked List Cycle", xp: 10 },
    { id: "110", title: "Invert Binary Tree", xp: 15 },
];

const POOL_MEDIUM = [
    { id: "201", title: "Merge K Sorted Lists", xp: 30 },
    { id: "202", title: "Longest Substring Without Repeating Characters", xp: 35 },
    { id: "203", title: "Maximum Subarray", xp: 25 },
    { id: "204", title: "Rotate Image", xp: 40 },
    { id: "205", title: "Group Anagrams", xp: 30 },
    { id: "206", title: "Product of Array Except Self", xp: 35 },
    { id: "207", title: "Validate Binary Search Tree", xp: 30 },
    { id: "208", title: "Number of Islands", xp: 35 },
    { id: "209", title: "Coin Change", xp: 40 },
    { id: "210", title: "Course Schedule", xp: 35 },
    { id: "211", title: "Implement Trie (Prefix Tree)", xp: 30 },
    { id: "212", title: "Kth Smallest Element in a BST", xp: 30 },
    { id: "213", title: "Daily Temperatures", xp: 25 },
    { id: "214", title: "House Robber", xp: 30 },
];

const POOL_HARD = [
    { id: "301", title: "Reverse a Binary Tree", xp: 50 },
    { id: "302", title: "LRU Cache", xp: 60 },
    { id: "303", title: "Median of Two Sorted Arrays", xp: 70 },
    { id: "304", title: "Trapping Rain Water", xp: 80 },
    { id: "305", title: "Merge k Sorted Lists", xp: 70 },
    { id: "306", title: "Regular Expression Matching", xp: 85 },
    { id: "307", title: "Largest Rectangle in Histogram", xp: 75 },
    { id: "308", title: "Edit Distance", xp: 65 },
    { id: "309", title: "Minimum Window Substring", xp: 70 },
    { id: "310", title: "Serialize and Deserialize Binary Tree", xp: 75 },
];

const ALL_CHALLENGES = [...POOL_EASY, ...POOL_MEDIUM, ...POOL_HARD];

async function main() {
    console.log(`Checking ${ALL_CHALLENGES.length} mock challenges...`);

    for (const challenge of ALL_CHALLENGES) {
        const existing = await prisma.codingChallenge.findUnique({ where: { id: challenge.id } });
        if (!existing) {
            console.log(`Creating ${challenge.id}: ${challenge.title}`);
            await prisma.codingChallenge.create({
                data: {
                    id: challenge.id,
                    title: challenge.title,
                    difficulty: challenge.id.startsWith("1") ? "Easy" : challenge.id.startsWith("2") ? "Medium" : "Hard",
                    description: `This is a placeholder description for ${challenge.title}. \n\nImplement the solution efficiently.`,
                    example: "Input: ...\nOutput: ...",
                    constraints: JSON.stringify(["n <= 1000", "Time Limit: 1s"]),
                    starterCode: JSON.stringify({
                        javascript: `// ${challenge.title}\nfunction solution(args) {\n  // Write your code here\n}`,
                        python: `# ${challenge.title}\ndef solution(args):\n    pass`,
                        cpp: `// ${challenge.title}\nclass Solution {\npublic:\n    void solve() {\n        \n    }\n};`
                    })
                }
            });
        }
    }
    console.log("Seeding complete.");
}

main()
    .catch(e => console.error(e))
    .finally(() => prisma.$disconnect());
