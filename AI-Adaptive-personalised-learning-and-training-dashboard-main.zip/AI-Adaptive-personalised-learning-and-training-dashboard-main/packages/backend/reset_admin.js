const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs'); // Assuming bcryptjs is used based on package.json

// Mocking the hashPassword logic if I can't easily import it
async function hashPassword(password) {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(password, salt);
}

const prisma = new PrismaClient();

async function reset() {
    try {
        const email = 'admin@admin.com';
        const newPassword = 'password123';
        const hashedPassword = await hashPassword(newPassword);

        await prisma.user.upsert({
            where: { email: email },
            update: { password: hashedPassword, role: 'ADMIN' },
            create: {
                email: email,
                name: 'System Admin',
                password: hashedPassword,
                role: 'ADMIN'
            }
        });

        console.log(`Successfully reset password for ${email} to ${newPassword}`);
    } catch (error) {
        console.error("Error resetting password:", error);
    } finally {
        await prisma.$disconnect();
    }
}

reset();
