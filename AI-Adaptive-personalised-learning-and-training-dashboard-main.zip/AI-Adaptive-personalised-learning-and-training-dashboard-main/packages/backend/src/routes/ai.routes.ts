
import { Router } from 'express';
import { generateLesson } from '../controllers/ai.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.post('/lesson', authenticateToken, generateLesson);

export default router;
