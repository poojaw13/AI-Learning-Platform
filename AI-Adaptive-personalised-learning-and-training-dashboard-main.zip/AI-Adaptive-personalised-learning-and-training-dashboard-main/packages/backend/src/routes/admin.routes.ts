import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticateToken, authorizeRole } from '../middleware/auth.middleware';
import { hashPassword } from '../utils/auth';

const router = Router();
const prisma = new PrismaClient();

// Authenticate all routes
router.use(authenticateToken);

// Admin Only Routes
router.get('/stats', authorizeRole(['ADMIN']), (req, res) => {
    res.json({
        health: {
            users: { label: 'Total Users', val: '24,601', color: 'text-blue-500' },
            active: { label: 'Active Today', val: '1,532', color: 'text-green-500' },
            revenue: { label: 'Certificates', val: '912', color: 'text-purple-500' },
            costs: { label: 'AI API Cost', val: '$105.20', color: 'text-red-500' }
        }
    });
});

router.get('/users', authorizeRole(['ADMIN']), async (req, res) => {
    try {
        const users = await prisma.user.findMany({
            include: {
                riskScores: {
                    orderBy: { createdAt: 'desc' },
                    take: 1
                },
                enrollments: true
            }
        });

        const formattedUsers = users.map((u: any) => {
            const avgProgress = u.enrollments.length > 0
                ? u.enrollments.reduce((acc: number, curr: any) => acc + curr.progress, 0) / u.enrollments.length
                : 0;

            const riskScore = u.riskScores[0]?.score || 0;
            let riskLabel = 'Low';
            if (riskScore > 0.8) riskLabel = 'Critical';
            else if (riskScore > 0.5) riskLabel = 'High';
            else if (riskScore > 0.3) riskLabel = 'Medium';

            return {
                id: u.id,
                name: u.name || 'Unknown',
                email: u.email,
                role: u.role,
                status: 'Active',
                risk: riskLabel,
                progress: Math.round(avgProgress),
                joined: u.createdAt.toISOString().split('T')[0]
            };
        });

        res.json(formattedUsers);
    } catch (error) {
        console.error("Failed to fetch users", error);
        res.status(500).json({ message: "Failed to fetch users" });
    }
});

router.post('/users', authorizeRole(['ADMIN']), async (req, res) => {
    try {
        const { email, password, name, role } = req.body;

        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const hashedPassword = await hashPassword(password);
        const user = await prisma.user.create({
            data: {
                email,
                password: hashedPassword,
                name,
                role: role || 'STUDENT',
            },
        });

        res.status(201).json({
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            status: 'Active',
            risk: 'Low',
            progress: 0,
            joined: user.createdAt.toISOString().split('T')[0]
        });
    } catch (error) {
        console.error("Failed to create user", error);
        res.status(500).json({ message: 'Error creating user', error });
    }
});

router.patch('/users/:id/toggle-status', authorizeRole(['ADMIN']), async (req, res) => {
    try {
        const { id } = req.params;
        // In a real app, update a status field.
        res.json({ message: 'User status updated' });
    } catch (error) {
        res.status(500).json({ message: "Failed to update status" });
    }
});

router.patch('/users/:id/reset-password', authorizeRole(['ADMIN']), async (req, res) => {
    try {
        const { id } = req.params;
        const { password } = req.body;

        if (!password) {
            return res.status(400).json({ message: "Password is required" });
        }

        const hashedPassword = await hashPassword(password);

        await prisma.user.update({
            where: { id: id },
            data: { password: hashedPassword }
        });

        res.json({ message: `Password reset successfully` });
    } catch (error) {
        console.error("Failed to reset password", error);
        res.status(500).json({ message: "Failed to reset password" });
    }
});

router.patch('/users/:id', authorizeRole(['ADMIN']), async (req, res) => {
    try {
        const { id } = req.params;
        const { name, email, role } = req.body;

        const user = await prisma.user.update({
            where: { id: id },
            data: { name, email, role }
        });

        res.json({
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            status: 'Active', // Mocked currently
        });
    } catch (error) {
        console.error("Failed to update user", error);
        res.status(500).json({ message: "Failed to update user" });
    }
});

// Shared Routes (Admin + Teacher)
router.get('/ai-status', authorizeRole(['ADMIN', 'TEACHER']), (req, res) => {
    res.json({
        models: {
            content: 'GPT-4o (Active)',
            vision: 'YOLO-v8 (Running)',
            adaptive: 'Adaptive V3'
        },
        fairness: {
            gender: 99.4,
            cultural: 97.1
        }
    });
});

export default router;
