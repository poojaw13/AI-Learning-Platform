import { Router } from 'express';
import { createExam, getExams, deleteExam, submitExam } from '../controllers/exam.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.post('/', authenticateToken, createExam);
router.post('/submit', authenticateToken, submitExam);
router.get('/', authenticateToken, getExams);
router.delete('/:id', authenticateToken, deleteExam);

export default router;
