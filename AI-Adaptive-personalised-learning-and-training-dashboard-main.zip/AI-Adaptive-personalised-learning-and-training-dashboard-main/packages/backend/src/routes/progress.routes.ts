
import { Router } from 'express';
import { updateLessonProgress, getStudentProgress } from '../controllers/progress.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.post('/lesson', authenticateToken, updateLessonProgress);
router.get('/', authenticateToken, getStudentProgress);

export default router;
