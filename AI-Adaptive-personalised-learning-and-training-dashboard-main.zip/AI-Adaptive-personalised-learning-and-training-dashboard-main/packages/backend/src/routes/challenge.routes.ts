import { Router } from 'express';
import { getChallengeById, submitChallenge, getAllChallenges } from '../controllers/challenge.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.get('/', authenticateToken, getAllChallenges);
router.get('/:id', authenticateToken, getChallengeById);
router.post('/submit', authenticateToken, submitChallenge);

export default router;
