import { Router } from 'express';
import { getRecoveryPlan, endSession, getConceptMastery, getLearningDNA, getCertReadiness } from '../controllers/student_iq.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.get('/recovery', authenticateToken, getRecoveryPlan);
router.post('/session/end', authenticateToken, endSession);
router.get('/mastery', authenticateToken, getConceptMastery);
router.get('/dna', authenticateToken, getLearningDNA);
router.get('/readiness/:courseId', authenticateToken, getCertReadiness);

export default router;
