import { Router } from 'express';
import { getTeacherClasses, getAtRiskStudents, getTeacherStudents, getCourseStudents } from '../controllers/teacher.controller';
import { getLiveSessions, createLiveSession } from '../controllers/live-session.controller';
import { authenticateToken, authorizeRole } from '../middleware/auth.middleware';

const router = Router();

// Teacher Dashboard Routes
router.get('/classes', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), getTeacherClasses);
router.get('/students', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), getTeacherStudents);
router.get('/classes/:courseId/students', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), getCourseStudents);
router.get('/students/at-risk', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), getAtRiskStudents);

export default router;
// Live Session Routes
router.get('/live-sessions', authenticateToken, getLiveSessions);
router.post('/live-sessions', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), createLiveSession);
