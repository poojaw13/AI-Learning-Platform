
import { Router } from 'express';
import { getDashboardStats, getPerformanceMetrics, getAIInsights, getAdminStats } from '../controllers/analytics.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Retrieve main dashboard stats
router.get('/dashboard', authenticateToken, getDashboardStats);

// Retrieve detailed performance metrics
router.get('/performance', authenticateToken, getPerformanceMetrics);

// Retrieve AI-generated recommendations
router.get('/insights', authenticateToken, getAIInsights);

// Retrieve Admin Dashboard main stats
router.get('/admin-stats', authenticateToken, (req, res, next) => {
    // Optional: Add admin role check middleware here
    if (req.user.role !== 'ADMIN') {
        return res.status(403).json({ message: "Access denied: Admins only" });
    }
    next();
}, getAdminStats);


export default router;
