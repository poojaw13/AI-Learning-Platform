
import { Router } from 'express';
import { getDailyChallenges } from '../controllers/assessment.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.get('/daily', authenticateToken, getDailyChallenges);

export default router;
