import { Router } from 'express';
import { getAllCourses, getCourseById, createCourse, generateAICourse, deleteCourse, submitQuiz } from '../controllers/course.controller';
import { authenticateToken, authorizeRole, authenticateOptional } from '../middleware/auth.middleware';

const router = Router();

// Public routes (or arguably protected, keeping public for now for browsing)
router.get('/', authenticateOptional, getAllCourses);
router.get('/:id', getCourseById);

// Protected routes
router.post('/', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), createCourse);
router.post('/generate-ai', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), generateAICourse);
router.delete('/:id', authenticateToken, authorizeRole(['TEACHER', 'ADMIN']), deleteCourse);

import { getCertificate } from '../controllers/certificate.controller';
import { chat, analyzeEmotion } from '../controllers/course.controller';

// Student routes
router.post('/quiz', authenticateToken, submitQuiz);
router.get('/:courseId/certificate', authenticateToken, getCertificate);
router.post('/chat', authenticateToken, chat);
router.post('/emotion', authenticateToken, analyzeEmotion);

export default router;
