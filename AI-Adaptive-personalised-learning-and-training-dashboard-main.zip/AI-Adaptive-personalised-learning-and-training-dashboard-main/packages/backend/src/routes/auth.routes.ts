import { Router } from 'express';
import { register, login, getMe, getLeaderboard, socialLogin } from '../controllers/auth.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.post('/register', register);
router.post('/login', login);
router.post('/social', socialLogin);
router.get('/me', authenticateToken, getMe);
router.get('/leaderboard', authenticateToken, getLeaderboard);

// ... no changes here
export default router;
