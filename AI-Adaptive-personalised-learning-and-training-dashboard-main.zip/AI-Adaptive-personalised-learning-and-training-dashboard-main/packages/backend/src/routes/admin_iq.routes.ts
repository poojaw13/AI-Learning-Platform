import { Router } from 'express';
import { getAdminRecoveryStats, getDropoutRiskMatrix, getBottlenecks, getDNAAggregates, generateReport } from '../controllers/admin_iq.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Middleware to ensure staff access (Admin or Teacher)
const isStaff = (req: any, res: any, next: any) => {
    if (req.user.role !== 'ADMIN' && req.user.role !== 'TEACHER') {
        return res.status(403).json({ message: "Staff access required" });
    }
    next();
};

router.get('/recovery-stats', authenticateToken, isStaff, getAdminRecoveryStats);
router.get('/risk-matrix', authenticateToken, isStaff, getDropoutRiskMatrix);
router.get('/bottlenecks', authenticateToken, isStaff, getBottlenecks);
router.get('/dna-aggregates', authenticateToken, isStaff, getDNAAggregates);
router.post('/generate-report', authenticateToken, isStaff, generateReport);

export default router;
