import { Router } from 'express';
import { getAchievements } from '../controllers/gamification.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

router.get('/achievements', authenticateToken, getAchievements);

export default router;
