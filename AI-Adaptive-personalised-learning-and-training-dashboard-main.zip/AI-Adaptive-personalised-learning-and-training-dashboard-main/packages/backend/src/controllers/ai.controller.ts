
import { Request, Response } from 'express';
import { generateLessonContent } from '../services/mock-ai.service';

export const generateLesson = async (req: Request, res: Response) => {
    try {
        const { topic, level } = req.body;

        if (!topic || !level) {
            return res.status(400).json({ message: "Topic and Level are required" });
        }

        const content = await generateLessonContent(topic, level);

        res.json({
            content,
            meta: {
                model: "Adaptive-GPT-Education-V1",
                generatedAt: new Date(),
                tokens: content.length / 4 // Approx
            }
        });
    } catch (error) {
        console.error("AI Generation Error:", error);
        res.status(500).json({ message: "Failed to generate content" });
    }
};
