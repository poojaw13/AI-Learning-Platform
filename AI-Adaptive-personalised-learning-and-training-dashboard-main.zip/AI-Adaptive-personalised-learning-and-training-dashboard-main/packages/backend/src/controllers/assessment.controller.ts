
import { Request, Response } from 'express';

// Expanded "AI-Generated" Pool
const POOL_EASY = [
    { id: 101, title: "Validate Palindrome", xp: 10 },
    { id: 102, title: "Two Sum", xp: 15 },
    { id: 103, title: "Valid Parentheses", xp: 10 },
    { id: 104, title: "Climbing Stairs", xp: 15 },
    { id: 105, title: "Merge Sorted Array", xp: 15 },
    { id: 106, title: "Maximum Depth of Binary Tree", xp: 10 },
    { id: 107, title: "Best Time to Buy and Sell Stock", xp: 15 },
    { id: 108, title: "Single Number", xp: 15 },
    { id: 109, title: "Linked List Cycle", xp: 10 },
    { id: 110, title: "Invert Binary Tree", xp: 15 },
];

const POOL_MEDIUM = [
    { id: 201, title: "Merge K Sorted Lists", xp: 30 }, // Note: Often Hard, but kept for legacy
    { id: 202, title: "Longest Substring Without Repeating Characters", xp: 35 },
    { id: 203, title: "Maximum Subarray", xp: 25 },
    { id: 204, title: "Rotate Image", xp: 40 },
    { id: 205, title: "Group Anagrams", xp: 30 },
    { id: 206, title: "Product of Array Except Self", xp: 35 },
    { id: 207, title: "Validate Binary Search Tree", xp: 30 },
    { id: 208, title: "Number of Islands", xp: 35 },
    { id: 209, title: "Coin Change", xp: 40 },
    { id: 210, title: "Course Schedule", xp: 35 },
    { id: 211, title: "Implement Trie (Prefix Tree)", xp: 30 },
    { id: 212, title: "Kth Smallest Element in a BST", xp: 30 },
    { id: 213, title: "Daily Temperatures", xp: 25 },
    { id: 214, title: "House Robber", xp: 30 },
];

const POOL_HARD = [
    { id: 301, title: "Reverse a Binary Tree", xp: 50 }, // Legacy Hard
    { id: 302, title: "LRU Cache", xp: 60 },
    { id: 303, title: "Median of Two Sorted Arrays", xp: 70 },
    { id: 304, title: "Trapping Rain Water", xp: 80 },
    { id: 305, title: "Merge k Sorted Lists", xp: 70 },
    { id: 306, title: "Regular Expression Matching", xp: 85 },
    { id: 307, title: "Largest Rectangle in Histogram", xp: 75 },
    { id: 308, title: "Edit Distance", xp: 65 },
    { id: 309, title: "Minimum Window Substring", xp: 70 },
    { id: 310, title: "Serialize and Deserialize Binary Tree", xp: 75 },
];

export const getDailyChallenges = async (req: Request, res: Response) => {
    // 1. Generate a deterministic seed for "Today"
    // We use a string hash of the date so effectively it updates every 24h at midnight.
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const seed = today.split('-').reduce((acc, part) => acc + parseInt(part), 0);

    // 2. Helper to pick index consistently based on seed
    const pick = (arr: any[], offset: number) => arr[(seed + offset) % arr.length];

    // 3. Select: 1 Easy, 2 Medium, 1 Hard
    const dailyChallenges = [
        pick(POOL_EASY, 1),
        pick(POOL_MEDIUM, 2),
        pick(POOL_MEDIUM, 5), // Different offset for 2nd medium
        pick(POOL_HARD, 3),
    ].map(c => ({
        id: c.id,
        title: c.title,
        xp: c.xp,
        difficulty: POOL_EASY.includes(c) ? 'Easy' : POOL_MEDIUM.includes(c) ? 'Medium' : 'Hard'
    }));

    // 4. Return with AI meta-data
    res.json({
        challenges: dailyChallenges,
        meta: {
            refreshedAt: new Date().toISOString(),
            engine: "Adaptive-Neural-Network-V4",
            logic: "1 Easy, 2 Medium, 1 Hard"
        }
    });
};
