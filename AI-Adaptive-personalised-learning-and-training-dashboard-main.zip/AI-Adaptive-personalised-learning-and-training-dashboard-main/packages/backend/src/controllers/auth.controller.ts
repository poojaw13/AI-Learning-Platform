import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { generateToken, hashPassword, comparePassword } from '../utils/auth';

const prisma = new PrismaClient();

export const register = async (req: Request, res: Response) => {
    try {
        const { email, password, name, role } = req.body;

        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const hashedPassword = await hashPassword(password);
        const user = await prisma.user.create({
            data: {
                email,
                password: hashedPassword,
                name,
                bio: req.body.bio,
                department: req.body.department,
                role: role || 'STUDENT',
            },
        });

        const token = generateToken(user.id, user.role);
        res.status(201).json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
    } catch (error) {
        res.status(500).json({ message: 'Error registering user', error });
    }
};

export const login = async (req: Request, res: Response) => {
    try {
        const { email, password } = req.body;

        const user = await prisma.user.findUnique({ where: { email } });
        if (!user || !user.password) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const isValid = await comparePassword(password, user.password);
        if (!isValid) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const token = generateToken(user.id, user.role);

        // Streak Logic
        const now = new Date();
        const lastLogin = user.lastLogin ? new Date(user.lastLogin) : null;
        let streak = user.streak || 0;

        if (lastLogin) {
            const diffTime = Math.abs(now.getTime() - lastLogin.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

            if (diffDays === 1) {
                // Logged in next day, increment
                streak += 1;
            } else if (diffDays > 1) {
                // Missed a day, reset
                streak = 1;
            }
            // If diffDays == 0 (same day), do nothing
        } else {
            streak = 1;
        }

        // Update User
        await prisma.user.update({
            where: { id: user.id },
            data: { lastLogin: now, streak }
        });

        res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role, streak } });
    } catch (error) {
        res.status(500).json({ message: 'Error logging in', error });
    }
};

export const getMe = async (req: Request, res: Response) => {
    try {
        const userId = req.user?.userId;
        const user = await prisma.user.findUnique({
            where: { id: userId },
            include: { profile: true } // Include detailed profile if needed
        });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Exclude password from response
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching user', error });
    }
};

export const getLeaderboard = async (req: Request, res: Response) => {
    try {
        const users = await prisma.user.findMany({
            where: { role: 'STUDENT' }, // Only students
            orderBy: { xp: 'desc' },
            take: 10,
            select: {
                id: true,
                name: true,
                xp: true,
                level: true,
                streak: true,
                avatar: true
            }
        });
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching leaderboard', error });
    }
};

export const socialLogin = async (req: Request, res: Response) => {
    try {
        const { provider } = req.body; // 'google' or 'github'

        let email = '';
        let name = '';
        const role = 'STUDENT';

        if (provider === 'google') {
            email = req.body.email || 'google_user@adaptivelearn.com';
            name = req.body.name || 'Google Student';
        } else if (provider === 'github') {
            email = req.body.email || 'github_dev@adaptivelearn.com';
            name = req.body.name || 'GitHub Developer';
        } else {
            return res.status(400).json({ message: 'Invalid provider' });
        }

        // Check if user exists, if not create
        let user = await prisma.user.findUnique({ where: { email } });

        if (!user) {
            // Create new social user with random password (since they login via social)
            const hashedPassword = await hashPassword(Math.random().toString(36).slice(-8));

            user = await prisma.user.create({
                data: {
                    email,
                    password: hashedPassword,
                    name,
                    role,
                    // Optionally set an avatar or provider flag if schema supported it
                },
            });
        }

        // Generate Token
        const token = generateToken(user.id, user.role);

        // Update Login Stats
        await prisma.user.update({
            where: { id: user.id },
            data: { lastLogin: new Date(), streak: (user.streak || 0) + 1 } // Simple increment for demo
        });

        // Return same structure as normal login
        res.json({
            token,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
                streak: user.streak
            }
        });

    } catch (error) {
        console.error("Social login error:", error);
        res.status(500).json({ message: 'Social login failed', error });
    }
};
