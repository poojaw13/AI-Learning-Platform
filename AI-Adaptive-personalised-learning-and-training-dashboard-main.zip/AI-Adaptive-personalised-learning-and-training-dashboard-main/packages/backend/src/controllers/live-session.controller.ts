import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const getLiveSessions = async (req: Request, res: Response) => {
    try {

        const sessions = await prisma.liveClassSession.findMany({
            orderBy: { startTime: 'asc' },
            include: {
                instructor: {
                    select: { name: true, avatar: true }
                }
            }
        });

        // Format for frontend
        const formatted = sessions.map((s: any) => ({
            id: s.id,
            title: s.title || 'Untitled',
            startTime: s.startTime ? new Date(s.startTime).toLocaleString('en-US', { weekday: 'short', hour: 'numeric', minute: '2-digit' }) : 'TBD',
            duration: `${s.duration || 60} min`,
            class: s.classId || 'General',
            instructor: s.instructor?.name || 'Unknown'
        }));

        res.json(formatted);
    } catch (error) {
        console.error("Error fetching live sessions:", error);
        res.status(500).json({ message: "Failed to fetch live sessions" });
    }
};

export const createLiveSession = async (req: Request, res: Response) => {
    try {
        const { title, classId, startTime, duration } = req.body;
        const instructorId = (req as any).user?.id || (req as any).user?.userId;

        if (!instructorId) return res.status(401).json({ message: "Unauthorized" });

        // Parse "Today, 5 PM" logic or expect ISO string?
        // For simplicity in this demo, let's assume the frontend sends a clearer format or we parse it.
        // But since the frontend sends "Today, 5 PM", we need to robustly parse it or change frontend.
        // Let's assume frontend sends a valid ISO string or we parse it here.
        // Actually, the current frontend input is free text.
        // We will simple try to parse widely, or default to now if fail.

        // Parse date - simpler approach for now
        let parsedDate = new Date();
        if (startTime && !startTime.includes('Today')) {
            parsedDate = new Date(startTime);
        }
        console.log("createLiveSession parsedDate:", parsedDate);

        // REVISION: The frontend `newSession.time` is just text.
        // To make this robust without changing too much frontend UI logic yet:
        // We'll update the frontend to use a datetime-local input.


        const session = await prisma.liveClassSession.create({
            data: {
                title,
                classId,
                startTime: parsedDate,
                duration: parseInt(duration),
                instructorId
            }
        });

        res.json(session);
    } catch (error) {
        console.error("Error creating live session:", error);
        res.status(500).json({ message: "Failed to create session" });
    }
};
