import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Create a new Exam
export const createExam = async (req: Request, res: Response) => {
    try {
        const { title, type, duration, passingScore, description, questions } = req.body;

        if (!title || !type || !duration) {
            return res.status(400).json({ message: "Missing required fields" });
        }

        const exam = await prisma.exam.create({
            data: {
                title,
                type,
                duration: parseInt(duration),
                passingScore: parseInt(passingScore),
                description,
                questions: JSON.stringify(questions),
                status: 'ACTIVE'
            }
        });

        res.status(201).json(exam);
    } catch (error) {
        console.error("Error creating exam:", error);
        res.status(500).json({ message: "Failed to create exam" });
    }
};

// Get all Exams
export const getExams = async (req: Request, res: Response) => {
    try {
        const exams = await prisma.exam.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                _count: {
                    select: { results: true }
                }
            }
        });

        // Calculate pass rate dynamically for now
        const examsWithStats = await Promise.all(exams.map(async (exam) => {
            const results = await prisma.examResult.findMany({ where: { examId: exam.id } });
            const passed = results.filter(r => (r.score || 0) >= exam.passingScore).length;
            const passRate = results.length > 0 ? Math.round((passed / results.length) * 100) : 0;

            return {
                ...exam,
                candidates: results.length,
                passRate
            };
        }));

        res.json(examsWithStats);
    } catch (error) {
        console.error("Error fetching exams:", error);
        res.status(500).json({ message: "Failed to fetch exams" });
    }
};

// Delete Exam
export const deleteExam = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        await prisma.exam.delete({ where: { id } });
        res.json({ message: "Exam deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: "Failed to delete exam" });
    }
};

// Submit Exam Result
export const submitExam = async (req: Request, res: Response) => {
    try {
        const { examId, score, answers } = req.body;
        const userId = req.user.userId;

        const result = await prisma.examResult.create({
            data: {
                userId,
                examId,
                score,
                status: 'SUBMITTED',
                answers: JSON.stringify(answers),
                submittedAt: new Date()
            }
        });

        // Award XP? (Optional, matching Quiz logic)
        // For now just save result.

        res.status(201).json(result);
    } catch (error) {
        console.error("Error submitting exam:", error);
        res.status(500).json({ message: "Failed to submit exam" });
    }
};
