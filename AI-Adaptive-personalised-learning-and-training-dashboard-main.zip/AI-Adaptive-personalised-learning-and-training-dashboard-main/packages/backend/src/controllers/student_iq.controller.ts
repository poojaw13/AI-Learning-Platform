import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// 1. Smart Inactivity Recovery
export const getRecoveryPlan = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user.userId;
        const user = await prisma.user.findUnique({ where: { id: userId } });

        if (!user || !user.lastLogin) return res.status(404).json({ message: "User not found" });

        const daysInactive = Math.floor((Date.now() - new Date(user.lastLogin).getTime()) / (1000 * 60 * 60 * 24));

        if (daysInactive < 7) {
            return res.json({ active: false, message: "User is active" });
        }

        // Mock AI Plan Generation
        const plan = {
            active: true,
            daysInactive,
            title: "Welcome Back Comeback Plan",
            difficultyAdjustment: "Reduced by 20%",
            recommendations: [
                "Review 'Intro to Variables' (Quick Recap)",
                "Complete 5-minute Focus Session",
                "Unlock 'Basics' Achievement"
            ],
            motivation: "You've been missed! We've lightened the load to help you get back in the flow."
        };

        res.json(plan);
    } catch (error) {
        res.status(500).json({ message: "Error generating recovery plan" });
    }
};

// 2. Learning Session Quality Score
export const endSession = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user.userId;
        const { courseId, duration, focusScore, accuracyScore, engagementScore } = req.body;

        const qualityScore = Math.round((focusScore + accuracyScore + engagementScore) / 3);

        const session = await prisma.learningSession.create({
            data: {
                userId,
                courseId,
                duration,
                focusScore,
                accuracyScore,
                engagementScore,
                qualityScore,
                endTime: new Date()
            }
        });

        // Update Learning DNA based on focus
        const dna = await prisma.learningDNA.upsert({
            where: { userId },
            update: { averageFocus: focusScore },
            create: {
                userId,
                style: "Visual",
                bestTime: new Date().getHours() > 18 ? "Night" : "Morning",
                averageFocus: focusScore
            }
        });

        res.json({ session, dna });
    } catch (error) {
        console.error("Error ending session:", error);
        res.status(500).json({ message: "Error ending session" });
    }
};

// 3. Concept-Level Mastery
export const getConceptMastery = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user.userId;
        let mastery = await prisma.conceptMastery.findMany({
            where: { userId }
        });

        // If no mastery data exists, create demo data for new students
        if (mastery.length === 0) {
            const demoMastery = [
                { concept: "React Basics", score: 0.75 },
                { concept: "State Management", score: 0.60 },
                { concept: "TypeScript", score: 0.85 },
                { concept: "API Integration", score: 0.70 },
                { concept: "UI/UX Design", score: 0.55 }
            ];

            // Create demo mastery records
            for (const item of demoMastery) {
                await prisma.conceptMastery.create({
                    data: {
                        userId,
                        concept: item.concept,
                        score: item.score
                    }
                });
            }

            mastery = await prisma.conceptMastery.findMany({
                where: { userId }
            });
        }

        res.json(mastery);
    } catch (error) {
        console.error("Error fetching mastery:", error);
        res.status(500).json({ message: "Error fetching mastery" });
    }
};

// 4. Learning DNA
export const getLearningDNA = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user.userId;
        let dna = await prisma.learningDNA.findUnique({ where: { userId } });
        
        // If no DNA exists, create default profile
        if (!dna) {
            dna = await prisma.learningDNA.create({
                data: {
                    userId,
                    style: "Balanced",
                    bestTime: "Night",
                    averageFocus: 0
                }
            });
        }

        res.json(dna);
    } catch (error) {
        console.error("Error fetching DNA:", error);
        res.status(500).json({ message: "Error fetching DNA" });
    }
};

// 5. Certification Readiness
export const getCertReadiness = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user.userId;
        const { courseId } = req.params;

        // Simple logic: weighted average of progress and quiz scores
        const enrollment = await prisma.enrollment.findUnique({
            where: { userId_courseId: { userId, courseId } }
        });

        if (!enrollment) return res.status(404).json({ message: "Enrollment not found" });

        const score = Math.round(enrollment.progress * 0.8); // Simple mock
        const status = score > 80 ? "READY" : "NOT_READY";

        res.json({ score, status });
    } catch (error) {
        res.status(500).json({ message: "Error fetching readiness" });
    }
};
