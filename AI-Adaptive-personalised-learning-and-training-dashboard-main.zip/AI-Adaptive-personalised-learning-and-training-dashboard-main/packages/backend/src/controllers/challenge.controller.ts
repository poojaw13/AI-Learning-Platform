import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Get Challenge by ID
export const getChallengeById = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const challenge = await prisma.codingChallenge.findUnique({
            where: { id }
        });

        if (!challenge) {
            return res.status(404).json({ message: "Challenge not found" });
        }

        // Parse JSON strings back to objects
        const parsedChallenge = {
            ...challenge,
            constraints: challenge.constraints ? JSON.parse(challenge.constraints) : [],
            starterCode: challenge.starterCode ? JSON.parse(challenge.starterCode) : {}
        };

        res.json(parsedChallenge);
    } catch (error) {
        console.error("Error fetching challenge:", error);
        res.status(500).json({ message: "Failed to fetch challenge" });
    }
};

// Submit Challenge Solution
export const submitChallenge = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user.id;
        const { challengeId, code, language } = req.body;

        // Mock Evaluation Logic (replace with real runner later)
        // For now, if code length > 20, we assume it passed simply to unblock the UI flow
        const passed = code.length > 20;
        const status = passed ? "PASSED" : "FAILED";
        const output = passed
            ? "Test Case 1: Passed ✅\nTest Case 2: Passed ✅"
            : "Test Case 1: Failed ❌\nSyntax Error: Unexpected token";

        const submission = await prisma.challengeSubmission.create({
            data: {
                userId,
                challengeId,
                code,
                language,
                status,
                output
            }
        });

        // Award XP if passed (and not already passed?)
        if (passed) {
            await prisma.user.update({
                where: { id: userId },
                data: { xp: { increment: 50 } }
            });
        }

        res.json({
            submission,
            message: passed ? "Solution Submitted! +50 XP" : "Solution Failed",
            output
        });

    } catch (error) {
        console.error("Error submitting challenge:", error);
        res.status(500).json({ message: "Failed to submit solution" });
    }
};

// Get All Challenges (for list view if needed)
export const getAllChallenges = async (req: Request, res: Response) => {
    try {
        const challenges = await prisma.codingChallenge.findMany({
            select: {
                id: true,
                title: true,
                difficulty: true
            }
        });
        res.json(challenges);
    } catch (error) {
        res.status(500).json({ message: "Failed to fetch challenges" });
    }
};
