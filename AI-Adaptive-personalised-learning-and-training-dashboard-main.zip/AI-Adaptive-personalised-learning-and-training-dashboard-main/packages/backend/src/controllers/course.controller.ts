import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import fs from 'fs';

const prisma = new PrismaClient();

export const getAllCourses = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.userId; // Ensure auth middleware attaches this

        const courses = await (prisma as any).course.findMany({
            include: {
                modules: {
                    include: { lessons: true }
                }
            },
        });

        // 2. Fetch User's real progress from Enrollment table
        const enrollments = userId ? await (prisma as any).enrollment.findMany({
            where: { userId }
        }) : [];

        const progressMap = new Map();
        enrollments.forEach((e: any) => {
            progressMap.set(e.courseId, e.progress);
        });

        const coursesWithProgress = courses.map((course: any) => {
            const totalLessons = course.modules.reduce((acc: number, m: any) => acc + m.lessons.length, 0);
            // Use real progress from DB, default to 0
            const realProgress = progressMap.get(course.id) || 0;

            return {
                ...course,
                progress: realProgress,
                duration: `${Math.max(2, Math.ceil(totalLessons * 0.5))}h` // Estimate 30m per lesson
            };
        });

        res.json(coursesWithProgress);
    } catch (error) {
        console.error("Course fetch error:", error);
        res.status(500).json({ message: 'Error fetching courses', error });
    }
};

export const getCourseById = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const course = await (prisma as any).course.findUnique({
            where: { id },
            include: {
                modules: {
                    include: { lessons: true }
                },
                exams: true
            }
        });
        if (!course) {
            return res.status(404).json({ message: 'Course not found' });
        }
        res.json(course);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching course', error });
    }
};


import { generateAICourse as callAICourseGen } from '../services/ai.service';

export const generateAICourse = async (req: Request, res: Response) => {
    try {
        const { topic, description } = req.body;
        const instructorId = (req as any).user.userId;

        if (!topic) return res.status(400).json({ message: "Topic is required" });

        // 1. Call AI Service
        const courseData = await callAICourseGen(topic, description || "");
        if (!courseData) return res.status(500).json({ message: "AI Generation failed" });

        // 2. Persist in DB using a Transaction
        const course = await (prisma as any).$transaction(async (tx: any) => {
            const newCourse = await tx.course.create({
                data: {
                    title: courseData.title,
                    description: courseData.description,
                    instructorId,
                    modules: {
                        create: courseData.modules.map((m: any, mIdx: number) => ({
                            title: m.title || "Untitled Module",
                            order: mIdx,
                            lessons: {
                                create: (m.lessons || []).map((l: any, lIdx: number) => ({
                                    title: l.title || "Untitled Lesson",
                                    content: l.content || "No content provided",
                                    type: l.type || "text",
                                    order: lIdx
                                }))
                            }
                        }))
                    }
                },
                include: {
                    modules: {
                        include: { lessons: true }
                    }
                }
            });
            if (courseData.finalExam) {
                await tx.exam.create({
                    data: {
                        title: courseData.finalExam.title || "Final Exam",
                        description: `Final assessment for ${newCourse.title}`,
                        type: "MCQ",
                        duration: 60,
                        passingScore: courseData.finalExam.passingScore || 70,
                        status: "ACTIVE",
                        questions: JSON.stringify(courseData.finalExam.questions),
                        courseId: newCourse.id
                    }
                });
            }

            // Refetch with exams
            return await tx.course.findUnique({
                where: { id: newCourse.id },
                include: {
                    modules: {
                        include: { lessons: true }
                    },
                    exams: true
                }
            });
        });

        res.status(201).json(course);
    } catch (error) {
        console.error("!!!!!!! AI Course Creation Error !!!!!!!", error);
        console.log("CWD:", process.cwd());
        try {
            fs.writeFileSync('d:/adaptive-learning/packages/backend/ai_gen_error.log', JSON.stringify(error, Object.getOwnPropertyNames(error), 2));
        } catch (fileErr) {
            console.error("Failed to write log file:", fileErr);
        }
        res.status(500).json({ message: "Failed to create AI course", error });
    }
};

export const createCourse = async (req: Request, res: Response) => {

    try {
        const { title, description, thumbnail } = req.body;
        const instructorId = (req as any).user.userId; // user is attached by auth middleware

        const course = await (prisma as any).course.create({
            data: {
                title,
                description,
                thumbnail,
                instructorId,
            },
        });
        res.status(201).json(course);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating course', error });
    }
};

export const deleteCourse = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const instructorId = (req as any).user.userId;

        // Verify course exists
        const course = await (prisma as any).course.findUnique({ where: { id } });
        if (!course) return res.status(404).json({ message: "Course not found" });

        // Authorization: Instructor or Admin
        if (course.instructorId !== instructorId && (req as any).user.role !== 'ADMIN') {
            return res.status(403).json({ message: "Not authorized to delete this course" });
        }

        // Manual cascading delete to ensure it works even if schema trigger is not active
        await (prisma as any).$transaction(async (tx: any) => {
            // 1. Delete Enrollments
            await tx.enrollment.deleteMany({ where: { courseId: id } });

            // 2. Delete Exams and Exam Results
            const exams = await tx.exam.findMany({ where: { courseId: id } });
            const examIds = exams.map((e: any) => e.id);
            if (examIds.length > 0) {
                await tx.examResult.deleteMany({ where: { examId: { in: examIds } } });
                await tx.exam.deleteMany({ where: { courseId: id } });
            }

            // 3. Delete Modules, Lessons, and Lesson Progress
            const modules = await tx.module.findMany({ where: { courseId: id } });
            const moduleIds = modules.map((m: any) => m.id);
            if (moduleIds.length > 0) {
                const lessons = await tx.lesson.findMany({ where: { moduleId: { in: moduleIds } } });
                const lessonIds = lessons.map((l: any) => l.id);
                if (lessonIds.length > 0) {
                    await tx.lessonProgress.deleteMany({ where: { lessonId: { in: lessonIds } } });
                    await tx.quizResult.deleteMany({ where: { lessonId: { in: lessonIds } } });
                    await tx.lesson.deleteMany({ where: { moduleId: { in: moduleIds } } });
                }
                await tx.module.deleteMany({ where: { courseId: id } });
            }

            // 4. Finally delete the course
            await tx.course.delete({ where: { id } });
        });

        res.json({ message: "Course and all related data deleted successfully" });
    } catch (error) {
        console.error("Delete course error:", error);
        res.status(500).json({ message: 'Error deleting course', error });
    }
}

import { analyzeQuizResult } from '../services/ai.service';

export const submitQuiz = async (req: Request, res: Response) => {
    try {
        const { lessonId, score, totalQuestions, wrongAnswers, topic } = req.body;
        const userId = req.user.userId;

        // 1. Save Quiz Result
        const result = await prisma.quizResult.create({
            data: {
                userId,
                lessonId,
                score
            }
        });

        // 2. Analyze with AI
        const analysis = await analyzeQuizResult({
            userId,
            topic: topic || 'General',
            score,
            totalQuestions,
            wrongAnswers: wrongAnswers || []
        });

        // 3. Update Profile if analysis successful
        if (analysis) {
            await prisma.dDAProfile.upsert({
                where: { userId },
                create: {
                    userId,
                    currentDifficulty: analysis.recommendedDifficulty,
                    skillData: JSON.stringify(analysis.weaknesses)
                },
                update: {
                    currentDifficulty: analysis.recommendedDifficulty,
                    skillData: JSON.stringify(analysis.weaknesses)
                }
            });
        }

        // 4. Gamification: Award XP
        const xpEarned = score * 10;
        const user = await prisma.user.findUnique({ where: { id: userId } });

        if (user) {
            const newXp = (user.xp || 0) + xpEarned;
            const newLevel = Math.floor(newXp / 1000) + 1;

            await prisma.user.update({
                where: { id: userId },
                data: {
                    xp: newXp,
                    level: newLevel
                }
            });
        }

        // 5. Update Lesson Completion and Course Progress if passing score (e.g. >= 60%)
        if (score >= 60) {
            // Find which course this lesson belongs to
            const lesson = await prisma.lesson.findUnique({
                where: { id: lessonId },
                include: { module: true }
            });

            if (lesson) {
                const courseId = lesson.module.courseId;

                // Mark Lesson as Completed
                await prisma.lessonProgress.upsert({
                    where: { userId_lessonId: { userId, lessonId } },
                    update: { completed: true },
                    create: { userId, lessonId, completed: true }
                });

                // Recalculate Course Progress
                const course = await prisma.course.findUnique({
                    where: { id: courseId },
                    include: { modules: { include: { lessons: true } } }
                });

                if (course) {
                    const totalLessons = course.modules.reduce((acc, m) => acc + m.lessons.length, 0);
                    const completedCount = await prisma.lessonProgress.count({
                        where: {
                            userId,
                            completed: true,
                            lesson: { module: { courseId } }
                        }
                    });

                    const progressPercent = totalLessons > 0 ? (completedCount / totalLessons) * 100 : 0;

                    await prisma.enrollment.upsert({
                        where: {
                            userId_courseId: {
                                userId,
                                courseId
                            }
                        },
                        update: { progress: progressPercent },
                        create: {
                            userId,
                            courseId,
                            progress: progressPercent
                        }
                    });
                }
            }
        }

        res.json({ result, analysis });
    } catch (error) {
        console.error("Quiz submission error", error);
        res.status(500).json({ message: 'Error submitting quiz', error });
    }
};

import { chatWithTutor } from '../services/ai.service';

export const chat = async (req: Request, res: Response) => {
    try {
        const { message, context } = req.body;
        const reply = await chatWithTutor({ message, context });
        res.json(reply || { reply: "AI Service Unavailable" });
    } catch (error) {
        res.status(500).json({ message: 'Error in chat', error });
    }
};

import axios from 'axios';
const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

export const analyzeEmotion = async (req: Request, res: Response) => {
    try {
        const { image } = req.body; // Base64 image
        // Proxy to AI Service
        try {
            const { data } = await axios.post(`${AI_SERVICE_URL}/analyze-emotion`, { image });
            res.json(data);
        } catch (err) {
            // Fallback mock if AI service emotion endpoint fails (e.g. old version running)
            console.warn("AI Service emotion analysis failed, using fallback.", err);
            res.json({ emotion: "Focused", confidence: 0.95, mock: true });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error analyzing emotion', error });
    }
};
