import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import axios from 'axios';

const prisma = new PrismaClient();

// 1. Inactive Students Panel & Recovery Success
export const getAdminRecoveryStats = async (req: Request, res: Response) => {
    try {
        const threshold = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const inactiveCount = await prisma.user.count({
            where: {
                role: "STUDENT",
                OR: [
                    { lastLogin: { lt: threshold } },
                    { lastLogin: null }
                ]
            }
        });

        res.json({
            inactiveCount,
            recoverySuccessRate: await calculateRecoverySuccessRate(),
            activeComebackPlans: await prisma.notification.count({ where: { type: 'RECOVERY' } })
        });
    } catch (error) {
        res.status(500).json({ message: "Error fetching recovery stats" });
    }
};

async function calculateRecoverySuccessRate() {
    const totalRecovered = await prisma.user.count({
        where: {
            role: 'STUDENT',
            lastLogin: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
            streak: { gt: 1 }
        }
    });
    // Arbitrary base for now, can be refined to 'previously inactive users'
    const totalInactive = await prisma.user.count({
        where: { role: 'STUDENT', lastLogin: { lt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } }
    });
    return totalInactive > 0 ? Math.round((totalRecovered / (totalInactive + totalRecovered)) * 100) : 100;
}

// 2. Dropout Risk Heatmap (Aggregated)
export const getDropoutRiskMatrix = async (req: Request, res: Response) => {
    try {
        const risks = await (prisma as any).riskScore.findMany({
            orderBy: { createdAt: 'desc' },
            take: 100,
            include: { user: { select: { name: true, department: true } } }
        });


        const highRisk = risks.filter((r: any) => r.score >= 0.7).length;
        const mediumRisk = risks.filter((r: any) => r.score >= 0.4 && r.score < 0.7).length;
        const lowRisk = risks.filter((r: any) => r.score < 0.4).length;

        // If no data, return zeros but structure is valid
        res.json({
            highRisk,
            mediumRisk,
            lowRisk,
            recentRisks: risks.slice(0, 5)
        });
    } catch (error) {
        res.status(500).json({ message: "Error fetching risk matrix" });
    }
};

// 3. Learning Bottleneck Detector
export const getBottlenecks = async (req: Request, res: Response) => {
    try {
        const bottlenecks = await (prisma as any).bottleneckPoint.findMany({
            orderBy: { dropped: 'desc' },
            take: 10
        });
        res.json(bottlenecks);
    } catch (error) {
        res.status(500).json({ message: "Error fetching bottlenecks" });
    }
};

// 4. Learning DNA Aggregates
export const getDNAAggregates = async (req: Request, res: Response) => {
    try {
        const dnas = await (prisma as any).learningDNA.findMany();

        const styleCounts = dnas.reduce((acc: any, curr: any) => {
            acc[curr.style] = (acc[curr.style] || 0) + 1;
            return acc;
        }, {});

        res.json({
            styles: styleCounts,
            avgFocus: Math.round(dnas.reduce((a: number, b: any) => a + b.averageFocus, 0) / (dnas.length || 1))
        });
    } catch (error) {
        res.status(500).json({ message: "Error fetching DNA aggregates" });
    }
};

// 5. Generate Monthly Learning Impact Report (PDF)
export const generateReport = async (req: Request, res: Response) => {
    try {
        const { userId } = req.body;
        const user = await prisma.user.findUnique({ where: { id: userId } });

        if (!user) return res.status(404).json({ message: "User not found" });

        // Forward to Python AI service

        const aiServiceUrl = process.env.AI_SERVICE_URL || 'http://localhost:8000';

        const { data } = await axios.post(`${aiServiceUrl}/generate-report`, {
            name: user.name,
            email: user.email,
            xp: user.xp,
            level: user.level
        });

        // Store record in FeedbackReport (conceptually)
        await (prisma as any).feedbackReport.create({
            data: {
                userId,
                content: `AI Impact Report Generated: ${data.report_url}`,
                plan: JSON.stringify({ filename: data.filename })
            }
        });

        res.json(data);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error triggering AI report generation" });
    }
};
