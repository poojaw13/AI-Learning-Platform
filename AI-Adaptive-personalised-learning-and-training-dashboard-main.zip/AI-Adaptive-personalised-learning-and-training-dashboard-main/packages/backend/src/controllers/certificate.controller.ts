import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { generateCertificate } from '../services/certificate.service';

const prisma = new PrismaClient();

export const getCertificate = async (req: Request, res: Response) => {
    try {
        const { courseId } = req.params;
        const userId = req.user.userId;

        const course = await prisma.course.findUnique({ where: { id: courseId } });
        if (!course) return res.status(404).json({ message: 'Course not found' });

        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user) return res.status(404).json({ message: 'User not found' });

        // In a real app, check enrollment and progress here
        // const enrollment = await prisma.enrollment.findUnique(...) 
        // if(enrollment.progress < 100) return error...

        // For demo, just generate it
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=certificate-${course.title.replace(/\s/g, '-')}.pdf`);

        generateCertificate(user.name || 'Student', course.title, res);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error generating certificate' });
    }
};
