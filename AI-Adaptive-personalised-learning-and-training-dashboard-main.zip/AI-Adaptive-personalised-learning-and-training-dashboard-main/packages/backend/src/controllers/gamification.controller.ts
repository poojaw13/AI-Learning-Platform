import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const getAchievements = async (req: Request, res: Response) => {
    try {
        const userId = req.user.userId;

        // Fetch User Data
        const user = await prisma.user.findUnique({
            where: { id: userId },
            include: {
                enrollments: true
            }
        });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const achievements = [];

        // 1. Course Finisher Check
        const completedCourses = user.enrollments.filter(e => e.progress >= 100);
        achievements.push({
            id: 'course-finisher',
            title: 'Course Finisher',
            description: 'Complete your first course',
            xp: 500,
            unlocked: completedCourses.length > 0
        });

        // 2. XP Milestones
        achievements.push({
            id: 'novice-learner',
            title: 'Novice Learner',
            description: 'Earn 100 XP',
            xp: 100,
            unlocked: user.xp >= 100
        });

        achievements.push({
            id: 'expert-learner',
            title: 'Expert Learner',
            description: 'Earn 1000 XP',
            xp: 1000,
            unlocked: user.xp >= 1000
        });

        // 3. Streak Master
        achievements.push({
            id: 'streak-master',
            title: 'Streak Master',
            description: 'Maintain a 3-day login streak',
            xp: 300,
            unlocked: user.streak >= 3
        });

        // 4. Multi-Course Master
        achievements.push({
            id: 'polymath',
            title: 'Polymath',
            description: 'Complete 3 different courses',
            xp: 2000,
            unlocked: completedCourses.length >= 3
        });

        res.json({ achievements });

    } catch (error) {
        console.error("Error fetching achievements:", error);
        res.status(500).json({ message: 'Failed to fetch achievements' });
    }
};
