
import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Mark a lesson as complete
export const updateLessonProgress = async (req: Request, res: Response) => {
    try {
        const userId = req.user.userId;
        const { lessonId, courseId } = req.body;

        if (!lessonId || !courseId) {
            return res.status(400).json({ message: 'Lesson ID and Course ID are required' });
        }

        // 1. Upsert Lesson Progress
        const progress = await prisma.lessonProgress.upsert({
            where: {
                userId_lessonId: {
                    userId,
                    lessonId
                }
            },
            update: { completed: true },
            create: {
                userId,
                lessonId,
                completed: true
            }
        });

        // 2. Recalculate Course Progress
        // Get all lessons in the course
        const course = await prisma.course.findUnique({
            where: { id: courseId },
            include: {
                modules: {
                    include: {
                        lessons: { select: { id: true } }
                    }
                }
            }
        });

        if (!course) {
            return res.status(404).json({ message: 'Course not found' });
        }

        const totalLessons = course.modules.flatMap(m => m.lessons).length;

        // Count user's completed lessons for this course
        const completedCount = await prisma.lessonProgress.count({
            where: {
                userId,
                completed: true,
                lesson: {
                    module: {
                        courseId
                    }
                }
            }
        });

        const progressPercent = totalLessons > 0 ? (completedCount / totalLessons) * 100 : 0;

        // 3. Update Enrollment Record
        // 3. Update Enrollment Record (Upsert to ensure connection)
        await prisma.enrollment.upsert({
            where: {
                userId_courseId: {
                    userId,
                    courseId
                }
            },
            update: {
                progress: progressPercent
            },
            create: {
                userId,
                courseId,
                progress: progressPercent
            }
        });

        res.json({
            message: 'Progress updated',
            lessonProgress: progress,
            courseProgress: progressPercent
        });

    } catch (error) {
        console.error('Error updating progress:', error);
        res.status(500).json({ message: 'Failed to update progress' });
    }
};

// Get all completed lessons for a user (to hydrate frontend state)
export const getStudentProgress = async (req: Request, res: Response) => {
    try {
        const userId = req.user.userId;
        const { courseId } = req.query;

        const whereClause: any = { userId, completed: true };

        // Optional: Filter by course to optimize query
        if (courseId) {
            whereClause.lesson = {
                module: {
                    courseId: courseId as string
                }
            };
        }

        const completedLessons = await prisma.lessonProgress.findMany({
            where: whereClause,
            select: { lessonId: true }
        });

        const completedSet = completedLessons.map(p => p.lessonId);

        res.json({ completedLessons: completedSet });
    } catch (error) {
        console.error('Error fetching progress:', error);
        res.status(500).json({ message: 'Failed to fetch progress' });
    }
};
