import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const getTeacherClasses = async (req: Request, res: Response) => {
    try {
        const teacherId = (req as any).user.id;

        const courses = await prisma.course.findMany({
            where: { instructorId: teacherId },
            include: {
                _count: {
                    select: { enrollments: true, modules: true }
                },
                enrollments: {
                    select: { progress: true }
                }
            }
        });

        const formattedClasses = courses.map(course => {
            const avgProgress = course.enrollments.length > 0
                ? Math.round(course.enrollments.reduce((acc, curr) => acc + curr.progress, 0) / course.enrollments.length)
                : 0;

            return {
                id: course.id,
                name: course.title,
                section: `Cohort-${course.createdAt.getFullYear()}`,
                students: course._count.enrollments,
                modulesCount: course._count.modules,
                avg: avgProgress,
                next: "Review Final Exams" // Could be dynamic if we query Assignments/Exams
            };
        });

        res.json(formattedClasses);
    } catch (error) {
        console.error("Error fetching teacher classes:", error);
        res.status(500).json({ message: "Failed to fetch classes" });
    }
};

export const getAtRiskStudents = async (req: Request, res: Response) => {
    try {
        const teacherId = (req as any).user.id;

        // Get students enrolled in this teacher's courses who have high risk scores
        const atRisk = await (prisma as any).riskScore.findMany({
            where: {
                score: { gte: 0.5 }, // High risk threshold
                user: {
                    enrollments: {
                        some: {
                            course: { instructorId: teacherId }
                        }
                    }
                }
            },
            include: {
                user: {
                    select: { name: true, email: true }
                }
            },
            distinct: ['userId'],
            orderBy: { createdAt: 'desc' },
            take: 5
        });

        const formattedRisks = atRisk.map((risk: any) => ({
            id: risk.userId,
            name: risk.user.name || "Anonymous Student",
            reason: risk.factors || "Low engagement detected by AI",
            risk: risk.score >= 0.8 ? "High" : "Med"
        }));

        res.json(formattedRisks);
    } catch (error) {
        console.error("Error fetching at-risk students:", error);
        res.status(500).json({ message: "Failed to fetch at-risk students" });
    }
};

export const getTeacherStudents = async (req: Request, res: Response) => {
    try {
        const teacherId = (req as any).user.id;

        // Get all students enrolled in any course taught by this teacher
        const enrollments = await prisma.enrollment.findMany({
            where: {
                course: { instructorId: teacherId }
            },
            include: {
                user: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        lastLogin: true,
                        sessions: {
                            orderBy: { startTime: 'desc' },
                            take: 5
                        },
                        results: {
                            select: { score: true }
                        }
                    }
                },
                course: {
                    select: {
                        title: true
                    }
                }
            },
            distinct: ['userId']
        });

        const formattedStudents = enrollments.map(e => {
            // Calculate Performance (Avg Grade)
            const totalScore = e.user.results.reduce((acc, curr) => acc + curr.score, 0);
            const avgScore = e.user.results.length > 0 ? Math.round(totalScore / e.user.results.length) : 0;

            // Calculate Attendance (Proxy: Session consistency or Login recency)
            // For now, let's use a "Login Score" based on last 7 days + total sessions
            const lastLogin = e.user.lastLogin ? new Date(e.user.lastLogin) : null;
            const daysSinceLogin = lastLogin ? Math.floor((Date.now() - lastLogin.getTime()) / (1000 * 60 * 60 * 24)) : 30;
            let attendanceScore = 100 - (daysSinceLogin * 5); // Lose 5% per day absent
            if (attendanceScore < 0) attendanceScore = 0;

            // Determine Status
            let status = "Active";
            if (daysSinceLogin > 7) status = "Needs Review";
            if (daysSinceLogin > 30) status = "Inactive";

            // Determine Performance Label
            let performance = "Average";
            if (avgScore >= 90) performance = "Excellent";
            else if (avgScore >= 75) performance = "Good";
            else if (avgScore < 50) performance = "Poor";

            return {
                id: e.user.id,
                name: e.user.name || "Anonymous",
                email: e.user.email,
                class: e.course.title,
                grade: avgScore.toString(),
                attendance: attendanceScore.toString(),
                status,
                lastSession: lastLogin ? lastLogin.toLocaleDateString() : "Never",
                performance
            };
        });

        res.json(formattedStudents);
    } catch (error) {
        console.error("Error fetching teacher students:", error);
        res.status(500).json({ message: "Failed to fetch students" });
    }
};

export const getCourseStudents = async (req: Request, res: Response) => {
    try {
        const { courseId } = req.params;

        const enrollments = await prisma.enrollment.findMany({
            where: { courseId },
            include: {
                user: {
                    select: { id: true, name: true, email: true, avatar: true }
                },
                course: {
                    select: { title: true }
                }
            }
        });

        // Fetch real grades
        const studentIds = enrollments.map(e => e.userId);

        const [quizAgg, examAgg] = await Promise.all([
            prisma.quizResult.groupBy({
                by: ['userId'],
                _avg: { score: true },
                where: { userId: { in: studentIds } }
            }),
            prisma.examResult.groupBy({
                by: ['userId'],
                _avg: { score: true },
                where: { userId: { in: studentIds } }
            })
        ]);

        const students = enrollments.map(e => {
            const quizScore = quizAgg.find(q => q.userId === e.userId)?._avg.score || 0;
            const examScore = examAgg.find(ex => ex.userId === e.userId)?._avg.score || 0;

            return {
                id: e.user.id,
                name: e.user.name || "Unknown Student",
                email: e.user.email,
                assignments: Math.round(quizScore), // Map quizzes to assignments
                midterms: Math.round(examScore),    // Map exams to midterms
                final: Math.round(examScore),       // Map exams to final (or 0 if no final)
                attendance: Math.round(e.progress), // Use progress as proxy for attendance/engagement
                progress: e.progress,
                avatar: e.user.avatar
            };
        });

        res.json(students);
    } catch (error) {
        console.error("Error fetching course students:", error);
        res.status(500).json({ message: "Failed to fetch course students" });
    }
};

