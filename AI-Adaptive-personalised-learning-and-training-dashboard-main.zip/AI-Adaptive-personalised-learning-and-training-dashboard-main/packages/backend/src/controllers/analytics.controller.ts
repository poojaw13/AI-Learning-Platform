import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Real DB Stats
export const getDashboardStats = async (req: Request, res: Response) => {
    try {
        const userId = req.user.userId;

        const [user, enrollments, quizResults] = await Promise.all([
            prisma.user.findUnique({ where: { id: userId } }),
            prisma.enrollment.findMany({ where: { userId } }),
            prisma.quizResult.findMany({
                where: { userId },
                include: { lesson: true }
            })
        ]);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const coursesCompleted = enrollments.filter(e => e.progress === 100).length;
        // Approximation: Sum of progress for hoursLearned (just a heuristic if no explicit logging)
        const hoursLearned = Math.round(enrollments.reduce((acc, curr) => acc + (curr.progress * 0.5), 0));

        // Calculate Skills Mastered: Unique topics (lessons) with score >= 80%
        const masteredTopics = new Set(
            quizResults
                .filter(r => r.score >= 80)
                .map(r => r.lesson.title)
        );
        const skillsMastered = masteredTopics.size;

        res.json({
            userId,
            coursesCompleted,
            hoursLearned, // This is an estimate based on progress
            streak: user.streak,
            skillsMastered,
            xp: user.xp,
            recentActivity: [], // Could query QuizResult later
            // New: Velocity Data (Mocked for now as we don't have daily XP logs yet, or calculated from QuizResults)
            velocity: [
                { name: 'Mon', xp: 0 },
                { name: 'Tue', xp: 0 },
                { name: 'Wed', xp: 0 },
                { name: 'Thu', xp: 0 },
                { name: 'Fri', xp: 0 },
                { name: 'Sat', xp: 0 },
                { name: 'Sun', xp: user.xp } // Show total as current for visual
            ]
        });
    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        res.status(500).json({ message: 'Error fetching stats' });
    }
};

export const getPerformanceMetrics = async (req: Request, res: Response) => {
    try {
        const userId = req.user.userId;
        const results = await prisma.quizResult.findMany({
            where: { userId },
            include: { lesson: true },
            orderBy: { createdAt: 'desc' },
            take: 5
        });

        // Calculate simple metrics from real data
        const recentQuizzes = results.map(r => ({
            title: r.lesson.title,
            tags: [r.lesson.type, "General"],
            time: "10m",
            score: r.score,
            totalQuestions: 10, // Assuming 10 for now
            completedAt: r.createdAt.toLocaleDateString()
        }));

        res.json({
            strongAreas: [], // Todo: Analyze topics from Question bank if available
            focusAreas: [],
            monthlyGoalProgress: 0,
            recentQuizzes
        });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching performance' });
    }
};

export const getAIInsights = async (req: Request, res: Response) => {
    try {
        const userId = req.user.userId;

        // Fetch real data for insights
        const [quizResults, examResults, enrollments] = await Promise.all([
            prisma.quizResult.findMany({
                where: { userId },
                include: { lesson: true },
                orderBy: { createdAt: 'desc' },
                take: 10
            }),
            prisma.examResult.findMany({
                where: { userId },
                include: { exam: true },
                orderBy: { createdAt: 'desc' },
                take: 5
            }),
            prisma.enrollment.findMany({
                where: { userId },
                include: { course: true }
            })
        ]);

        const performanceInsights = [];
        const recommendations = [];

        // 1. Generate Performance Insights
        if (quizResults.length > 0 || examResults.length > 0) {
            const totalScore = quizResults.reduce((acc, curr) => acc + curr.score, 0) + examResults.reduce((acc, curr) => acc + (curr.score || 0), 0);
            const totalCount = quizResults.length + examResults.length;
            const avgScore = totalScore / totalCount;

            // Insight: General Performance
            if (avgScore >= 80) {
                performanceInsights.push({
                    type: 'success',
                    title: 'Strong Academic Performance',
                    description: `You represent a strong understanding of concepts with a ${Math.round(avgScore)}% average score across assessments.`
                });
            } else if (avgScore < 60) {
                performanceInsights.push({
                    type: 'warning',
                    title: 'Concept Reinforcement Needed',
                    description: `Your average score is ${Math.round(avgScore)}%. Consider reviewing course materials for better retention.`,
                    action: 'Review Basics'
                });
            }

            // Insight: Velocity
            if (totalCount >= 5) {
                performanceInsights.push({
                    type: 'info',
                    title: 'Consistent Learner',
                    description: 'You are maintaining a steady learning pace with frequent assessment attempts.'
                });
            }
        }

        // Insight: Course Progress
        const activeCourses = enrollments.filter(e => e.progress > 0 && e.progress < 100);
        if (activeCourses.length > 0) {
            performanceInsights.push({
                type: 'purple',
                title: 'Active Progress',
                description: `You are actively making progress in ${activeCourses.length} courses. Keep up the momentum!`,
                action: 'Continue Learning'
            });
        }

        // Only generate "Start Your First Course" if explicitly 0 enrollments and 0 active progress
        // Checking for completely empty state to avoid "mismatched" feelings.
        if (enrollments.length === 0 && quizResults.length === 0 && examResults.length === 0) {
            recommendations.push({
                id: 1,
                title: "Start Your First Course",
                tags: ["Recommendation"],
                priorityColor: "bg-blue-500/20 text-blue-400 border-blue-500/30",
                reasoning: "You have no active enrollments or assessment history. Browse the catalog to begin.",
                source: "System",
                time: "Now",
                category: "Getting Started"
            });
        }

        // High Performer Recommendation
        if (quizResults.length > 0 || examResults.length > 0) {
            // ... existing logic but simplified for brevity in this replace block ...
            // Reusing the avgScore calculation would be cleaner but for this diff:
            const totalScore = quizResults.reduce((acc, curr) => acc + curr.score, 0) + examResults.reduce((acc, curr) => acc + (curr.score || 0), 0);
            const avg = totalScore / (quizResults.length + examResults.length);

            if (avg >= 80 && recommendations.length === 0) {
                recommendations.push({
                    id: 2,
                    title: "Ready for Advanced Topics?",
                    tags: ["Challenge"],
                    priorityColor: "bg-purple-500/20 text-purple-400 border-purple-500/30",
                    reasoning: "Your high assessment scores suggest you're ready for more complex challenges. Try a project-based module.",
                    source: "AI Tutor",
                    time: "Now",
                    category: "Next Steps"
                });
            }
        }

        // 2. Prepare Recent Quiz Analysis Data (Merging Quizzes and Exams)
        const mappedQuizzes = quizResults.map(q => ({
            id: q.id,
            title: q.lesson.title,
            score: q.score,
            topic: 'Quiz',
            date: q.createdAt
        }));

        const mappedExams = examResults.map(e => ({
            id: e.id,
            title: e.exam.title,
            score: e.score || 0,
            topic: 'Exam', // Distinguish visually if possible, or just call it 'Exam'
            date: e.createdAt
        }));

        // Merge and Sort
        const recentQuizzes = [...mappedQuizzes, ...mappedExams]
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .slice(0, 5);

        res.json({
            insights: recommendations,
            performanceInsights,
            recentQuizzes, // Now includes Exams
            generatedAt: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ message: "Failed to generate insights" });
    }
};

export const getAdminStats = async (req: Request, res: Response) => {
    try {
        // Parallelize queries for performance
        const [
            totalUsers,
            usersActiveToday,
            totalCourses,
            coursesActive, // Courses with at least one enrollment
            totalCertificates, // Approximation based on completed enrollments for now
            integrityAlerts // Placeholder
        ] = await Promise.all([
            prisma.user.count(),
            prisma.user.count({
                where: {
                    lastLogin: {
                        gte: new Date(new Date().setHours(0, 0, 0, 0))
                    }
                }
            }),
            prisma.course.count(),
            prisma.course.count({
                where: {
                    enrollments: {
                        some: {}
                    }
                }
            }),
            prisma.enrollment.count({
                where: {
                    progress: 100
                }
            }),
            prisma.anomalyLog.count({
                where: {
                    severity: 'HIGH',
                    createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
                }
            })
        ]);

        // Real Monthly Growth (Last 6 Months)
        const months = [];
        const growthData = [];
        const today = new Date();

        for (let i = 5; i >= 0; i--) {
            const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            const monthName = d.toLocaleString('default', { month: 'short' });
            const nextMonth = new Date(d.getFullYear(), d.getMonth() + 1, 1);

            const [studentCount, courseCount] = await Promise.all([
                prisma.user.count({ where: { createdAt: { lt: nextMonth } } }),
                prisma.course.count({ where: { createdAt: { lt: nextMonth } } })
            ]);

            growthData.push({
                name: monthName,
                students: studentCount,
                courses: courseCount
            });
        }

        // New: Skill Distribution (Based on Quiz Results by Type)
        const skillDistribution = [
            { name: 'Python', value: await prisma.quizResult.count({ where: { lesson: { type: 'PYTHON' } } }) },
            { name: 'React', value: await prisma.quizResult.count({ where: { lesson: { type: 'REACT' } } }) },
            { name: 'AI/ML', value: await prisma.quizResult.count({ where: { lesson: { type: 'AI' } } }) },
            { name: 'Data Science', value: await prisma.quizResult.count({ where: { lesson: { type: 'DATA_SCIENCE' } } }) }
        ];

        // New: Recent Alerts
        const recentAlertsRaw = await prisma.anomalyLog.findMany({
            take: 5,
            orderBy: { createdAt: 'desc' },
            select: {
                id: true,
                type: true,
                severity: true,
                createdAt: true
            }
        });

        const recentAlerts = recentAlertsRaw.map(alert => ({
            id: alert.id,
            description: alert.type.replace(/_/g, ' '), // Simple formatting
            severity: alert.severity,
            createdAt: alert.createdAt
        }));

        res.json({
            kpis: {
                totalUsers,
                activeToday: usersActiveToday,
                totalCourses,
                coursesActive,
                totalCertificates,
                systemStatus: "Online",
                integrityAlerts
            },
            growthData,
            skillDistribution,
            recentAlerts
        });

    } catch (error) {
        console.error("Error fetching admin stats:", error);
        res.status(500).json({ message: "Failed to fetch admin statistics" });
    }
};
