import express, { Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';

const app = express();

app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(morgan('dev'));

import authRoutes from './routes/auth.routes';
import courseRoutes from './routes/course.routes';
import assessmentRoutes from './routes/assessment.routes';
import aiRoutes from './routes/ai.routes';
import analyticsRoutes from './routes/analytics.routes';
import adminRoutes from './routes/admin.routes';
import teacherRoutes from './routes/teacher.routes';
import examRoutes from './routes/exam.routes';
import studentIqRoutes from './routes/student_iq.routes';
import adminIqRoutes from './routes/admin_iq.routes';
import progressRoutes from './routes/progress.routes';
import gamificationRoutes from './routes/gamification.routes';
import challengeRoutes from './routes/challenge.routes';

app.use('/api/auth', authRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/assessments', assessmentRoutes);
app.use('/api/challenges', challengeRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/teacher', teacherRoutes);
app.use('/api/exams', examRoutes);
app.use('/api/student-iq', studentIqRoutes);
app.use('/api/admin-iq', adminIqRoutes);
app.use('/api/progress', progressRoutes);
app.use('/api/gamification', gamificationRoutes);

app.get('/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', timestamp: new Date() });
});

export default app;
