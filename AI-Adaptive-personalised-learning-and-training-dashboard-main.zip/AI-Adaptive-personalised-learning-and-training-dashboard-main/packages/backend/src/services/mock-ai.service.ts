
/**
 * Mock AI Service for generating educational content.
 * Simulates a Large Language Model by constructing structured markdown from templates.
 */

export const generateLessonContent = async (topic: string, level: 'Beginner' | 'Intermediate' | 'Advanced') => {
    // Simulate AI Latency (1-2 seconds)
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Dynamic Templates based on difficulty
    if (level === 'Beginner') {
        return `
# Introducción to ${topic}
*AI-Generated for Beginners*

## What is ${topic}?
${topic} is a fundamental concept in software development. Think of it like building blocks. In simple terms, **${topic}** helps you structure your applications efficiently.

### Key Concepts
1. **Basics**: Understanding the core syntax of ${topic}.
2. **Usage**: How to use ${topic} in a simple "Hello World" example.
3. **Common Mistakes**: Avoiding simple syntax errors.

### Simple Example
\`\`\`javascript
// Basic example of ${topic}
console.log("Hello ${topic}!");
function learn() {
    return "Start small";
}
\`\`\`

> **AI Tip**: Don't worry about complexity yet. Focus on getting the code to run!
        `;
    } 
    
    if (level === 'Intermediate') {
        return `
# Deep Dive into ${topic}
*AI-Generated for Intermediate Developers*

## Architecture & Patterns
Now that you know the basics, let's look at how **${topic}** scales. In production environments, ${topic} is often used with design patterns like Singleton or Factory.

### Best Practices
- **Modularity**: Keep your ${topic} logic separate from UI.
- **Performance**: Optimize loops and state updates.
- **Testing**: Write unit tests for your ${topic} modules.

### Real-world Scenario
Imagine you are building an E-commerce site. ${topic} would be used to handle the shopping cart logic efficiently.

\`\`\`typescript
interface ${topic.replace(/\s/g, '')}Config {
    id: string;
    active: boolean;
}

class ${topic.replace(/\s/g, '')}Manager {
    // Optimizing state management
    process() {
        // Implementation detail
    }
}
\`\`\`
        `;
    }

    // Advanced
    return `
# Advanced ${topic} Internals
*AI-Generated for Experts*

## Under the Hood
Let's deconstruct how **${topic}** works at the compiler/runtime level. Understanding the memory allocation and garbage collection implications of ${topic} is crucial for high-frequency trading apps.

### Performance Tuning
1. **Memory Leaks**: Identifying retain cycles in ${topic}.
2. **Concurrency**: Handling race conditions when accessing ${topic}.
3. **AST Transformation**: How Babel compiles ${topic}.

### Complex Implementation
\`\`\`cpp
// Pseudocode for ${topic} internal memory handling
void* optimize_${topic.replace(/\s/g, '').toLowerCase()}(size_t size) {
    // Custom allocator for performance
    if (size > THRESHOLD) {
        return mmap_alloc(size);
    }
    return stack_alloc(size);
}
\`\`\`

> **Warning**: Only apply these optimizations if profiling indicates a bottleneck.
    `;
};
