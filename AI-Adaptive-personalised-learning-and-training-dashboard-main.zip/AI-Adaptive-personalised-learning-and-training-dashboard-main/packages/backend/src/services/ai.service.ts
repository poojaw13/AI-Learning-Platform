import axios from 'axios';

const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

interface QuizResult {
    userId: string;
    topic: string;
    score: number;
    totalQuestions: number;
    wrongAnswers: string[];
}

interface SkillGapResponse {
    userId: string;
    weaknesses: string[];
    recommendedDifficulty: number;
    suggestedTopics: string[];
}

export const analyzeQuizResult = async (result: QuizResult): Promise<SkillGapResponse | null> => {
    try {
        const response = await axios.post<SkillGapResponse>(`${AI_SERVICE_URL}/analyze`, result);
        return response.data;
    } catch (error: any) {
        console.error('Error connecting to AI Service:', error.message);
        return null;
    }
};

interface ChatRequest {
    message: string;
    context?: string;
}

interface ChatResponse {
    reply: string;
}

export const chatWithTutor = async (req: ChatRequest): Promise<ChatResponse | null> => {
    try {
        const response = await axios.post<ChatResponse>(`${AI_SERVICE_URL}/chat`, req);
        const reply = response.data.reply;

        if (reply === "I am your AI Tutor. I can help with that!" || !reply) {
            return generateLocalResponse(req.message);
        }

        return response.data;
    } catch (error: any) {
        console.warn('AI Service unreachable, using local logic:', error.message);
        return generateLocalResponse(req.message);
    }
};

const generateLocalResponse = (message: string): ChatResponse => {
    const msg = message.toLowerCase();

    if (msg.includes("python")) {
        return { reply: "Python is versatile! It's great for AI, Data Science, and Backend development. Check out our 'Intro to Python' course." };
    }
    if (msg.includes("javascript") || msg.includes("js")) {
        return { reply: "JavaScript is the language of the web. You can build full-stack apps with Node.js and React!" };
    }
    if (msg.includes("react") || msg.includes("frontend")) {
        return { reply: "React is a powerful library for building user interfaces. Focus on Components, Props, and State hooks." };
    }
    if (msg.includes("node") || msg.includes("backend") || msg.includes("express")) {
        return { reply: "Node.js allows you to run JavaScript on the server. It's event-driven and great for scalable APIs." };
    }
    if (msg.includes("db") || msg.includes("database") || msg.includes("sql") || msg.includes("prisma")) {
        return { reply: "Databases are essential. We use Prisma with PostgreSQL in this platform. It makes data modeling easy!" };
    }
    if (msg.includes("quiz") || msg.includes("test")) {
        return { reply: "Quizzes help reinforce your memory. Don't worry if you get some wrong; that's part of learning!" };
    }
    if (msg.includes("hi") || msg.includes("hello") || msg.includes("hey")) {
        return { reply: "Hello there! ready to learn something new today?" };
    }

    const defaults = [
        "That's an interesting topic. I can help you search for more modules on that.",
        "I'm your AI Tutor. Could you be more specific so I can guide you better?",
        "Keep going! Consistency is key to mastering these concepts.",
        "I'm here to support your learning journey. Try asking about a specific language or course.",
        "Interesting! Tell me more about what you're working on."
    ];
    return { reply: defaults[Math.floor(Math.random() * defaults.length)] };
};

export const generateAICourse = async (topic: string, description: string): Promise<any | null> => {
    try {
        const response = await axios.post(`${AI_SERVICE_URL}/generate-course`, { topic, description }, { timeout: 300000 }); // 5 minutes
        return response.data;
    } catch (error: any) {
        console.error('Error in AI Course Generation:', error.message);
        console.warn('Falling back to local mock generation due to AI service failure.');
        return generateLocalCourse(topic, description);
    }
};

// Helper for randomization
const shuffleArray = (array: any[]) => array.sort(() => Math.random() - 0.5);

const generateDynamicExam = (topic: string) => {
    const templates = [
        { q: `What is the primary purpose of {topic}?`, o: ["To solve specific problems efficiently", "To confuse developers", "Just for aesthetic purposes", "No real purpose"], a: "To solve specific problems efficiently" },
        { q: `Which of the following is a key feature of {topic}?`, o: ["Scalability and Performance", "Slow execution speed", "Random behavior", "Manual memory management only"], a: "Scalability and Performance" },
        { q: `When would you choose to use {topic}?`, o: ["When building robust applications", "Only for small scripts", "Never", "For graphics only"], a: "When building robust applications" },
        { q: `True or False: {topic} is widely used in industry.`, o: ["True", "False", "Maybe", "Only in startups"], a: "True" },
        { q: `Which pattern is commonly associated with {topic}?`, o: ["Modular Design", "Spaghetti Code", "Copy-Paste", "None"], a: "Modular Design" },
        { q: `What is a common best practice in {topic}?`, o: ["Consistent Naming Conventions", "Writing everything in one file", "Ignoring errors", "Hardcoding values"], a: "Consistent Naming Conventions" },
        { q: `How does {topic} handle errors?`, o: ["Through Exception Handling", "By crashing silently", "It ignores them", "By deleting data"], a: "Through Exception Handling" },
        { q: `What tool is essential for working with {topic}?`, o: ["A good Code Editor / IDE", "MS Paint", "Calculator", "Music Player"], a: "A good Code Editor / IDE" },
        { q: `Why is optimization important in {topic}?`, o: ["To improve user experience and cost", "To make code harder to read", "It is not important", "To use more memory"], a: "To improve user experience and cost" },
        { q: `What is the first step in learning {topic}?`, o: ["Understanding the basics", "Mastering advanced topics", "Buying a new computer", "Giving up"], a: "Understanding the basics" },
        { q: `In a professional setting, how is {topic} deployed?`, o: ["Using CI/CD pipelines", "Manually copying files", "Emailing zip files", "On a USB drive"], a: "Using CI/CD pipelines" },
        { q: `What distinguishes an expert in {topic}?`, o: ["Deep understanding of internals", "Knowing syntax only", "Typing fast", "Using dark mode"], a: "Deep understanding of internals" },
        { q: `Which of these is a security risk in {topic}?`, o: ["Unvalidated Input", "Strong Passwords", "Encryption", "HTTPS"], a: "Unvalidated Input" },
        { q: `How do you debug {topic} code?`, o: ["Using breakpoints and logs", "Staring at the screen", "Guessing", "Deleting the project"], a: "Using breakpoints and logs" },
        { q: `What is the future of {topic}?`, o: ["Integration with AI and Cloud", "Obsolescence", "Becoming manual", "No future"], a: "Integration with AI and Cloud" },
        { q: `Does {topic} support open source libraries?`, o: ["Yes, extensively", "No, never", "Only paid ones", "Maybe"], a: "Yes, extensively" },
        { q: `What is the role of the community in {topic}?`, o: ["Providing documentation and tools", "Creating viruses", "Nothing", "Charging money"], a: "Providing documentation and tools" },
        { q: `Can {topic} be used for large-scale systems?`, o: ["Yes, it is designed for scale", "No, only for prototypes", "Maybe", "I don't know"], a: "Yes, it is designed for scale" },
        { q: `What is "Refactoring" in the context of {topic}?`, o: ["Improving structure without changing behavior", "Rewriting code from scratch", "Deleting comments", "Adding bugs"], a: "Improving structure without changing behavior" },
        { q: `How do you stay updated with {topic}?`, o: ["Reading documentation and blogs", "Ignoring updates", "Using old versions", "Guessing"], a: "Reading documentation and blogs" },
        { q: `Which architectural style fits {topic}?`, o: ["Microservices", "Monolith (if simple)", "Event-Driven", "All of the above"], a: "All of the above" },
        { q: `What is unit testing in {topic}?`, o: ["Testing individual components", "Testing the whole app", "Manual clicking", "None"], a: "Testing individual components" },
        { q: `Why is version control important for {topic}?`, o: ["To track changes and collaborate", "To waste space", "To confuse people", "It is not"], a: "To track changes and collaborate" },
        { q: `What is the "Hello World" of {topic}?`, o: ["A simple print statement", "A complex server", "A database", "An AI model"], a: "A simple print statement" },
        { q: `How does {topic} manage memory?`, o: ["Mostly automatic (Garbage Collection)", "Manual only", "It doesn't", "Magic"], a: "Mostly automatic (Garbage Collection)" }
    ];

    // Shuffle and pick 20
    const shuffled = shuffleArray(templates);
    const selected = shuffled.slice(0, 20);

    return selected.map(t => ({
        text: t.q.replace("{topic}", topic),
        options: shuffleArray([...t.o]), // Shuffle options too
        correctAnswer: t.a
    }));
};

const generateLocalCourse = (topic: string, description: string) => {
    const cleanTopic = topic.replace(/^(What is |Intro to |Introduction to |How to learn )/i, '').trim();

    return {
        title: `Mastering ${cleanTopic}: From Beginner to Advanced`,
        description: description || `A comprehensive curriculum designed to take you from a complete beginner to an advanced practitioner in ${cleanTopic}.`,
        modules: [
            {
                title: "Level 1: The Foundation (Beginner)",
                lessons: [
                    {
                        title: `1.1 Introduction to ${cleanTopic}`,
                        content: `# Welcome to ${cleanTopic}\n\n## The Journey Begins\nWelcome to your first step in mastering **${cleanTopic}**! This course is designed to take you from zero to hero. In this introductory lesson, we will explore not just what ${cleanTopic} is, but *why* it matters in the modern tech landscape. \n\n### Why Learn This?\nIn today's fast-paced digital world, **${cleanTopic}** stands out as a critical skill. Whether you are looking to automate boring tasks, build scalable web applications, or analyze massive datasets, this technology provides the tools you need. It is used by top tech companies like Google, Facebook, and Netflix to power their core services.\n\n### Core Philosophy\nAt its heart, ${cleanTopic} is built around the idea of **simplicity and power**. It avoids unnecessary complexity while giving you the control you need. \n\n> "The only way to do great work is to love what you do." - Steve Jobs\n\n### Real-World Analogy\nThink of ${cleanTopic} like a Swiss Army Knife. It has a tool for every situation. You might only use the knife (basic syntax) at first, but soon you'll be using the screwdriver (libraries) and scissors (frameworks) to build complex projects.\n\n![Intro Image](https://source.unsplash.com/random/800x400/?${cleanTopic.split(' ')[0]})\n\n(Generated by Intelligent Fallback)`,
                        type: "VIDEO"
                    },
                    {
                        title: "1.2 Setting Up Your Environment",
                        content: `# Getting Started: The Setup\n\nBefore we write a single line of code, we need a solid foundation. A carpenter doesn't start work without sharpening their tools, and neither should you.\n\n### Step 1: Installation\nThe first thing you need is the runtime. Open your terminal and run:\n\n\`\`\`bash\nnpm install ${cleanTopic.toLowerCase().replace(' ', '-')}\n# or for python users\npip install ${cleanTopic.toLowerCase().replace(' ', '-')}\n\`\`\`\n\n### Step 2: The IDE\nWe highly recommend using **VS Code** or **IntelliJ**. These editors provide syntax highlighting, auto-completion, and debugging tools that will save you hundreds of hours.\n\n### Common Pitfalls\n- **Path Issues**: Make sure your environment variables are set correctly.\n- **Version Mismatch**: Always check that you are using the latest stable version.\n\n### Pro Tip\nSpend time customizing your editor themes and shortcuts. A comfortable environment leads to better code!`,
                        type: "TEXT"
                    },
                    {
                        title: "1.3 Core Concepts & Syntax",
                        content: `# The Building Blocks\n\nEvery expert was once a beginner. Let's master the basics that form the foundation of everything else.\n\n### Variables and Data Types\nData is the fuel of any application. In ${cleanTopic}, we handle data using variables. \n\n- **Strings**: For text.\n- **Integers**: For whole numbers.\n- **Booleans**: For true/false logic.\n\n### Control Flow\nYour program needs to make decisions. This is done using \`if-else\` statements and loops.\n\n\`\`\`javascript\nif (isReady) {\n  startLearning();\n} else {\n  takeBreak();\n}\n\`\`\`\n\n### Functions\nDon't repeat yourself (DRY). Functions distinguish a novice from a pro. They allow you to encapsulate logic and reuse it across your application.\n\n### Summary\nMastering these basics is non-negotiable. Practice them until they become second nature.`,
                        type: "TEXT"
                    }
                ]
            },
            {
                title: "Level 2: Intermediate Mastery",
                lessons: [
                    {
                        title: "2.1 Advanced Patterns & Architecture",
                        content: `# Level Up: Professional Architecture\n\nNow that you know the basics, let's write code that *scales*. Writing code that works is easy; writing code that is maintainable is hard.\n\n### The MVC Pattern\nModel-View-Controller (MVC) is the industry standard for specific types of applications. It separates concerns:\n- **Model**: Data logic.\n- **View**: User Interface.\n- **Controller**: Business logic.\n\n### Async Programming\nModern applications are asynchronous. You cannot block the main thread while waiting for a database query. Learn to use \`Promises\` and \`async/await\` to handle operations smoothly.\n\n### State Management\nAs your app grows, passing data around becomes a nightmare. We use state management libraries to handle this centrally.\n\n> "Good code is readable code."`,
                        type: "VIDEO"
                    },
                    {
                        title: "2.2 Working with Data & APIs",
                        content: `# Data Handling in Depth\n\nData is king. In this lesson, we will look at how to manage state and handle huge datasets efficiently.\n\n### REST vs GraphQL\nHow do you talk to servers? \n- **REST**: Standard resource-based URL endpoints.\n- **GraphQL**: Query exactly what you need.\n\n### Database Interaction\nConnecting to a DB (like using Prisma ORM) allows you to persist data. \n\n\`\`\`typescript\nconst user = await prisma.user.findFirst({\n  where: { id: 1 }\n});\n\`\`\`\n\n### Practical Exercise\nTry building a simple CRUD (Create, Read, Update, Delete) application. This is the rite of passage for every developer.`,
                        type: "TEXT"
                    },
                    {
                        title: "2.3 Debugging & Testing Strategies",
                        content: `# Bulletproof Code\n\nErrors will happen. It's not a matter of *if*, but *when*. The difference between a junior and a senior dev is how they handle errors.\n\n### Unit Testing\nTest individual functions in isolation. Tools like Jest or Mocha are perfect for this.\n\n\`\`\`javascript\ntest('should return 4', () => {\n  expect(add(2, 2)).toBe(4);\n});\n\`\`\`\n\n### Integration Testing\nTest how different parts of your system work together. Does the API talk to the Database correctly?\n\n### Debugging Workflow\n1. Reproduce the bug.\n2. Isolate the cause.\n3. Fix it.\n4. Write a test to ensure it never comes back.`,
                        type: "TEXT"
                    }
                ]
            },
            {
                title: "Level 3: Expert & Real World (Advanced)",
                lessons: [
                    {
                        title: "3.1 Performance Optimization",
                        content: `# Speed Matters\n\nIn the real world, milliseconds equal revenue. Optimizing for scale and performance is the hallmark of an expert.\n\n### Caching Strategies\nDon't compute the same thing twice. Use Redis or Memcached to store expensive query results.\n\n### Database Indexing\nAn unindexed database is a slow database. Learn how B-Trees work and how to optimize your SQL queries.\n\n### Load Balancing\nWhen one server isn't enough, use Nginx to distribute traffic across a cluster of servers. This ensures high availability and fault tolerance.`,
                        type: "VIDEO"
                    },
                    {
                        title: "3.2 Distributed Systems Design",
                        content: `# System Design\n\nBuilding scalable distributed systems is the ultimate challenge.\n\n### Microservices vs Monolith\nShould you split your app into small services? \n- **Pros**: Independent scaling, technology agnostic.\n- **Cons**: Network latency, complex deployment.\n\n### CAP Theorem\nConsistency, Availability, Partition Tolerance. You can only pick two. Understanding this trade-off is crucial for system design.\n\n### Message Queues\nDecouple your services using RabbitMQ or Kafka. This allows for asynchronous processing and buffering of high traffic.`,
                        type: "TEXT"
                    },
                    {
                        title: "3.3 Final Capstone Project",
                        content: `# The Final Challenge\n\nCombine everything you've learned to build a complete real-world application. This is your portfolio piece.\n\n### Project Requirements\n1. **Full Backend**: Secure API with authentication.\n2. **Responsive Frontend**: A beautiful UI that works on mobile.\n3. **CI/CD Pipeline**: Automated testing and deployment.\n\n### Next Steps\nCongratulations on making it this far! The learning never stops. Contribute to open source, write blogs, and teach others what you've learned.`,
                        type: "TEXT"
                    }
                ]
            }
        ],
        finalExam: {
            title: `${cleanTopic} Certification Exam`,
            passingScore: 70,
            questions: generateDynamicExam(cleanTopic)
        }
    };
};
