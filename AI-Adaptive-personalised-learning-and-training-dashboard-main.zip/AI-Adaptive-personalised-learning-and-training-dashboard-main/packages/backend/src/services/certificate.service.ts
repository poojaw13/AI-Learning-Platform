import PDFDocument from 'pdfkit';
import { Response } from 'express';

export const generateCertificate = (user: string, course: string, res: Response) => {
    const doc = new PDFDocument({
        layout: 'landscape',
        size: 'A4',
    });

    doc.pipe(res);

    // Background (Simple border)
    doc.rect(20, 20, doc.page.width - 40, doc.page.height - 40).stroke('#2980b9');

    // Header
    doc.font('Helvetica-Bold').fontSize(40).fillColor('#2c3e50').text('Certificate of Completion', 0, 100, { align: 'center' });

    // Body
    doc.moveDown();
    doc.font('Helvetica').fontSize(20).text('This is to certify that', { align: 'center' });

    doc.moveDown();
    doc.font('Helvetica-Bold').fontSize(30).fillColor('#e74c3c').text(user, { align: 'center' });

    doc.moveDown();
    doc.font('Helvetica').fontSize(20).fillColor('#2c3e50').text('has successfully completed the course', { align: 'center' });

    doc.moveDown();
    doc.font('Helvetica-Bold').fontSize(30).fillColor('#2980b9').text(course, { align: 'center' });

    doc.moveDown();
    doc.fontSize(15).fillColor('black').text(`Date: ${new Date().toLocaleDateString()}`, { align: 'center' });

    // Footer
    doc.moveDown(4);
    doc.fontSize(12).text('Adaptive Learning Platform', { align: 'center' });

    doc.end();
};
