import { PrismaClient } from '@prisma/client';
import { hashPassword } from '../src/utils/auth';

const prisma = new PrismaClient();

async function main() {
    // 0. Create Admin
    await prisma.user.upsert({
        where: { email: 'admin@admin.com' },
        update: {},
        create: {
            email: 'admin@admin.com',
            name: 'System Admin',
            password: await hashPassword('password123'),
            role: 'ADMIN',
            lastLogin: new Date()
        }
    });

    // 1. Create Teacher
    const password = await hashPassword('password123');
    const teacher = await prisma.user.upsert({
        where: { email: 'teacher@example.com' },
        update: {},
        create: {
            email: 'teacher@example.com',
            name: 'Mr. Teacher',
            password,
            role: 'TEACHER',
            lastLogin: new Date()
        }
    });

    // 1.5 Create Student
    const student = await prisma.user.upsert({
        where: { email: 'student@example.com' },
        update: {},
        create: {
            email: 'student@example.com',
            name: 'John Student',
            password: await hashPassword('password123'),
            role: 'STUDENT',
            xp: 250,
            level: 3,
            streak: 5,
            lastLogin: new Date()
        }
    });

    // 1.5.1 Upsert Learning DNA
    await prisma.learningDNA.upsert({
        where: { userId: student.id },
        update: {},
        create: {
            userId: student.id,
            style: "Visual",
            bestTime: "Night",
            averageFocus: 78
        }
    });

    // 1.5.2 Upsert Mastery (Delete existing to avoid duplicates/complex upsert)
    // For simplicity in seeding, we'll check if any exist, if not create them.
    const masteryCount = await prisma.conceptMastery.count({ where: { userId: student.id } });
    if (masteryCount === 0) {
        await prisma.conceptMastery.createMany({
            data: [
                { userId: student.id, concept: "React Basics", score: 0.85 },
                { userId: student.id, concept: "TypeScript", score: 0.65 },
                { userId: student.id, concept: "Data Structures", score: 0.72 },
                { userId: student.id, concept: "Algorithms", score: 0.45 },
                { userId: student.id, concept: "System Design", score: 0.60 }
            ]
        });
    }

    // 2. Create Course
    const course = await prisma.course.create({
        data: {
            title: 'Intro to Python Data Science',
            description: 'Learn Python basics for AI',
            instructorId: teacher.id,
            modules: {
                create: {
                    title: 'Basics',
                    order: 1,
                    lessons: {
                        create: [
                            {
                                title: 'What is Python?',
                                content: 'Python is a high-level language...',
                                type: 'TEXT',
                                order: 1
                            },
                            {
                                title: 'Data Types Quiz',
                                content: 'Quiz description',
                                type: 'QUIZ',
                                order: 2,
                                data: JSON.stringify([
                                    {
                                        id: 'q1',
                                        question: 'Which is NOT a Python data type?',
                                        options: ['int', 'str', 'float', 'real'],
                                        correctAnswer: 'real',
                                        topic: 'Data Types'
                                    },
                                    {
                                        id: 'q2',
                                        question: 'What is output of 3 + 4?',
                                        options: ['7', '34', 'Error', 'None'],
                                        correctAnswer: '7',
                                        topic: 'Arithmetic'
                                    }
                                ])
                            }
                        ]
                    }
                }
            }
        }
    });

    // 3. Enroll Student in Course
    await prisma.enrollment.create({
        data: {
            userId: student.id,
            courseId: course.id,
            progress: 35
        }
    });

    console.log('Seeded:', course.title);

    // 4. Create Coding Challenges
    const challenges = [
        {
            title: "Two Sum",
            difficulty: "Easy",
            description: "Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to `target`. You may assume that each input would have exactly one solution, and you may not use the same element twice.",
            example: "Input: nums = [2,7,11,15], target = 9\nOutput: [0,1]\nExplanation: Because nums[0] + nums[1] == 9, we return [0, 1].",
            constraints: JSON.stringify(["2 <= nums.length <= 10^4", "-10^9 <= nums[i] <= 10^9", "-10^9 <= target <= 10^9"]),
            starterCode: JSON.stringify({
                javascript: "function twoSum(nums, target) {\n    // Write your solution here\n    \n}",
                python: "def twoSum(nums, target):\n    # Write your solution here\n    pass",
                cpp: "class Solution {\npublic:\n    vector<int> twoSum(vector<int>& nums, int target) {\n        \n    }\n};"
            })
        },
        {
            title: "Coin Change",
            difficulty: "Medium",
            description: "You are given an integer array `coins` representing coins of different denominations and an integer `amount` representing a total amount of money. Return the fewest number of coins that you need to make up that amount. If that amount of money cannot be made up by any combination of the coins, return -1.",
            example: "Input: coins = [1,2,5], amount = 11\nOutput: 3\nExplanation: 11 = 5 + 5 + 1",
            constraints: JSON.stringify(["1 <= coins.length <= 12", "0 <= amount <= 10^4"]),
            starterCode: JSON.stringify({
                javascript: "function coinChange(coins, amount) {\n    // Write your solution here\n    \n}",
                python: "def coinChange(coins, amount):\n    # Write your solution here\n    pass",
                cpp: "class Solution {\npublic:\n    int coinChange(vector<int>& coins, int amount) {\n        \n    }\n};"
            })
        },
        {
            title: "Kth Smallest Element in a BST",
            difficulty: "Medium",
            description: "Given the root of a binary search tree, and an integer k, return the kth smallest value (1-indexed) of all the values of the nodes in the tree.",
            example: "Input: root = [3,1,4,null,2], k = 1\nOutput: 1",
            constraints: JSON.stringify(["The number of nodes in the tree is n.", "1 <= k <= n <= 10^4", "0 <= Node.val <= 10^4"]),
            starterCode: JSON.stringify({
                javascript: "function kthSmallest(root, k) {\n    // Write your solution here\n    \n}",
                python: "def kthSmallest(root, k):\n    # Write your solution here\n    pass",
                cpp: "class Solution {\npublic:\n    int kthSmallest(TreeNode* root, int k) {\n        \n    }\n};"
            })
        },
        {
            title: "Trapping Rain Water",
            difficulty: "Hard",
            description: "Given `n` non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.",
            example: "Input: height = [0,1,0,2,1,0,1,3,2,1,2,1]\nOutput: 6",
            constraints: JSON.stringify(["n == height.length", "1 <= n <= 2 * 10^4", "0 <= height[i] <= 10^5"]),
            starterCode: JSON.stringify({
                javascript: "function trap(height) {\n    // Write your solution here\n    \n}",
                python: "def trap(height):\n    # Write your solution here\n    pass",
                cpp: "class Solution {\npublic:\n    int trap(vector<int>& height) {\n        \n    }\n};"
            })
        }
    ];

    for (const challenge of challenges) {
        await prisma.codingChallenge.create({
            data: challenge
        });
    }
    console.log(`Seeded ${challenges.length} coding challenges`);

    console.log('Created users:');
    console.log('- Admin: admin@admin.com / password123');
    console.log('- Teacher: teacher@example.com / password123');
    console.log('- Student: student@example.com / password123');
}

main()
    .then(async () => {
        await prisma.$disconnect()
    })
    .catch(async (e) => {
        console.error(e)
        await prisma.$disconnect()
        process.exit(1)
    })
