
import axios from 'axios';

const API_URL = 'http://localhost:4000/api';
const TEST_TIMESTAMP = Date.now();
const EMAIL = `test.user.${TEST_TIMESTAMP}@example.com`;
const PASSWORD = 'password123';

async function runTest() {
    console.log(`Starting System Verification Test...`);
    console.log(`Target: ${API_URL}`);

    try {
        // 1. Register
        console.log(`\n1. Registering new test user: ${EMAIL}`);
        await axios.post(`${API_URL}/auth/register`, {
            email: EMAIL,
            password: PASSWORD,
            name: 'Test User',
            role: 'STUDENT'
        });
        console.log('✅ Registration Successful');

        // 2. Login
        console.log(`\n2. Logging in...`);
        const loginRes = await axios.post(`${API_URL}/auth/login`, {
            email: EMAIL,
            password: PASSWORD
        });
        const token = loginRes.data.token;
        const userId = loginRes.data.user.id;
        console.log('✅ Login Successful');

        const authHeaders = { Authorization: `Bearer ${token}` };

        // 3. Get Courses (Check Initial State)
        console.log(`\n3. Fetching Courses (Initial)...`);
        const coursesRes = await axios.get(`${API_URL}/courses`, { headers: authHeaders });
        const targetCourse = coursesRes.data.find((c: any) => c.modules.length > 0);

        if (!targetCourse) throw new Error("No courses found to test with.");
        console.log(`Testing with Course: ${targetCourse.title} (ID: ${targetCourse.id})`);

        const initialProgress = targetCourse.progress;
        console.log(`Initial Progress: ${initialProgress}%`);
        if (initialProgress !== 0) console.warn("⚠️ Expected 0% progress for new user");

        // 4. Mark Lesson as Complete
        const targetLesson = targetCourse.modules[0].lessons[0];
        console.log(`\n4. Completing Lesson: ${targetLesson.title} (ID: ${targetLesson.id})`);

        await axios.post(`${API_URL}/progress/lesson`, {
            lessonId: targetLesson.id,
            courseId: targetCourse.id
        }, { headers: authHeaders });
        console.log('✅ Lesson Marked Complete');

        // 5. Verify Progress Sync (Course List)
        console.log(`\n5. Verifying Course List Progress Update...`);
        const updatedCoursesRes = await axios.get(`${API_URL}/courses`, { headers: authHeaders });
        const updatedCourse = updatedCoursesRes.data.find((c: any) => c.id === targetCourse.id);

        console.log(`Updated Progress: ${updatedCourse.progress}%`);
        if (updatedCourse.progress > initialProgress) {
            console.log('✅ SUCCESS: Course List reflects progress update');
        } else {
            console.error('❌ FAIL: Course progress did not increase');
        }

        // 6. Verify Dashboard Stats
        console.log(`\n6. Verifying Dashboard Stats...`);
        const statsRes = await axios.get(`${API_URL}/analytics/dashboard`, { headers: authHeaders });
        console.log(`Learning Hours: ${statsRes.data.hoursLearned}`);

        // 7. Verify Achievements
        console.log(`\n7. Verifying Achievements...`);
        try {
            const achievementsRes = await axios.get(`${API_URL}/gamification/achievements`, { headers: authHeaders });
            console.log(`Achievements Found: ${achievementsRes.data.achievements.length}`);
            console.log('✅ SUCCESS: Achievements endpoint is accessible');
        } catch (err: any) {
            console.error('❌ FAIL: Achievements endpoint failed', err.response?.status);
        }

        console.log('\n-----------------------------------');
        console.log('🎉 SYSTEM VERIFICATION COMPLETED');
        console.log('-----------------------------------');

    } catch (error: any) {
        console.error('\n❌ TEST FAILED');
        if (error.response) {
            console.error(`Status: ${error.response.status}`);
            console.error(`Data:`, error.response.data);
        } else {
            console.error(error.message);
        }
        process.exit(1);
    }
}

runTest();
