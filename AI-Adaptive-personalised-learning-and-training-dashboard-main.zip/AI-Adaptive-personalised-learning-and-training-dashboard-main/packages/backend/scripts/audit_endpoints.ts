import axios from 'axios';

const BASE_URL = 'http://localhost:4000/api';

// MOCKED TOKENS FOR AUDIT - Ideally these should be real, fetched via login
// For this script to work, we need valid tokens.
// Step 1: Login as each role to get tokens.

const users = [
    { role: 'STUDENT', email: 'student@gmail.com', password: 'password123' },
    { role: 'TEACHER', email: 'nishanthini@gmail.com', password: 'password123' },
    { role: 'ADMIN', email: 'admin@gmail.com', password: 'password123' }
];

const routes = [
    { method: 'GET', path: '/auth/me', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'GET', path: '/courses', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'POST', path: '/courses', roles: ['ADMIN'] }, // High risk
    { method: 'GET', path: '/teacher/classes', roles: ['TEACHER', 'ADMIN'] },
    { method: 'GET', path: '/teacher/live-sessions', roles: ['STUDENT', 'TEACHER', 'ADMIN'] }, // Fixed recently
    { method: 'POST', path: '/teacher/live-sessions', roles: ['TEACHER', 'ADMIN'] },
    { method: 'GET', path: '/admin/stats', roles: ['ADMIN'] },
    { method: 'GET', path: '/analytics/insights', roles: ['STUDENT', 'TEACHER', 'ADMIN'] }, // Verify this
    // Add more critical routes
];

async function audit() {
    console.log("🚀 Starting System Audit & Bug Hunt...");

    const tokens: Record<string, string> = {};

    // 1. Get Tokens
    for (const u of users) {
        try {
            const res = await axios.post(`${BASE_URL}/auth/login`, { email: u.email, password: u.password });
            tokens[u.role] = res.data.token;
            console.log(`✅ Logged in as ${u.role}`);
        } catch (e) {
            console.error(`❌ Failed to login as ${u.role}:`, (e as Error).message);
        }
    }

    console.log("\n🔍 Scanning Routes...");

    // 2. Test Routes
    for (const route of routes) {
        console.log(`\nTesting ${route.method} ${route.path}`);

        for (const role of ['STUDENT', 'TEACHER', 'ADMIN']) {
            const token = tokens[role as keyof typeof tokens];
            if (!token) {
                console.log(`  - ${role}: SKIPPING (No token)`);
                continue;
            }

            try {
                await axios({
                    method: route.method,
                    url: `${BASE_URL}${route.path}`,
                    headers: { Authorization: `Bearer ${token}` },
                    validateStatus: () => true // Don't throw on error
                }).then(res => {
                    const status = res.status;
                    const isAllowed = route.roles.includes(role);

                    if (isAllowed && status === 200) {
                        console.log(`  - ${role}: ✅ OK (200)`);
                    } else if (!isAllowed && (status === 403 || status === 401)) {
                        console.log(`  - ${role}: ✅ SECURE (${status})`);
                    } else if (isAllowed && status !== 200) {
                        console.error(`  - ${role}: ❌ BROKEN (Expected 200, got ${status})`);
                    } else if (!isAllowed && status === 200) {
                        console.error(`  - ${role}: 🚨 SECURITY RISK (Expected 403, got 200)`);
                    } else {
                        console.log(`  - ${role}: ⚠️  Unexpected (${status})`);
                    }
                });
            } catch (e) {
                console.error(`  - ${role}: 💥 CRASH (${(e as Error).message})`);
            }
        }
    }
}

audit();
