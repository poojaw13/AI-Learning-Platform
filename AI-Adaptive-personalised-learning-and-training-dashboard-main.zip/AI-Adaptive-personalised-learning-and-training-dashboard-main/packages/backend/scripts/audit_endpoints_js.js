
const axios = require('axios');
const fs = require('fs');

const BASE_URL = 'http://localhost:4000/api';

const timestamp = Date.now();
const users = [
    { role: 'STUDENT', email: `student_${timestamp}@test.com`, password: 'password123' },
    { role: 'TEACHER', email: `teacher_${timestamp}@test.com`, password: 'password123' },
    { role: 'ADMIN', email: `admin_${timestamp}@test.com`, password: 'password123' }
];

const routes = [
    // Public/Auth
    { method: 'GET', path: '/auth/me', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },

    // Courses
    { method: 'GET', path: '/courses', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'POST', path: '/courses', roles: ['ADMIN'] }, // High risk

    // Teacher Dashboard
    { method: 'GET', path: '/teacher/classes', roles: ['TEACHER', 'ADMIN'] },
    { method: 'GET', path: '/teacher/students', roles: ['TEACHER', 'ADMIN'] },
    { method: 'GET', path: '/teacher/students/at-risk', roles: ['TEACHER', 'ADMIN'] },

    // Live Sessions
    { method: 'GET', path: '/teacher/live-sessions', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'POST', path: '/teacher/live-sessions', roles: ['TEACHER', 'ADMIN'] },

    // Analytics
    { method: 'GET', path: '/analytics/dashboard', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'GET', path: '/analytics/insights', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'GET', path: '/admin/stats', roles: ['ADMIN'] },

    // Progress
    { method: 'GET', path: '/progress', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'POST', path: '/progress/lesson', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },

    // Exams
    { method: 'GET', path: '/exams', roles: ['STUDENT', 'TEACHER', 'ADMIN'] },
    { method: 'POST', path: '/exams', roles: ['TEACHER', 'ADMIN'] },
];

// function log(msg) {
//     console.log(msg);
//     fs.appendFileSync('audit_report_v2.txt', msg + '\n');
// }

// Just use same file
function log(msg) {
    console.log(msg);
    fs.appendFileSync('audit_report_v2.txt', msg + '\n');
}

async function audit() {
    fs.writeFileSync('audit_report_v2.txt', "🚀 Starting System Audit & Bug Hunt (Round 2)...\n");
    log("🚀 Starting System Audit & Bug Hunt...");

    const tokens = {};

    // 1. Get Tokens
    for (const u of users) {
        try {
            // Try Register first
            try {
                await axios.post(`${BASE_URL}/auth/register`, {
                    email: u.email,
                    password: u.password,
                    name: u.role,
                    role: u.role
                });
                log(`✅ Registered ${u.role}`);
            } catch (err) {
                // Ignore if already exists (400 or 409)
            }

            // Msg Login
            const res = await axios.post(`${BASE_URL}/auth/login`, { email: u.email, password: u.password });
            tokens[u.role] = res.data.token;
            log(`✅ Logged in as ${u.role}`);
        } catch (e) {
            log(`❌ Failed to login/register as ${u.role}: ${e.message}`);
            if (e.response) log(`   Response: ${JSON.stringify(e.response.data)}`);
        }
    }

    log("\n🔍 Scanning Routes...");

    // 2. Test Routes
    for (const route of routes) {
        log(`\nTesting ${route.method} ${route.path}`);

        for (const role of ['STUDENT', 'TEACHER', 'ADMIN']) {
            const token = tokens[role];
            if (!token) {
                log(`  - ${role}: SKIPPING (No token)`);
                continue;
            }

            try {
                const res = await axios({
                    method: route.method,
                    url: `${BASE_URL}${route.path}`,
                    headers: { Authorization: `Bearer ${token}` },
                    validateStatus: () => true // Don't throw on error
                });

                const status = res.status;
                const isAllowed = route.roles.includes(role);

                if (isAllowed && (status >= 200 && status < 300)) {
                    log(`  - ${role}: ✅ OK (${status})`);
                } else if (!isAllowed && (status === 403 || status === 401)) {
                    log(`  - ${role}: ✅ SECURE (${status})`);
                } else if (isAllowed && status >= 400) {
                    if (status === 404) {
                        log(`  - ${role}: ⚠️  NOT FOUND (404) - Path likely invalid or data missing`);
                    } else {
                        log(`  - ${role}: ❌ BROKEN (Expected 200, got ${status})`);
                    }
                } else if (!isAllowed && (status >= 200 && status < 300)) {
                    log(`  - ${role}: 🚨 SECURITY RISK (Expected 403, got ${status})`);
                } else {
                    log(`  - ${role}: ⚠️  Unexpected (${status})`);
                }

            } catch (e) {
                log(`  - ${role}: 💥 CRASH (${e.message})`);
            }
        }
    }
}

audit();
