
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    try {
        console.log("Fetching all coding challenges...");
        const challenges = await prisma.codingChallenge.findMany();
        console.log(`Found ${challenges.length} challenges.`);

        challenges.forEach(c => {
            console.log(`- ID: ${c.id}, Title: ${c.title}`);
        });

        const targetId = "109";
        const existing = await prisma.codingChallenge.findUnique({ where: { id: targetId } });

        if (!existing) {
            console.log(`Challenge ${targetId} not found. Creating it...`);
            await prisma.codingChallenge.create({
                data: {
                    id: targetId,
                    title: "Two Sum (Fixed)",
                    difficulty: "Easy",
                    description: "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.",
                    example: "Input: nums = [2,7,11,15], target = 9\nOutput: [0,1]",
                    constraints: JSON.stringify(["2 <= nums.length <= 10^4", "-10^9 <= nums[i] <= 10^9"]),
                    starterCode: JSON.stringify({
                        javascript: "function twoSum(nums, target) {\n  // Your code here\n}",
                        python: "def two_sum(nums, target):\n    # Your code here",
                        cpp: "class Solution {\npublic:\n    vector<int> twoSum(vector<int>& nums, int target) {\n        \n    }\n};"
                    })
                }
            });
            console.log(`Created challenge ${targetId}.`);
        } else {
            console.log(`Challenge ${targetId} already exists.`);
        }

    } catch (e) {
        console.error("Error:", e);
    } finally {
        await prisma.$disconnect();
    }
}

main();
