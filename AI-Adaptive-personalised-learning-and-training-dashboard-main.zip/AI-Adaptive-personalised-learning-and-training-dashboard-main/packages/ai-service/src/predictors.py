import random
from typing import List, Dict

def predict_dropout_risk(student_data: Dict) -> Dict:
    """
    Mock ML logic to predict dropout risk.
    """
    # Heuristic: 
    # - Low XP/Level
    # - High inactivity
    # - Low average accuracy
    risk_score = random.uniform(0, 1)
    factors = []
    
    if risk_score > 0.7:
        factors.append("Low engagement in last 3 sessions")
        factors.append("Accuracy below 60% in core modules")
    elif risk_score > 0.4:
        factors.append("Inconsistent learning schedule")
        
    return {
        "score": round(risk_score, 2),
        "factors": factors,
        "recommendation": "Suggest 'Comeback Plan' if score > 0.6"
    }

def generate_concept_path(mastery_data: List[Dict]) -> List[str]:
    """
    Identifies skill gaps and suggests a learning path.
    """
    weak_concepts = [m['concept'] for m in mastery_data if m['score'] < 0.7]
    return weak_concepts if weak_concepts else ["Advanced Specialization"]
