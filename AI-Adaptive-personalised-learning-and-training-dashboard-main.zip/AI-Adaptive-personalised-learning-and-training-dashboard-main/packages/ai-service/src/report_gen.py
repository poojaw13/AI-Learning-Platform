from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import random
import os

def generate_impact_report(user_data: dict, filename: str):
    """
    Generates a PDF learning impact report.
    """
    c = canvas.Canvas(filename, pagesize=letter)
    width, height = letter
    
    # Header
    c.setFont("Helvetica-Bold", 24)
    c.drawString(100, height - 80, "Learning Impact Report")
    
    c.setFont("Helvetica", 12)
    c.drawString(100, height - 100, f"Prepared for: {user_data.get('name', 'Learner')}")
    c.drawString(100, height - 115, f"Date: January 2026")
    
    c.line(100, height - 130, 500, height - 130)
    
    # Growth Stats
    c.setFont("Helvetica-Bold", 16)
    c.drawString(100, height - 160, "Monthly Growth Summary")
    
    stats = [
        f"XP Gained: {random.randint(500, 2000)}",
        f"Skills Mastered: {random.randint(3, 8)}",
        f"Hours Learned: {random.randint(10, 40)}",
        f"Focus Consistency: {random.randint(70, 95)}%"
    ]
    
    c.setFont("Helvetica", 12)
    y_pos = height - 185
    for stat in stats:
        c.drawString(120, y_pos, f"• {stat}")
        y_pos -= 20
        
    # AI Feedback
    c.setFont("Helvetica-Bold", 16)
    c.drawString(100, y_pos - 20, "AI Insights & Recommendations")
    
    c.setFont("Helvetica", 10)
    feedback = (
        "You have shown exceptional growth in 'Core Algorithms'. "
        "Your 'Night Learner' DNA suggests you perform best between 10 PM and 1 AM. "
        "Recommendation: Prioritize 'Advanced React Hooks' in the coming week to maintain momentum."
    )
    
    # Basic text wrap
    text_object = c.beginText(100, y_pos - 45)
    text_object.setFont("Helvetica", 10)
    text_object.setTextOrigin(100, y_pos - 45)
    
    words = feedback.split()
    line = ""
    for word in words:
        if len(line + " " + word) < 80:
            line += " " + word
        else:
            text_object.textLine(line)
            line = word
    text_object.textLine(line)
    c.drawText(text_object)
    
    c.save()
    return filename
