from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="Adaptive Learning AI Service")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"status": "online", "service": "ai-microservice"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}

from skill_analyzer import analyze_gap, QuizResult, SkillGapResponse
from src.predictors import predict_dropout_risk, generate_concept_path
from src.report_gen import generate_impact_report
import uuid

@app.post("/analyze", response_model=SkillGapResponse)
def analyze_skills(result: QuizResult):
    return analyze_gap(result)

@app.post("/predict-risk")
def calculate_risk(student_data: Dict):
    return predict_dropout_risk(student_data)

@app.post("/generate-path")
def create_path(mastery_data: List[Dict]):
    path = generate_concept_path(mastery_data)
    return {"path": path}

@app.post("/generate-report")
def create_report(user_data: Dict):
    report_id = str(uuid.uuid4())
    filename = f"reports/report_{report_id}.pdf"
    os.makedirs("reports", exist_ok=True)
    generate_impact_report(user_data, filename)
    return {"report_url": f"/reports/report_{report_id}.pdf", "filename": filename}

class ChatRequest(BaseModel):
    message: str
    context: str = ""

@app.post("/chat")
def chat_tutor(req: ChatRequest):
    msg = req.message.lower()
    
    # Simple Keyword matching for better mock experience
    if "python" in msg:
        return {"reply": "Python is versatile! It's great for AI, Data Science, and Backend development. Check out our 'Intro to Python' course."}
    
    if "javascript" in msg or "js" in msg:
        return {"reply": "JavaScript is the language of the web. You can build full-stack apps with Node.js and React!"}
    
    if "react" in msg or "frontend" in msg:
        return {"reply": "React is a powerful library for building user interfaces. Focus on Components, Props, and State hooks."}
    
    if "node" in msg or "backend" in msg or "express" in msg:
        return {"reply": "Node.js allows you to run JavaScript on the server. It's event-driven and great for scalable APIs."}

    if "db" in msg or "database" in msg or "sql" in msg or "prisma" in msg:
        return {"reply": "Databases are essential. We use Prisma with PostgreSQL in this platform. It makes data modeling easy!"}
    
    if "quiz" in msg or "test" in msg:
        return {"reply": "Quizzes help reinforce your memory. Don't worry if you get some wrong; that's part of learning!"}

    if "hi" in msg or "hello" in msg or "hey" in msg:
         return {"reply": "Hello there! ready to learn something new today?"}

    # Default responses if no keyword matches
    import random
    defaults = [
        "That's an interesting topic. I can help you search for more modules on that.",
        "I'm your AI Tutor. Could you be more specific so I can guide you better?",
        "Keep going! Consistency is key to mastering these concepts.",
        "I'm here to support your learning journey. Try asking about a specific language or course.",
        "Interesting! Tell me more about what you're working on."
    ]
    
    return {"reply": random.choice(defaults)}

class EmotionRequest(BaseModel):
    image: str # Base64 encoded image

import random
@app.post("/analyze-emotion")
def analyze_emotion(req: EmotionRequest):
    # Mock CV Analysis
    emotions = ["Focused", "Confused", "Bored", "Excited"]
    detected = random.choice(emotions)
    return {"emotion": detected, "confidence": 0.89}

from google import genai
import json

# Configure Gemini
api_key = os.getenv("GEMINI_API_KEY")
client = None
if api_key:
    client = genai.Client(api_key=api_key)

class CourseGenerateRequest(BaseModel):
    topic: str
    description: str = ""

@app.post("/generate-course")
def generate_course(req: CourseGenerateRequest):
    prompt = f"""
    Create a complete, structured course on the topic: {req.topic}.
    Description: {req.description}
    
    Structure the response as a JSON object with the following schema:
    {{
        "title": "Course Title",
        "description": "Comprehensive course description",
        "modules": [
            {{
                "title": "Module Title",
                "lessons": [
                    {{
                        "title": "Lesson Title",
                        "content": "Detailed educational content in markdown format",
                        "type": "text" 
                    }}
                ]
            }}
        ]
    }}
    
    Ensure at least 3 modules and 3 lessons per module.
    For each lesson 'content', provide EXTREMELY DETAILED educational text (at least 6-8 paragraphs) in markdown format. 
    Include:
    - Real-world analogies
    - Code snippets (if technical)
    - Common pitfalls
    - "Pro Tips" section
    
    Include a "finalExam" object with:
    - "title": string
    - "passingScore": 70 (integer)
    - "questions": array of objects
    
    CRITICAL: The exam must have **20 UNIQUE, CHALLENGING** multiple-choice questions.
    The questions should be randomized in concept and not simple definitive definitions.
    
    Each question must have:
    - "text": string
    - "options": list of strings (4 options)
    - "correctAnswer": string (must be one of the options)
    
    Return ONLY valid JSON.
    Structure:
    {{
        "title": "...",
        "description": "...",
        "modules": [...],
        "finalExam": {{
            "title": "Final Exam",
            "passingScore": 70,
            "questions": [
                {{ "text": "...", "options": ["A", "B", "C", "D"], "correctAnswer": "A" }}
            ]
        }}
    }}
    """
    
    if client:
        try:
            response = client.models.generate_content(
                model="gemini-1.5-flash",
                contents=prompt
            )
            # Basic JSON cleanup in case of markdown blocks
            text = response.text.replace("```json", "").replace("```", "").strip()
            return json.loads(text)
        except Exception as e:
            import traceback
            with open("ai_server_error.log", "w") as f:
                f.write(str(e) + "\n" + traceback.format_exc())
            print(f"Gemini Error logged: {str(e)}")
            # Fall through to mock
    
    # Robust Mock for demonstration if API key missing
    
    # Smart Content Generator
    def generate_lesson_content(title, topic):
        title_lower = title.lower()
        
        # 1. History & Intro
        if any(x in title_lower for x in ['history', 'intro', 'what is', 'evolution', 'overview']):
            return f"""# {title}

## The Genesis of {topic}
Every great technology has a story. **{topic}** didn't just appear overnight; it was born out of a necessity to solve specific problems that existing tools couldn't handle.

### Timeline of Innovation
- **Early Days**: The initial concepts were theoretical.
- **The Breakthrough**: A key development changed everything.
- **Modern Era**: Today, {topic} is a cornerstone of the industry.

### Why It Matters
Understanding the history helps us appreciate the design decisions. Why does it work this way? Because previous attempts failed at X, Y, and Z.

> "Those who cannot remember the past are condemned to repeat it."

### Key Takeaways
- {topic} evolved from earlier systems.
- It solves scalability and complexity issues.
- It is now an industry standard.
(Generated by Smart AI Mock)
"""

        # 2. Setup & Environment
        elif any(x in title_lower for x in ['setup', 'install', 'environment', 'config', 'cli']):
            return f"""# {title}

## Laying the Foundation
Before we can build, we must prepare our tools. Setting up a robust development environment for **{topic}** is critical for productivity.

### Step-by-Step Installation

#### 1. System Requirements
Ensure you have the latest OS updates. {topic} works best on Unix-based systems but has excellent Windows support via WSL.

#### 2. The Command Line
Open your terminal and run:
```bash
# Install the core runtime
npm install -g {topic.replace(' ', '-').lower()}-cli

# Verify installation
{topic.split(' ')[0].lower()} --version
```

### IDE Configuration
We recommend **VS Code** with the official {topic} extension. This provides:
- Syntax Highlighting
- Intelligent Code Completion
- Real-time Error Checking

### Troubleshooting
If you see `command not found`, check your PATH environment variable.
(Generated by Smart AI Mock)
"""

        # 3. Core Concepts / Basics
        elif any(x in title_lower for x in ['core', 'basic', 'syntax', 'variable', 'function', 'type']):
            return f"""# {title}

## The Building Blocks
Mastering the syntax of **{topic}** is like learning the grammar of a new language. Once you know the rules, you can write poetry.

### Key Concepts

#### 1. Definitions
In {topic}, everything revolves around **Objects** and **Functions**. 
- **Variable**: A container for value.
- **Function**: A reusable block of logic.

#### 2. Syntax Example
Let's look at a simple example:

```javascript
// Defining a simple function in {topic} style
function calculateGrowth(input) {{
    const rate = 1.5;
    return input * rate;
}}
```

### Best Practices
- **Naming**: Use camelCase for variables.
- **Comments**: Explain 'why', not 'what'.
- **Consistency**: Stick to one style guide.

### Summary
These primitives are simple, but they combine to create complex systems. Practice writing them until it becomes muscle memory.
(Generated by Smart AI Mock)
"""

        # 4. Advanced / Architecture
        elif any(x in title_lower for x in ['advanced', 'architecture', 'pattern', 'scale', 'optimiz']):
            return f"""# {title}

## Engineering at Scale
When you move beyond simple scripts, structure becomes everything. **{topic}** provides powerful architectural patterns to handle complexity.

### The MVC Pattern
Model-View-Controller is the gold standard here.
1.  **Model**: Manages data and logic.
2.  **View**: Renders the UI.
3.  **Controller**: Handles user input.

### Performance Optimization
Speed is a feature. To optimize {topic}:
- **Caching**: Store expensive results.
- **Lazy Loading**: Load only what you need.
- **Concurrency**: Do multiple things at once.

### Real-World Scenario
Imagine handling 1 million users. A naive implementation would crash. Using {topic}'s advanced concurrency model, we can handle the load with minimal resources.

```python
# Pseudo-code for scalable architecture
class LoadBalancer:
    def distribute(self, request):
        server = self.get_least_busy()
        server.process(request)
```
(Generated by Smart AI Mock)
"""

        # Default / Project
        else:
            return f"""# {title}

## Practical Application
Theory is useful, but practice is essential. In this lesson, we apply **{topic}** to a real-world problem.

### The Objective
We are going to build a module that processes data efficiently.

### Implementation Steps
1.  **Initialize**: Set up the project structure.
2.  **Develop**: Write the core logic.
3.  **Test**: Verify edge cases.

### Code Walkthrough
```javascript
const project = new {topic}Project();
project.start();
console.log("System Online");
```

### Conclusion
You have now seen {topic} in action. Try extending this example by adding user authentication.
(Generated by Smart AI Mock)
"""

    return {
        "title": f"Complete {req.topic} Masterclass",
        "description": f"A deep dive into {req.topic} covering everything from basics to advanced concepts.",
        "modules": [
            {
                "title": "Fundamentals & Introduction",
                "lessons": [
                    { "title": f"What is {req.topic}?", "content": generate_lesson_content(f"What is {req.topic}?", req.topic), "type": "text" },
                    { "title": "History and Evolution", "content": generate_lesson_content("History and Evolution", req.topic), "type": "text" },
                    { "title": "Setting Up Environment", "content": generate_lesson_content("Setting Up Environment", req.topic), "type": "text" }
                ]
            },
            {
                "title": "Core Architecture",
                "lessons": [
                    { "title": "Deep Dive into Components", "content": generate_lesson_content("Deep Dive into Core Components", req.topic), "type": "text" },
                    { "title": "Building your first Project", "content": generate_lesson_content("Building your first Project", req.topic), "type": "text" },
                    { "title": "State Management", "content": generate_lesson_content("State Management", req.topic), "type": "text" }
                ]
            },
            {
                "title": "Advanced Mastery",
                "lessons": [
                    { "title": "Optimization Techniques", "content": generate_lesson_content("Optimization Techniques", req.topic), "type": "text" },
                    { "title": "Future Trends", "content": generate_lesson_content("Future Trends", req.topic), "type": "text" },
                    { "title": "Security Best Practices", "content": generate_lesson_content("Security Best Practices", req.topic), "type": "text" }
                ]
            }
        ],
        "finalExam": {
            "title": f"{req.topic} Certification Exam",
            "passingScore": 70,
            "questions": [
                { "text": f"What is a key benefit of {req.topic}?", "options": ["Efficiency", "Complexity", "Slowness", "None"], "correctAnswer": "Efficiency" },
                { "text": "Which of these is NOT related?", "options": ["Concept A", "Concept B", "Random Word", "Concept C"], "correctAnswer": "Random Word" },
                { "text": "What is the industry standard pattern?", "options": ["MVC", "ABC", "XYZ", "123"], "correctAnswer": "MVC" },
                { "text": "How do you handle errors?", "options": ["Try-Catch", "Ignore them", "Print 'Error'", "Delete code"], "correctAnswer": "Try-Catch" },
                { "text": "What is the complexity of O(n)?", "options": ["Linear", "Constant", "Quadratic", "Exponential"], "correctAnswer": "Linear" },
                { "text": "Which DB is NoSQL?", "options": ["MongoDB", "MySQL", "PostgreSQL", "SQLite"], "correctAnswer": "MongoDB" },
                { "text": "What does HTTP stand for?", "options": ["HyperText Transfer Protocol", "High Transfer Text Protocol", "Hyper Tool Protocol", "None"], "correctAnswer": "HyperText Transfer Protocol" },
                { "text": "What is a variable?", "options": ["A container for data", "A number", "A string", "A function"], "correctAnswer": "A container for data" },
                { "text": "Which is a frontend framework?", "options": ["React", "Django", "Flask", "Spring"], "correctAnswer": "React" },
                { "text": "What is Docker?", "options": ["Containerization tool", "Code editor", "Database", "OS"], "correctAnswer": "Containerization tool" },
                { "text": "What is Git?", "options": ["Version Control", "Video Game", "Chat App", "Food"], "correctAnswer": "Version Control" },
                { "text": "What is CI/CD?", "options": ["Continuous Integration/Deployment", "Code Internal/Deploy", "Common Interface", "None"], "correctAnswer": "Continuous Integration/Deployment" },
                { "text": "What is an API?", "options": ["Application Programming Interface", "Apple Pie Ingredients", "Automated Program Input", "None"], "correctAnswer": "Application Programming Interface" },
                { "text": "What is JSON?", "options": ["JavaScript Object Notation", "Java System Object", "Just Some Object", "None"], "correctAnswer": "JavaScript Object Notation" },
                { "text": "What is REST?", "options": ["Representational State Transfer", "Resting State", "Real Standards", "None"], "correctAnswer": "Representational State Transfer" },
                { "text": "Which is a compiled language?", "options": ["C++", "Python", "JavaScript", "Ruby"], "correctAnswer": "C++" },
                { "text": "What is Agile?", "options": ["Software Dev Methodology", "A Gym", "A Tool", "A Language"], "correctAnswer": "Software Dev Methodology" },
                { "text": "What is a bug?", "options": ["An error in code", "An insect", "A feature", "None"], "correctAnswer": "An error in code" },
                { "text": "What is the cloud?", "options": ["Remote servers", "The sky", "Water vapor", "None"], "correctAnswer": "Remote servers" },
                { "text": "Are you ready to be an expert?", "options": ["Yes", "No", "Maybe", "I hope so"], "correctAnswer": "Yes" }
            ]
        }
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
