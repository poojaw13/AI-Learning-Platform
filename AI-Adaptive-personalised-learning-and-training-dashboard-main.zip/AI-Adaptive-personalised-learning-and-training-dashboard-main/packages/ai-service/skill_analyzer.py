from pydantic import BaseModel
from typing import List

class QuizResult(BaseModel):
    userId: str
    topic: str
    score: float
    totalQuestions: int
    wrongAnswers: List[str] # List of concepts/tags the user got wrong

class SkillGapResponse(BaseModel):
    userId: str
    weaknesses: List[str]
    recommendedDifficulty: float
    suggestedTopics: List[str]

def analyze_gap(data: QuizResult) -> SkillGapResponse:
    # Logic: If partial score is low, identify weaknesses
    weaknesses = data.wrongAnswers
    
    current_difficulty = 1.0
    if data.score < 50:
        current_difficulty = 0.8
    elif data.score > 80:
        current_difficulty = 1.2
    
    suggestions = []
    if "algebra" in [w.lower() for w in weaknesses]:
        suggestions.append("Basic Algebra Review")
    
    return SkillGapResponse(
        userId=data.userId,
        weaknesses=weaknesses,
        recommendedDifficulty=current_difficulty,
        suggestedTopics=suggestions
    )
