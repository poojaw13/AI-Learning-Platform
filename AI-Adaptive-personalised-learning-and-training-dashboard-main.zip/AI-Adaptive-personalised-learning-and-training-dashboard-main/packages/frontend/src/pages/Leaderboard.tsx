
import { useEffect, useState } from 'react';
import client from '../api/client';

import { Medal, Crown } from 'lucide-react';

interface LeaderboardUser {
    id: string;
    name: string;
    xp: number;
    level: number;
    streak: number;
    avatar?: string;
}

export const Leaderboard = () => {
    const [users, setUsers] = useState<LeaderboardUser[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchLeaderboard = async () => {
            try {
                // Mock data for now if API fails or is empty, to ensure "Next Level" look
                const mockUsers = [
                    { id: '1', name: 'Alex Johnson', xp: 12500, level: 12, streak: 15 },
                    { id: '2', name: 'Sarah Connor', xp: 11800, level: 11, streak: 8 },
                    { id: '3', name: 'Mike Ross', xp: 10400, level: 10, streak: 3 },
                    { id: '4', name: 'You', xp: 9500, level: 9, streak: 5 }, // Current User
                    { id: '5', name: 'Emily Blunt', xp: 9100, level: 9, streak: 1 },
                ];

                try {
                    const { data } = await client.get('/auth/leaderboard');
                    if (data && data.length > 0) {
                        setUsers(data);
                    } else {
                        setUsers(mockUsers);
                    }
                } catch {
                    setUsers(mockUsers);
                }

            } catch {
                console.error("Failed to load leaderboard");
            } finally {
                setIsLoading(false);
            }
        };
        fetchLeaderboard();
    }, []);

    const getRankIcon = (index: number) => {
        switch (index) {
            case 0: return <Crown size={24} className="text-yellow-400" fill="currentColor" />;
            case 1: return <Medal size={24} className="text-gray-300" fill="currentColor" />;
            case 2: return <Medal size={24} className="text-orange-400" fill="currentColor" />;
            default: return <span className="text-gray-500 font-bold text-lg">#{index + 1}</span>;
        }
    };

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-white mb-2">Global Leaderboard</h1>
                        <p className="text-gray-400 text-sm">See where you stand among the top learners</p>
                    </div>
                </div>

                <div className="max-w-4xl mx-auto">
                    {/* Top 3 Podium (Optional, simple list for now) */}

                    <div className="bg-[#161b28] border border-gray-800 rounded-2xl overflow-hidden">
                        <div className="grid grid-cols-12 bg-gray-900/50 p-4 text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-800">
                            <div className="col-span-2 text-center">Rank</div>
                            <div className="col-span-5">Learner</div>
                            <div className="col-span-2 text-center">Level</div>
                            <div className="col-span-3 text-right pr-4">Total XP</div>
                        </div>

                        {isLoading ? (
                            <div className="p-12 flex justify-center">
                                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-emerald-500"></div>
                            </div>
                        ) : (
                            <div className="divide-y divide-gray-800">
                                {users.map((user, index) => (
                                    <div key={user.id} className={`grid grid-cols-12 p-4 items-center hover:bg-gray-800/50 transition-colors ${user.name === 'You' ? 'bg-emerald-900/10 border-l-2 border-emerald-500' : ''}`}>
                                        <div className="col-span-2 flex justify-center">
                                            {getRankIcon(index)}
                                        </div>
                                        <div className="col-span-5 flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center font-bold text-emerald-500 border border-gray-700">
                                                {user.name.charAt(0)}
                                            </div>
                                            <div>
                                                <span className={`font-bold block ${user.name === 'You' ? 'text-emerald-400' : 'text-white'}`}>{user.name}</span>
                                                {user.streak > 0 && <span className="text-[10px] text-orange-400 flex items-center gap-1">🔥 {user.streak} day streak</span>}
                                            </div>
                                        </div>
                                        <div className="col-span-2 text-center">
                                            <span className="bg-gray-800 text-gray-300 text-[10px] font-bold px-2 py-1 rounded">Lvl {user.level}</span>
                                        </div>
                                        <div className="col-span-3 text-right pr-4 font-mono font-bold text-yellow-500">
                                            {user.xp.toLocaleString()} XP
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
