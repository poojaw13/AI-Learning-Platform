import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import client from '../../api/client';
import { toast } from 'react-toastify';

import { Sparkles, Zap, Target, Play, Fingerprint, Shield, History, ChevronRight } from 'lucide-react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

interface DNA {
    style: string;
    bestTime: string;
    averageFocus: number;
}

interface Recovery {
    active: boolean;
    title: string;
    motivation: string;
    recommendations: string[];
    difficultyAdjustment: string;
}

interface Mastery {
    concept: string;
    score: number;
}

export const AdvancedStudentIQ = () => {
    const navigate = useNavigate();
    const [dna, setDna] = useState<DNA | null>(null);
    const [recovery, setRecovery] = useState<Recovery | null>(null);
    const [mastery, setMastery] = useState<Mastery[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStudentData = async () => {
            try {
                const [dnaRes, recoveryRes, masteryRes] = await Promise.all([
                    client.get('/student-iq/dna'),
                    client.get('/student-iq/recovery'),
                    client.get('/student-iq/mastery')
                ]);
                setDna(dnaRes.data);
                setRecovery(recoveryRes.data);
                setMastery(masteryRes.data);
            } catch (error) {
                console.error("Failed to fetch student IQ data", error);
                toast.error("Failed to load your learning data. Please try again.");
            } finally {
                setLoading(false);
            }
        };
        fetchStudentData();
    }, []);

    const masteryData = mastery.map(m => ({
        subject: m.concept,
        A: m.score * 100,
        fullMark: 100
    }));

    const handleInsightClick = (type: string) => {
        if (type === 'spaced') {
            toast.info("Starting Spaced Repetition Session for 'React Hooks'...");
            setTimeout(() => navigate('/student/dashboard'), 1500);
        } else if (type === 'quick') {
            toast.success("Loading Quick Win Module: 'Props'...");
            setTimeout(() => navigate('/student/dashboard'), 1500);
        }
    };

    if (loading) return <div className="min-h-screen bg-[#0f111a] text-white flex items-center justify-center italic-none">Scanning Learning DNA...</div>;

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-3xl font-black text-white flex items-center gap-3 italic-none uppercase tracking-tighter">
                        <Sparkles className="text-emerald-400" size={32} />
                        Intelligence Console
                    </h1>
                    <p className="text-gray-400 mt-2">Comprehensive behavioral patterns and cognitive mastery analysis.</p>
                </div>

                {/* Main Content */}
                <div className="grid grid-cols-12 gap-8">

                    {/* Recovery Mode / Welcome Back */}
                    {recovery?.active && (
                        <div className="col-span-12 bg-gradient-to-r from-emerald-600/20 to-blue-600/20 border border-emerald-500/30 rounded-3xl p-8 mb-4 relative overflow-hidden group">
                            <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
                                <div className="max-w-2xl">
                                    <div className="inline-flex items-center gap-2 bg-emerald-500 text-[10px] font-black uppercase px-2 py-1 rounded mb-4">
                                        <Zap size={12} /> Recovery Mode Active
                                    </div>
                                    <h2 className="text-3xl font-black text-white mb-2 italic-none">{recovery.title}</h2>
                                    <p className="text-emerald-100/70 mb-6">{recovery.motivation}</p>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                        {recovery.recommendations.map((rec: string, i: number) => (
                                            <div key={i} className="flex gap-3 items-center bg-black/30 p-4 rounded-2xl border border-white/5">
                                                <Target size={18} className="text-emerald-400" />
                                                <span className="text-sm text-gray-200">{rec}</span>
                                            </div>
                                        ))}
                                    </div>
                                    <button className="bg-white text-emerald-900 font-black px-8 py-3 rounded-2xl flex items-center gap-2 hover:scale-105 transition-transform" onClick={() => navigate('/student/dashboard')}>
                                        <Play size={18} fill="currentColor" /> Resume Learning Path
                                    </button>
                                </div>
                                <div className="hidden lg:block">
                                    <div className="w-48 h-48 rounded-full border-8 border-emerald-500/10 flex items-center justify-center">
                                        <div className="text-center font-black">
                                            <span className="block text-4xl text-emerald-400">-{recovery.difficultyAdjustment.split(' ')[2]}</span>
                                            <span className="text-[10px] text-emerald-500 uppercase">Difficulty</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Left Column: DNA & Mastery */}
                    <div className="col-span-12 lg:col-span-8 space-y-8">
                        {/* Learning DNA Card */}
                        <div className="bg-[#161b28] rounded-3xl border border-gray-800 p-8 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                                <Fingerprint size={120} />
                            </div>
                            <h3 className="text-xl font-black text-white mb-8 flex items-center gap-3 uppercase tracking-widest text-sm">
                                <Fingerprint className="text-blue-400" size={20} /> Behavioral Learning DNA
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                <div className="text-center p-6 bg-gray-900/50 rounded-3xl border border-gray-800">
                                    <span className="text-gray-500 text-[10px] font-bold uppercase block mb-2 tracking-widest">Cognitive Style</span>
                                    <p className="text-2xl font-black text-white">{dna?.style || "Balanced"}</p>
                                    <p className="text-xs text-blue-400 mt-2">Visuo-Spatial Primary</p>
                                </div>
                                <div className="text-center p-6 bg-gray-900/50 rounded-3xl border border-gray-800">
                                    <span className="text-gray-500 text-[10px] font-bold uppercase block mb-2 tracking-widest">Temporal Peak</span>
                                    <p className="text-2xl font-black text-white">{dna?.bestTime || "Night"}</p>
                                    <p className="text-xs text-purple-400 mt-2">Optimal 10PM - 1AM</p>
                                </div>
                                <div className="text-center p-6 bg-gray-900/50 rounded-3xl border border-gray-800">
                                    <span className="text-gray-500 text-[10px] font-bold uppercase block mb-2 tracking-widest">Focus Resilience</span>
                                    <p className="text-2xl font-black text-white">{dna?.averageFocus || 0}%</p>
                                    <p className="text-xs text-emerald-400 mt-2">Deep Work Oriented</p>
                                </div>
                            </div>
                        </div>

                        {/* Mastery Radar */}
                        <div className="bg-[#161b28] rounded-3xl border border-gray-800 p-8">
                            <h3 className="text-xl font-black text-white mb-8 flex items-center gap-3 uppercase tracking-widest text-sm">
                                <Target className="text-red-400" size={20} /> Concept Mastery Profile
                            </h3>
                            <div className="h-[400px] w-full">
                                {masteryData.length > 0 ? (
                                    <ResponsiveContainer width="100%" height="100%">
                                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={masteryData}>
                                            <PolarGrid stroke="#374151" />
                                            <PolarAngleAxis dataKey="subject" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                                            <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                                            <Radar
                                                name="Mastery"
                                                dataKey="A"
                                                stroke="#10b981"
                                                fill="#10b981"
                                                fillOpacity={0.4}
                                            />
                                        </RadarChart>
                                    </ResponsiveContainer>
                                ) : (
                                    <div className="h-full flex flex-col items-center justify-center text-gray-500">
                                        <Shield size={48} className="mb-4 opacity-20" />
                                        <p>Complete quizzes to build your mastery map.</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Right Column: Mini Panels */}
                    <div className="col-span-12 lg:col-span-4 space-y-8">
                        {/* Cert Readiness */}
                        <div className="bg-[#161b28] rounded-3xl border border-gray-800 p-6">
                            <h3 className="font-bold text-white mb-6 uppercase text-[10px] tracking-widest">Certification Readiness</h3>
                            <div className="text-center py-4">
                                <div className="inline-block relative">
                                    <svg className="w-32 h-32 transform -rotate-90">
                                        <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-gray-800" />
                                        <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="8" fill="transparent" strokeDasharray={Math.PI * 2 * 58} strokeDashoffset={Math.PI * 2 * 58 * (1 - 0.72)} className="text-emerald-500" strokeLinecap="round" />
                                    </svg>
                                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                                        <span className="text-3xl font-black text-white">72%</span>
                                        <span className="text-[8px] text-gray-500 uppercase">Score</span>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400 mt-4 leading-relaxed">
                                    Gain <span className="text-emerald-400 font-bold">18% more mastery</span> in Data Structures to unlock certification.
                                </p>
                            </div>
                        </div>

                        {/* Recent Insights */}
                        <div className="bg-[#161b28] rounded-3xl border border-gray-800 p-6">
                            <h3 className="font-bold text-white mb-4 uppercase text-[10px] tracking-widest">AI Actionable Insights</h3>
                            <div className="space-y-4">
                                <div
                                    className="flex gap-4 group cursor-pointer p-2 rounded-xl hover:bg-white/5 transition-colors"
                                    onClick={() => handleInsightClick('spaced')}
                                >
                                    <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500">
                                        <History size={20} />
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-xs font-bold text-white">Spaced Repetition Due</p>
                                        <p className="text-[10px] text-gray-500">React Hooks is fading from memory. Revise now.</p>
                                    </div>
                                    <ChevronRight size={14} className="text-gray-700 self-center" />
                                </div>
                                <div
                                    className="flex gap-4 group cursor-pointer p-2 rounded-xl hover:bg-white/5 transition-colors"
                                    onClick={() => handleInsightClick('quick')}
                                >
                                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-500">
                                        <Zap size={20} />
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-xs font-bold text-white">Quick Win Detected</p>
                                        <p className="text-[10px] text-gray-500">Master 'Props' in 5 mins to increase DNA focus.</p>
                                    </div>
                                    <ChevronRight size={14} className="text-gray-700 self-center" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
