import { useNavigate } from 'react-router-dom';
import { Button } from '../components/Button';
import { Brain, TrendingUp, Users, Shield, Award, Code, Database, Zap } from 'lucide-react';

export const LandingPage = () => {
    const navigate = useNavigate();

    return (
        <div className="min-h-screen bg-transparent text-white font-sans selection:bg-indigo-500 selection:text-white overflow-hidden relative">
            {/* Background Blobs */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-200/40 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute top-[20%] right-[-10%] w-[40%] h-[40%] bg-cyan-200/40 rounded-full blur-3xl animate-pulse delay-1000"></div>
                <div className="absolute bottom-[-10%] left-[20%] w-[60%] h-[60%] bg-purple-200/30 rounded-full blur-3xl animate-pulse delay-2000"></div>
            </div>

            {/* Navigation */}
            <nav className="fixed w-full z-50 bg-[#111827] border-b border-gray-800 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                    <div className="flex items-center gap-2 cursor-pointer group" onClick={() => navigate('/')}>
                        <div className="bg-gradient-to-tr from-blue-600 to-purple-600 p-2 rounded-xl shadow-lg shadow-blue-500/20 group-hover:scale-110 transition-transform duration-300">
                            <Brain size={20} className="text-white" />
                        </div>
                        <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">AdaptiveLearn</span>
                    </div>
                    <div className="flex gap-4">
                        <button onClick={() => navigate('/login')} className="text-sm font-bold text-gray-300 hover:text-white transition-colors">Log In</button>
                        <Button onClick={() => navigate('/register')} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:shadow-purple-500/30 text-white border-none shadow-lg shadow-blue-500/20 hover:-translate-y-0.5 transition-all">Get Started</Button>
                    </div>
                </div>
            </nav>

            {/* Hero Section */}
            <main className="pt-32 pb-16 px-4">
                <div className="max-w-7xl mx-auto text-center">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-xs font-bold mb-8 uppercase tracking-wider shadow-sm animate-fade-in">
                        <Zap size={12} fill="currentColor" /> Final Year Project 2025
                    </div>
                    <h1 className="text-5xl md:text-7xl font-extrabold text-white tracking-tight mb-8 leading-tight drop-shadow-sm">
                        The Future of <br />
                        <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 animate-gradient">Adaptive Education</span>
                    </h1>
                    <p className="max-w-2xl mx-auto text-lg text-gray-300 mb-10 leading-relaxed font-medium">
                        A next-generation learning platform driven by AI. We combine real-time analytics,
                        personalized curriculums, and gamification to create the ultimate educational experience.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                        <Button size="lg" onClick={() => navigate('/register')} className="bg-gradient-to-r from-blue-600 to-purple-600 border-none text-white shadow-xl shadow-blue-500/20 hover:shadow-purple-500/40 text-lg px-8 py-4 h-auto hover:-translate-y-1 transition-all">Start Learning Now</Button>
                        <Button size="lg" variant="secondary" onClick={() => navigate('/demo')} className="bg-gray-800 text-white border-gray-700 hover:bg-gray-700 text-lg px-8 py-4 h-auto shadow-sm hover:shadow-md transition-all">View Demo Dashboard</Button>
                    </div>
                </div>

                {/* Platform Impact Stats */}
                <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto border-t border-b border-gray-800 py-12 bg-gray-900 rounded-3xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="text-center group">
                        <div className="text-4xl font-bold text-blue-600 mb-2 group-hover:scale-110 transition-transform">85%</div>
                        <div className="text-sm text-gray-400 uppercase tracking-widest font-bold">Completion Rate</div>
                    </div>
                    <div className="text-center group">
                        <div className="text-4xl font-bold text-purple-600 mb-2 group-hover:scale-110 transition-transform">500+</div>
                        <div className="text-sm text-gray-400 uppercase tracking-widest font-bold">AI Modules Generated</div>
                    </div>
                    <div className="text-center group">
                        <div className="text-4xl font-bold text-emerald-600 mb-2 group-hover:scale-110 transition-transform">24/7</div>
                        <div className="text-sm text-gray-400 uppercase tracking-widest font-bold">System Uptime</div>
                    </div>
                </div>
            </main>

            {/* Modules Grid */}
            <section className="py-24 bg-[#111827] border-y border-gray-800 relative">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/10 to-transparent pointer-events-none"></div>
                <div className="max-w-7xl mx-auto px-4">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl font-bold text-white mb-4">Comprehensive Learning Ecosystem</h2>
                        <p className="text-gray-400 max-w-2xl mx-auto">Built with advanced modules to serve Students, Teachers, and Administrators with state-of-the-art AI technology.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <ModuleCard
                            icon={<Brain size={32} className="text-purple-600" />}
                            bgClass="bg-gradient-to-br from-purple-100 to-fuchsia-100"
                            title="AI Personalization Engine"
                            desc="Uses GPT-4o to analyze learning patterns and generate custom quizzes and study paths in real-time."
                        />
                        <ModuleCard
                            icon={<TrendingUp size={32} className="text-blue-600" />}
                            bgClass="bg-gradient-to-br from-blue-100 to-cyan-100"
                            title="Real-Time Analytics"
                            desc="Admin and Teacher dashboards powered by live data streams. Track at-risk students and platform usage instantly."
                        />
                        <ModuleCard
                            icon={<Award size={32} className="text-amber-600" />}
                            bgClass="bg-gradient-to-br from-amber-100 to-orange-100"
                            title="Gamification System"
                            desc="Leaderboards, XP, and Achievement badges (e.g. 'Bug Hunter', 'Speed Demon') to maximize engagement."
                        />
                        <ModuleCard
                            icon={<Users size={32} className="text-emerald-600" />}
                            bgClass="bg-gradient-to-br from-emerald-100 to-teal-100"
                            title="Teacher Portal"
                            desc="Dedicated interface for instructors to manage classes, view student progress, and intervene early."
                        />
                        <ModuleCard
                            icon={<Shield size={32} className="text-rose-600" />}
                            bgClass="bg-gradient-to-br from-rose-100 to-pink-100"
                            title="Admin Control Center"
                            desc="Full system oversight with user management, AI fairness monitoring, and system health checks."
                        />
                        <ModuleCard
                            icon={<Code size={32} className="text-cyan-600" />}
                            bgClass="bg-gradient-to-br from-cyan-100 to-sky-100"
                            title="Study Communities"
                            desc="Peer-to-peer learning groups with discussion forums and collaborative resource sharing."
                        />
                    </div>
                </div>
            </section>

            {/* Tech Stack */}
            <section className="py-20 bg-[#111827]">
                <div className="max-w-7xl mx-auto px-4 text-center">
                    <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-10">Powering The Platform</p>
                    <div className="flex flex-wrap justify-center gap-8 md:gap-16 opacity-70 grayscale hover:grayscale-0 transition-all duration-500">
                        <TechBadge label="React 18" icon={<Code size={20} />} />
                        <TechBadge label="TypeScript" icon={<Code size={20} />} />
                        <TechBadge label="Node.js" icon={<Database size={20} />} />
                        <TechBadge label="PostgreSQL" icon={<Database size={20} />} />
                        <TechBadge label="OpenAI API" icon={<Brain size={20} />} />
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="border-t border-gray-800 bg-[#111827] py-12">
                <div className="max-w-7xl mx-auto px-4 text-center">
                    <h3 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 mb-2">AdaptiveLearn</h3>
                    <p className="text-slate-500 text-sm mb-6">Final Year Capstone Project • 2025</p>
                    <div className="flex justify-center gap-6 text-sm text-slate-500 font-medium">
                        <a href="#" className="hover:text-blue-600 transition-colors">Documentation</a>
                        <a href="#" className="hover:text-blue-600 transition-colors">API Reference</a>
                        <a href="#" className="hover:text-blue-600 transition-colors">GitHub Repo</a>
                    </div>
                </div>
            </footer>
        </div>
    );
};

const ModuleCard = ({ icon, title, desc, bgClass }: { icon: React.ReactNode; title: string; desc: string; bgClass: string }) => {
    return (
        <div className="bg-gray-900 p-8 rounded-2xl border border-gray-800 hover:border-indigo-500 hover:bg-gray-800 transition-all hover:translate-y-[-4px] hover:shadow-xl group shadow-sm">
            <div className={`mb-6 p-4 rounded-2xl ${bgClass} inline-block group-hover:scale-110 transition-transform duration-300 shadow-sm`}>
                {icon}
            </div>
            <h3 className="text-xl font-bold text-white mb-3 group-hover:text-indigo-400 transition-colors">{title}</h3>
            <p className="text-gray-400 leading-relaxed text-sm">{desc}</p>
        </div>
    );
}

const TechBadge = ({ label, icon }: { label: string, icon: React.ReactNode }) => (
    <div className="flex items-center gap-2 text-gray-400 font-bold text-lg">
        {icon} <span>{label}</span>
    </div>
);
