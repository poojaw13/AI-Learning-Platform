
import { Button } from '../../components/Button';

export const AboutPage = () => (
    <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">About AdaptiveLearn</h1>
        <p className="text-gray-600">AdaptiveLearn is an AI-powered platform designed to personalize education for every student.</p>
    </div>
);

export const CareerPathsPage = () => (
    <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Explore Career Paths</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border rounded hover:shadow-lg">
                <h3 className="font-bold">Data Scientist</h3>
                <p>Learn Python, SQL, and Machine Learning.</p>
            </div>
            <div className="p-4 border rounded hover:shadow-lg">
                <h3 className="font-bold">Full Stack Developer</h3>
                <p>Master React, Node.js, and Databases.</p>
            </div>
        </div>
    </div>
);

export const FAQPage = () => (
    <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Help & FAQ</h1>
        <details className="mb-4 border p-4 rounded">
            <summary className="font-bold cursor-pointer">How does the AI work?</summary>
            <p className="mt-2 text-gray-600">Our AI analyzes your quiz performance to adjust difficulty dynamically.</p>
        </details>
        <details className="mb-4 border p-4 rounded">
            <summary className="font-bold cursor-pointer">Is it free?</summary>
            <p className="mt-2 text-gray-600">We offer a free tier and a premium certification tier.</p>
        </details>
    </div>
);

export const PricingPage = () => (
    <div className="p-10 max-w-4xl mx-auto text-center">
        <h1 className="text-3xl font-bold mb-8">Simple Pricing</h1>
        <div className="flex justify-center gap-8">
            <div className="border p-8 rounded-xl shadow-sm">
                <h3 className="text-xl font-bold">Free</h3>
                <p className="text-4xl font-bold my-4">$0</p>
                <ul className="text-left space-y-2">
                    <li>✓ Access to courses</li>
                    <li>✓ Basic AI Tutor</li>
                </ul>
            </div>
            <div className="border p-8 rounded-xl shadow-xl bg-blue-50 border-blue-200">
                <h3 className="text-xl font-bold text-blue-600">Pro</h3>
                <p className="text-4xl font-bold my-4">$19</p>
                <ul className="text-left space-y-2">
                    <li>✓ Verified Certificates</li>
                    <li>✓ Advanced AI Insights</li>
                    <li>✓ Unlimited Career Paths</li>
                </ul>
            </div>
        </div>
    </div>
);

export const HowAIWorksPage = () => (
    <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">🧠 How Our AI Works</h1>
        <div className="space-y-6">
            <section>
                <h3 className="text-xl font-bold mb-2">1. Knowledge Graph Mapping</h3>
                <p>We map every concept into a connected graph. If you fail a "React" quiz, we check if your "JavaScript" foundation is strong.</p>
            </section>
            <section>
                <h3 className="text-xl font-bold mb-2">2. Dynamic Difficulty Adjustment (DDA)</h3>
                <p>If you answer correctly instantly, the next question gets harder. If you struggle, we simplify and offer hints.</p>
            </section>
            <section>
                <h3 className="text-xl font-bold mb-2">3. Emotion Detection</h3>
                <p>Our optional webcam feature detects confusion or fatigue and suggests breaks or easier content automatically.</p>
            </section>
        </div>
    </div>
);

export const LegalPage = () => (
    <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Privacy & Terms</h1>
        <p className="mb-4"><strong>Data Privacy:</strong> We do not sell your data. Your webcam images for emotion detection are processed locally (or securely in RAM) and never stored.</p>
        <p><strong>Terms of Use:</strong> By using AdaptiveLearn, you agree to...</p>
    </div>
);

export const ContactPage = () => (
    <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Contact Support</h1>
        <form className="space-y-4 max-w-lg">
            <input type="email" placeholder="Your Email" className="w-full p-2 border rounded" />
            <textarea placeholder="How can we help?" className="w-full p-2 border rounded h-32"></textarea>
            <Button>Send Message</Button>
        </form>
    </div>
);

export const CertificationsPage = () => (
    <div className="p-10 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">📜 Verified Certifications</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border p-6 rounded-xl hover:shadow-lg bg-white">
                <div className="h-40 bg-gray-100 mb-4 rounded flex items-center justify-center text-4xl">🎓</div>
                <h3 className="font-bold text-xl">Full Stack Developer</h3>
                <p className="text-gray-500">Industry recognized. Includes React, Node, and SQL.</p>
            </div>
            <div className="border p-6 rounded-xl hover:shadow-lg bg-white">
                <div className="h-40 bg-gray-100 mb-4 rounded flex items-center justify-center text-4xl">🤖</div>
                <h3 className="font-bold text-xl">AI & Data Science</h3>
                <p className="text-gray-500">Master Python, TensorFlow, and Ethics.</p>
            </div>
        </div>
    </div>
);
