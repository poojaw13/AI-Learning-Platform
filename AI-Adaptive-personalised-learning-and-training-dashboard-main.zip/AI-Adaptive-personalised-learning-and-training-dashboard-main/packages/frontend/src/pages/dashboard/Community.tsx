
import React from 'react';

import { Users, MessageCircle, Hash } from 'lucide-react';
import { toast } from 'react-toastify';

export const Community = () => {
    interface Message { id: number; user: string; text: string; time: string; avatar: string; }

    interface Group {
        id: number;
        name: string;
        members: number;
        active: number;
        topic: string;
    }

    // Unique chat history for each group
    const groupChats: Record<number, Message[]> = {
        1: [ // React Developers
            { id: 1, user: "Sarah J.", text: "Has anyone tried the new React compiler?", time: "2:00 PM", avatar: "S" },
            { id: 2, user: "Mike T.", text: "Yes! It's amazing how less useMemo needed.", time: "2:02 PM", avatar: "M" },
            { id: 3, user: "Emma W.", text: "Still waiting for stable release.", time: "2:05 PM", avatar: "E" }
        ],
        2: [ // Python AI/ML
            { id: 1, user: "David K.", text: "PyTorch or TensorFlow for beginners?", time: "1:30 PM", avatar: "D" },
            { id: 2, user: "Lisa M.", text: "Definitely PyTorch. Easier dynamic graphs.", time: "1:35 PM", avatar: "L" },
            { id: 3, user: "Bot", text: "Check out the new 'Intro to PyTorch' module!", time: "1:36 PM", avatar: "B" }
        ],
        3: [ // System Design
            { id: 1, user: "Alex R.", text: "How do you handle 1M WebSocket connections?", time: "11:00 AM", avatar: "A" },
            { id: 2, user: "Senior Dev", text: "Horizontal scaling with a message broker like Redis.", time: "11:15 AM", avatar: "S" },
            { id: 3, user: "Alex R.", text: "Thanks! Reading up on Pub/Sub now.", time: "11:20 AM", avatar: "A" }
        ],
        4: [ // Beginners Hub
            { id: 1, user: "Newbie", text: "I'm stuck on infinite loops in JS.", time: "3:00 PM", avatar: "N" },
            { id: 2, user: "Mentor", text: "Check your exit condition! i++ is usually missing.", time: "3:05 PM", avatar: "M" },
            { id: 3, user: "Newbie", text: "Ah, that was it. Thank you!", time: "3:10 PM", avatar: "N" }
        ]
    };

    const groups = [
        { id: 1, name: "React Developers", members: 1240, active: 45, topic: "Frontend" },
        { id: 2, name: "Python AI/ML", members: 890, active: 120, topic: "Data Science" },
        { id: 3, name: "System Design", members: 2100, active: 56, topic: "Architecture" },
        { id: 4, name: "Beginners Hub", members: 5000, active: 300, topic: "General" }
    ];

    const [activeGroup, setActiveGroup] = React.useState<Group>(groups[0]);
    const [messages, setMessages] = React.useState<Message[]>(groupChats[1]);
    const [newMessage, setNewMessage] = React.useState("");

    const handleJoinGroup = (group: Group) => {
        setActiveGroup(group);
        setMessages(groupChats[group.id] || []);
    };

    const handleSendMessage = () => {
        if (!newMessage.trim()) return;

        const msg = {
            id: Date.now(),
            user: "You",
            text: newMessage,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            avatar: "Y"
        };
        setMessages([...messages, msg]);
        setNewMessage("");

        // Simulate random reply
        setTimeout(() => {
            const groupReplies: Record<number, string[]> = {
                1: ["Have you tried the new compiler features?", "I heard Concurrent Mode is finally maturing.", "Next.js vs Remix - what's your pick?", "Make sure to check the 'Advanced Hooks' workshop.", "Tailwind or CSS Modules for this one?", "Does this work with Vite too?", "Great point about the state management!"],
                2: ["Check out the new PyTorch tutorial in the dashboard.", "Is scikit-learn still relevant for this task?", "LLMs are changing the game so fast.", "Transformers are all you need!", "What's your take on the new NumPy release?", "I prefer Pandas with Polars for larger datasets.", "That's a very efficient way to handle tensors."],
                3: ["Don't forget to account for single points of failure.", "How does this scale across multiple availability zones?", "Redis is great, but have you considered Memcached for this?", "Microservices or Monolith-first for this architecture?", "Interesting approach to eventual consistency.", "Lounge sessions are great for diving deep into this.", "Database sharding might be necessary here."],
                4: ["Don't give up! Coding is all about practice.", "StackOverflow is your best friend here.", "The 'JS Fundamentals' module covers this well.", "MDN Docs are the single source of truth!", "Try console.log()ing every step to understand the flow.", "Welcome to the community! We're here to help.", "That's a very common early mistake, no worries!"]
            };

            const replies = groupReplies[activeGroup.id as number] || ["Great point.", "Totally agree!", "Could you explain that more?"];

            const randomReply = {
                id: Date.now() + 1,
                user: `${activeGroup.name} Bot`,
                text: replies[Math.floor(Math.random() * replies.length)],
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                avatar: "B"
            };
            setMessages(prev => [...prev, randomReply]);
        }, 3000);
    };

    return (
        <div className="bg-transparent font-sans text-slate-900">
            <div className="p-8 h-screen overflow-hidden flex flex-col">
                {/* Header */}
                <div className="flex justify-between items-center mb-6 shrink-0">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 mb-2">Community & Study Groups</h1>
                        <p className="text-gray-500 text-sm">Connect, learn, and grow with fellow students</p>
                    </div>
                </div>

                <div className="grid grid-cols-12 gap-8 flex-1 overflow-hidden">
                    {/* Main Content */}
                    <div className="col-span-8 flex flex-col h-full overflow-hidden">
                        {/* Chat Interface */}
                        <div className="bg-white border border-gray-200 rounded-2xl flex flex-col h-full shadow-sm overflow-hidden">
                            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                                        <Hash size={20} />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-gray-900">{activeGroup.name}</h3>
                                        <p className="text-xs text-gray-500">{activeGroup.active} online • {activeGroup.topic}</p>
                                    </div>
                                </div>
                                <div className="flex -space-x-2">
                                    {[1, 2, 3, 4].map(i => (
                                        <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center text-xs text-gray-500 font-bold">U{i}</div>
                                    ))}
                                    <div className="w-8 h-8 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-xs text-gray-500 font-bold">+40</div>
                                </div>
                            </div>

                            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
                                {messages.map((msg) => (
                                    <div key={msg.id} className={`flex gap-3 ${msg.user === 'You' ? 'flex-row-reverse' : ''}`}>
                                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${msg.user === 'You' ? 'bg-emerald-600 text-white' : 'bg-white border border-gray-200 text-gray-600'}`}>
                                            {msg.avatar}
                                        </div>
                                        <div className={`max-w-[70%] ${msg.user === 'You' ? 'items-end' : 'items-start'} flex flex-col`}>
                                            <div className={`p-3 rounded-2xl text-sm ${msg.user === 'You' ? 'bg-emerald-600 text-white rounded-tr-none' : 'bg-white border border-gray-200 text-gray-700 rounded-tl-none shadow-sm'}`}>
                                                {msg.text}
                                            </div>
                                            <span className="text-[10px] text-gray-400 mt-1 px-1">{msg.user} • {msg.time}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="p-4 bg-white border-t border-gray-100">
                                <div className="relative">
                                    <input
                                        type="text"
                                        placeholder={`Message #${activeGroup.name}...`}
                                        className="w-full bg-gray-50 border border-gray-200 text-gray-700 text-sm rounded-xl pl-4 pr-12 py-3 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                                        value={newMessage}
                                        onChange={(e) => setNewMessage(e.target.value)}
                                        onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                                    />
                                    <button
                                        onClick={handleSendMessage}
                                        className="absolute right-2 top-2 p-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                                    >
                                        <MessageCircle size={16} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Sidebar: Popular Groups */}
                    <div className="col-span-4 space-y-6 h-full overflow-y-auto pb-4 custom-scrollbar">
                        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
                            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <Users size={18} className="text-emerald-600" /> Popular Groups
                            </h3>
                            <div className="space-y-3">
                                {groups.map(group => (
                                    <div
                                        key={group.id}
                                        onClick={() => handleJoinGroup(group)}
                                        className={`flex items-center justify-between p-3 border rounded-xl transition-all cursor-pointer group ${activeGroup?.id === group.id ? 'bg-emerald-50 border-emerald-500/30' : 'bg-gray-50 border-gray-200 hover:border-gray-300 hover:shadow-sm'}`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${activeGroup?.id === group.id ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-200 text-gray-500 group-hover:text-gray-900'}`}>
                                                <Hash size={20} />
                                            </div>
                                            <div>
                                                <h4 className={`font-bold text-sm ${activeGroup?.id === group.id ? 'text-emerald-900' : 'text-gray-900'}`}>{group.name}</h4>
                                                <p className="text-[10px] text-gray-500">{group.members} members • {group.active} online</p>
                                            </div>
                                        </div>
                                        {activeGroup?.id === group.id && <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>}
                                    </div>
                                ))}
                            </div>
                            <button className="w-full mt-4 text-xs font-bold text-gray-500 hover:text-gray-900 py-2 border border-gray-200 rounded-lg hover:bg-gray-100 transition-all">
                                View All Groups
                            </button>
                        </div>

                        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-100 rounded-2xl p-6 text-center shadow-sm">
                            <h4 className="font-bold text-indigo-900 mb-2">Invite Friends</h4>
                            <p className="text-xs text-indigo-700 mb-4">Study together and earn bonus XP for every friend who joins!</p>
                            <button
                                onClick={() => {
                                    navigator.clipboard.writeText("https://adaptivelearn.com/join?ref=user123");
                                    toast.success("Invite link copied to clipboard!");
                                }}
                                className="bg-indigo-600 hover:bg-indigo-700 text-white w-full py-2 rounded-lg font-bold text-sm transition-colors shadow-lg shadow-indigo-200"
                            >
                                Copy Invite Link
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
