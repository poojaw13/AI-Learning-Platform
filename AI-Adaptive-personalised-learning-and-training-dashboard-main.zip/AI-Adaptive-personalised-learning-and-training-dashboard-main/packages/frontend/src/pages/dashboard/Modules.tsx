
import React from 'react';
import { useSearchParams } from 'react-router-dom';

import { BookOpen, Clock } from 'lucide-react';
import client from '../../api/client';

interface Module {
    id: string;
    title: string;
    level: string;
    description: string;
    progress: number;
    duration: string;
    _id?: string;
}

export const Modules = () => {
    const [modules, setModules] = React.useState<Module[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [searchParams] = useSearchParams();
    const searchQuery = searchParams.get('search') || '';

    React.useEffect(() => {
        client.get('/courses') // Assuming /courses serves modules/courses
            .then(res => {
                // Deduplicate logic
                // Deduplicate logic by TITLE (to hide repetitive generations)
                const rawModules = Array.isArray(res.data) ? res.data : [];
                // Use Map where key is lowercase title to ensure uniqueness
                const uniqueModules = Array.from(new Map(rawModules.map((m: Module) => [m.title.toLowerCase().trim(), m])).values());
                setModules(uniqueModules as Module[]);
                setLoading(false);
            })
            .catch(err => {
                console.error("Failed to fetch modules:", err);
                setModules([]); // Fallback to empty
                setLoading(false);
            });
    }, []);

    const filteredModules = modules.filter(module =>
        module.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        module.description.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (loading) {
        return (
            <div className="bg-transparent font-sans text-slate-900 flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
            </div>
        );
    }

    return (
        <div className="bg-gray-50 flex-1 font-sans text-gray-900">
            <div className="relative">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 mb-2">Learning Modules</h1>
                        <p className="text-gray-500 text-sm">
                            {searchQuery ? `Search results for "${searchQuery}"` : 'Explore and track your course progress'}
                        </p>
                    </div>
                </div>

                {/* Empty State */}
                {filteredModules.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-[60vh] text-center p-8 bg-white rounded-3xl border border-gray-200 border-dashed">
                        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-6">
                            <BookOpen size={40} className="text-emerald-600" />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">
                            {searchQuery ? `No results for "${searchQuery}"` : 'No Modules Found'}
                        </h2>
                        <p className="text-gray-500 max-w-md mb-8">
                            {searchQuery ? "Try checking for typos or searching for something else." : "It looks like there are no learning modules available yet. Check back later or ask your instructor."}
                        </p>
                        <button
                            onClick={() => window.location.href = '/modules'}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold transition-colors"
                        >
                            {searchQuery ? 'Clear Search' : 'Refresh Modules'}
                        </button>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredModules.map((module) => (
                            <div
                                key={module._id || module.id}
                                onClick={() => window.location.href = `/courses/${module._id || module.id}`}
                                className="group relative bg-white border border-gray-100 rounded-3xl p-6 hover:shadow-2xl hover:shadow-indigo-500/10 hover:-translate-y-2 transition-all duration-300 cursor-pointer overflow-hidden"
                            >
                                <div className="absolute top-0 right-0 p-5 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Clock size={40} className="text-indigo-50" />
                                </div>
                                <div className="flex justify-between items-start mb-6 relative">
                                    <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
                                        <BookOpen size={24} />
                                    </div>
                                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${module.level === 'Beginner' ? 'bg-emerald-100 text-emerald-700' :
                                        module.level === 'Advanced' ? 'bg-rose-100 text-rose-700' :
                                            'bg-blue-100 text-blue-700'
                                        }`}>
                                        {module.level || 'General'}
                                    </span>
                                </div>

                                <h3 className="font-extrabold text-gray-900 text-xl mb-2 line-clamp-1 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-indigo-600 group-hover:to-purple-600 transition-all">
                                    {module.title}
                                </h3>
                                <p className="text-sm text-gray-500 mb-6 line-clamp-2 leading-relaxed h-10">
                                    {module.description || "Master this topic with our comprehensive curriculum."}
                                </p>

                                <div className="mt-auto">
                                    <div className="flex justify-between text-xs font-semibold text-gray-400 mb-2">
                                        <span>Progress</span>
                                        <span className="text-indigo-600">{module.progress || 0}%</span>
                                    </div>
                                    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden mb-4">
                                        <div
                                            className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-1000 ease-out"
                                            style={{ width: `${module.progress || 0}%` }}
                                        ></div>
                                    </div>

                                    <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                                        <div className="flex items-center gap-2 text-xs text-gray-500">
                                            <Clock size={14} className="text-indigo-400" />
                                            <span>{module.duration || '2h 30m'}</span>
                                        </div>
                                        <span className="text-xs font-bold text-indigo-600 group-hover:translate-x-1 transition-transform flex items-center gap-1">
                                            {module.progress ? 'Continue' : 'Start Now'} →
                                        </span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};
