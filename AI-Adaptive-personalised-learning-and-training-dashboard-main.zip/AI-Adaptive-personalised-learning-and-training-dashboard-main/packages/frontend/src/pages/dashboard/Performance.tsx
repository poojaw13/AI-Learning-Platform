

import React from 'react';

import { Search, CheckCircle, AlertTriangle, Target, Calendar } from 'lucide-react';
import client from '../../api/client';

export const Performance = () => {
    interface QuizData {
        recentQuizzes: { title: string; tags: string[]; time: string; score: number; totalQuestions: number; scoreColor: string; barColor: string; completedAt: string }[];
        strongAreas: string[];
        focusAreas: string[];
    }
    const [data, setData] = React.useState<QuizData | null>(null);

    React.useEffect(() => {
        client.get('/analytics/performance')
            .then(res => setData(res.data))
            .catch(err => console.error(err));
    }, []);

    const quizzes = data?.recentQuizzes || [];

    return (
        <div className="space-y-8 animate-fade-in-up">
            <div className="p-8">
                {/* Header with Search (Reused style) */}
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-xl font-bold text-white flex items-center gap-2">
                        📜 Recent Quiz Results
                    </h1>
                    <div className="relative group">
                        <Search className="absolute left-3 top-2.5 text-gray-400 group-focus-within:text-neon-blue transition-colors" size={18} />
                        <input
                            type="text"
                            placeholder="Search..."
                            className="glass-input pl-10 pr-16 py-2 w-64 focus:w-72 focus:border-neon-blue/50"
                        />
                        <span className="absolute right-3 top-2.5 bg-white/5 text-gray-400 text-[10px] px-1.5 py-0.5 rounded border border-white/10">⌘ K</span>
                    </div>
                </div>

                <div className="grid grid-cols-12 gap-8">
                    {/* Main Content Area */}
                    <div className="col-span-8 space-y-4">
                        {quizzes.length > 0 ? (
                            quizzes.map((quiz, idx) => (
                                <div key={idx} className="glass-card p-6 group hover:border-gray-600/50">
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <h3 className="font-bold text-lg text-white mb-2 group-hover:text-neon-blue transition-colors">{quiz.title}</h3>
                                            <div className="flex gap-2">
                                                {quiz.tags.map((tag: string) => (
                                                    <span key={tag} className="text-[10px] bg-white/5 text-gray-300 font-bold px-2 py-1 rounded border border-white/10">
                                                        {tag}
                                                    </span>
                                                ))}
                                                <span className="text-[10px] text-gray-400 flex items-center gap-1 px-2 py-1">
                                                    ⏱️ {quiz.time}
                                                </span>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <span className={`text-xl font-bold ${quiz.scoreColor}`}>{quiz.score}%</span>
                                            <p className="text-[10px] text-gray-500">{Math.round((quiz.score / 100) * quiz.totalQuestions)}/{quiz.totalQuestions} correct</p>
                                        </div>
                                    </div>

                                    <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden mt-3 mb-2">
                                        <div className={`h-full ${quiz.barColor} rounded-full shield-glow`} style={{ width: `${quiz.score}%` }}></div>
                                    </div>
                                    <p className="text-[10px] text-gray-500">{quiz.completedAt}</p>
                                </div>
                            ))
                        ) : (
                            <div className="glass-panel p-12 text-center rounded-2xl border-dashed border-gray-700">
                                <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <Target className="text-gray-600" size={32} />
                                </div>
                                <h3 className="text-lg font-bold text-white mb-2">No quizzes taken yet</h3>
                                <p className="text-gray-400 text-sm mb-6">Complete your first assessment to see your performance metrics.</p>
                                <button className="px-6 py-2 bg-neon-blue text-black font-bold rounded-xl hover:bg-cyan-400 transition-colors">
                                    Start Assessment
                                </button>
                            </div>
                        )}
                    </div>

                    {/* Sidebar Right */}
                    <div className="col-span-4 space-y-6">

                        {/* Strong Areas */}
                        <div className="glass-panel p-5 rounded-2xl">
                            <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                                <span className="text-emerald-400">⭐</span> Strong Areas
                            </h3>
                            <div className="space-y-3">
                                {data?.strongAreas && data.strongAreas.length > 0 ? (
                                    data.strongAreas.map((area: string, idx: number) => (
                                        <div key={idx} className="flex items-center justify-between p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                                            <span className="text-sm font-bold text-emerald-400">{area}</span>
                                            <CheckCircle size={16} className="text-emerald-500" />
                                        </div>
                                    ))
                                ) : (
                                    <p className="text-xs text-center text-gray-500 py-2">No strong areas identified yet.</p>
                                )}
                            </div>
                        </div>

                        {/* Focus Areas */}
                        <div className="glass-panel p-5 rounded-2xl">
                            <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                                <AlertTriangle size={18} className="text-amber-400" /> Focus Areas
                            </h3>
                            <div className="space-y-3">
                                {data?.focusAreas && data.focusAreas.length > 0 ? (
                                    data.focusAreas.map((area: string, idx: number) => (
                                        <div key={idx} className="flex items-center justify-between p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                                            <span className="text-sm font-bold text-amber-400">{area}</span>
                                            <Target size={16} className="text-amber-500" />
                                        </div>
                                    ))
                                ) : (
                                    <p className="text-xs text-center text-gray-500 py-2">No focus areas identified yet.</p>
                                )}
                            </div>
                            {data?.focusAreas && data.focusAreas.length > 0 && (
                                <button className="w-full mt-4 flex items-center justify-center gap-2 text-xs font-bold text-white bg-white/5 hover:bg-white/10 py-2 rounded-lg transition-colors border border-white/10">
                                    <Target size={14} /> Practice Weak Areas
                                </button>
                            )}
                        </div>

                        {/* Monthly Goal */}
                        <div className="glass-panel p-5 rounded-2xl">
                            <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                                <Calendar size={18} className="text-neon-blue" /> Monthly Goal
                            </h3>
                            <div className="text-center py-2">
                                <span className="text-4xl font-bold text-white">75%</span>
                                <p className="text-xs text-gray-400 mt-1">Average quiz score target</p>
                            </div>
                            <div className="w-full bg-gray-800 h-2 rounded-full overflow-hidden mt-3 mb-2">
                                <div className="h-full bg-neon-blue rounded-full shield-glow" style={{ width: '82%' }}></div>
                            </div>
                            <p className="text-[10px] text-center text-neon-blue font-bold">🎉 Goal exceeded! Keep up the great work!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
