
import React from 'react';

import { Brain, MessageSquare, ArrowRight, TrendingUp, AlertTriangle, Zap, Target } from 'lucide-react';
import client from '../../api/client';

export const AIInsights = () => {
    interface Recommendation { id: string | number; title: string; tags: string[]; priorityColor: string; reasoning: string; source: string; time: string; category: string; }
    interface PerformanceInsight { type: 'success' | 'warning' | 'info' | 'purple'; title: string; description: string; action?: string; }

    const [recommendations, setRecommendations] = React.useState<Recommendation[]>([]);
    const [performanceInsights, setPerformanceInsights] = React.useState<PerformanceInsight[]>([]);

    // Quiz Analysis State
    interface RecentQuiz { id: number; title: string; score: number; topic: string; date: string; }
    const [recentQuizzes, setRecentQuizzes] = React.useState<RecentQuiz[]>([]);

    React.useEffect(() => {
        client.get('/analytics/insights')
            .then(res => {
                setRecommendations(res.data.insights || []);
                setPerformanceInsights(res.data.performanceInsights || []);
                setRecentQuizzes(res.data.recentQuizzes || []);
            })
            .catch(err => console.error(err));
    }, []);

    // ... (rest of chat state) ...

    // ... (inside JSX) ...

    {/* Recent Quiz Analysis */ }
    <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
        <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Target size={18} className="text-emerald-600" /> Recent Quiz Analysis
        </h3>
        {recentQuizzes.length > 0 ? (
            <div className="space-y-4">
                {recentQuizzes.map((quiz) => (
                    <div key={quiz.id}>
                        <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-900 font-bold">{quiz.title}</span>
                            <span className={`font-bold ${quiz.score >= 80 ? 'text-emerald-600' : quiz.score >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
                                {quiz.score}%
                            </span>
                        </div>
                        <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden mb-2">
                            <div
                                className={`h-full rounded-full ${quiz.score >= 80 ? 'bg-emerald-500' : quiz.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
                                style={{ width: `${quiz.score}%` }}
                            ></div>
                        </div>
                        <div className="flex gap-2">
                            <span className="text-[9px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded border border-gray-200">
                                {quiz.topic}
                            </span>
                        </div>
                    </div>
                ))}
            </div>
        ) : (
            <div className="text-center py-6">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Target className="text-gray-400" size={18} />
                </div>
                <p className="text-xs text-gray-500">No quizzes taken yet.</p>
            </div>
        )}
    </div>

    // Chat State
    interface ChatMessage { id: number; text: string; sender: 'user' | 'bot'; }
    const [chatInput, setChatInput] = React.useState("");
    const [chatMessages, setChatMessages] = React.useState<ChatMessage[]>([]);
    const [isChatLoading, setIsChatLoading] = React.useState(false);

    const handleChatSubmit = async () => {
        if (!chatInput.trim()) return;

        const userMsg: ChatMessage = { id: Date.now(), text: chatInput, sender: 'user' };
        setChatMessages(prev => [...prev, userMsg]);
        setChatInput("");
        setIsChatLoading(true);

        try {
            const { data } = await client.post('/courses/chat', { message: userMsg.text });
            const botMsg: ChatMessage = { id: Date.now() + 1, text: data.reply || "I'm not sure how to answer that.", sender: 'bot' };
            setChatMessages(prev => [...prev, botMsg]);
        } catch (error) {
            console.error(error);
            setChatMessages(prev => [...prev, { id: Date.now() + 1, text: "Sorry, I'm having trouble connecting to the AI.", sender: 'bot' }]);
        } finally {
            setIsChatLoading(false);
        }
    };

    const getInsightIcon = (type: string) => {
        switch (type) {
            case 'success': return { icon: Target, color: 'text-emerald-600', bg: 'bg-emerald-100' };
            case 'warning': return { icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-100' };
            case 'info': return { icon: Zap, color: 'text-blue-600', bg: 'bg-blue-100' };
            case 'purple': return { icon: Target, color: 'text-purple-600', bg: 'bg-purple-100' };
            default: return { icon: Target, color: 'text-gray-600', bg: 'bg-gray-100' };
        }
    };

    return (
        <div className="bg-transparent font-sans text-slate-900">
            <div className="p-8">
                {/* Header Section */}
                <div className="flex justify-between items-start mb-8">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center border border-emerald-200">
                            <Brain className="text-emerald-600" size={24} />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">AI Learning Assistant</h1>
                            <p className="text-gray-500 text-sm">Personalized recommendations based on your quiz performance and learning patterns</p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-12 gap-8">
                    {/* Main Content Area */}
                    <div className="col-span-8 space-y-8">

                        {/* Recommendations Section */}
                        <section>
                            <h2 className="text-lg font-bold text-emerald-600 mb-4 flex items-center gap-2">
                                <SparklesIcon /> Personalized Recommendations
                            </h2>
                            {recommendations.length > 0 ? (
                                <div className="space-y-4">
                                    {recommendations.map(rec => (
                                        <div key={rec.id} className="bg-white border border-gray-200 rounded-2xl p-6 hover:border-gray-300 transition-all shadow-sm">
                                            <div className="flex justify-between items-start mb-4">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
                                                        <span className="text-lg">🎯</span>
                                                    </div>
                                                    <h3 className="font-bold text-lg text-gray-900">{rec.title}</h3>
                                                </div>
                                                <div className="flex gap-2">
                                                    {rec.tags.map((tag: string, i: number) => (
                                                        <span key={i} className={`text-[10px] font-bold px-2 py-1 rounded border uppercase tracking-wide ${i === 0 ? rec.priorityColor.replace('bg-', 'bg-opacity-20 bg-').replace('text-', 'text-opacity-100 text-') : 'bg-gray-100 text-gray-600 border-gray-200'}`}>
                                                            {tag}
                                                        </span>
                                                    ))}
                                                </div>
                                            </div>

                                            <div className="bg-gray-50 rounded-xl p-4 mb-4 border border-gray-100">
                                                <p className="text-sm text-blue-600 font-medium mb-1">AI Reasoning:</p>
                                                <p className="text-sm text-gray-600 leading-relaxed">{rec.reasoning}</p>
                                            </div>

                                            <div className="flex justify-between items-center text-xs text-gray-500">
                                                <div className="flex gap-4">
                                                    <span className="flex items-center gap-1">⚓ Based on: {rec.source}</span>
                                                    <span className="flex items-center gap-1">⏱️ {rec.time}</span>
                                                    <span className="flex items-center gap-1">📂 {rec.category}</span>
                                                </div>
                                                <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-2 transition-colors">
                                                    Start Learning <ArrowRight size={14} />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="p-8 bg-white border border-gray-200 rounded-2xl text-center text-gray-500">
                                    No recommendations yet. Start learning to generate insights.
                                </div>
                            )}
                        </section>

                        {/* Performance Insights Grid */}
                        <section>
                            <h2 className="text-lg font-bold text-emerald-600 mb-4 flex items-center gap-2">
                                <TrendingUp size={18} /> Performance Insights
                            </h2>
                            {performanceInsights.length > 0 ? (
                                <div className="grid grid-cols-2 gap-4">
                                    {performanceInsights.map((insight, idx) => {
                                        const { icon: Icon, color, bg } = getInsightIcon(insight.type);
                                        return (
                                            <div key={idx} className="bg-white border border-gray-200 rounded-2xl p-5 hover:bg-gray-50 transition-colors shadow-sm">
                                                <div className="flex items-start gap-4">
                                                    <div className={`p-2 ${bg} rounded-lg ${color}`}>
                                                        <Icon size={20} />
                                                    </div>
                                                    <div>
                                                        <h4 className="font-bold text-gray-900 mb-1">{insight.title}</h4>
                                                        <p className="text-xs text-gray-500 leading-relaxed">{insight.description}</p>
                                                        {insight.action && (
                                                            <button className="mt-2 text-[10px] font-bold text-white bg-gray-600 px-3 py-1 rounded hover:bg-gray-500">
                                                                {insight.action}
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            ) : (
                                <div className="p-8 bg-white border border-gray-200 rounded-2xl text-center">
                                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                        <TrendingUp className="text-gray-400" size={24} />
                                    </div>
                                    <p className="text-gray-500 text-sm font-medium">No performance data available yet.</p>
                                    <p className="text-gray-400 text-xs mt-1">Complete quizzes and courses to see AI-generated insights.</p>
                                </div>
                            )}
                        </section>
                    </div>

                    {/* Sidebar Right */}
                    <div className="col-span-4 space-y-6">
                        {/* Ask AI Assistant Widget */}
                        {/* Ask AI Assistant Widget */}
                        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
                            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <MessageSquare size={18} className="text-emerald-600" /> Ask AI Assistant
                            </h3>

                            <div className="bg-gray-50 rounded-xl p-3 mb-4 h-64 overflow-y-auto border border-gray-200 text-xs space-y-3 custom-scrollbar flex flex-col-reverse">
                                {/* Messages (reversed for auto-scroll to bottom behavior if using flex-col-reverse) */}
                                {chatMessages.length === 0 && (
                                    <div className="text-center text-gray-400 mt-10">
                                        <p>Ask me anything about your learning progress!</p>
                                    </div>
                                )}
                                {[...chatMessages].reverse().map((msg) => (
                                    <div key={msg.id} className={`${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
                                        {msg.sender === 'user' ? (
                                            <span className="bg-emerald-600 text-white px-3 py-2 rounded-l-lg rounded-tr-lg inline-block text-left break-words max-w-[90%]">
                                                {msg.text}
                                            </span>
                                        ) : (
                                            <div>
                                                <span className="text-emerald-600 font-bold block mb-1 flex items-center gap-1"><Brain size={12} /> AI Assistant:</span>
                                                <span className="text-gray-600 block bg-white border border-gray-200 px-3 py-2 rounded-r-lg rounded-tl-lg shadow-sm text-left break-words">
                                                    {msg.text}
                                                </span>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>

                            <div className="relative">
                                <input
                                    type="text"
                                    placeholder="Ask about your learning progress..."
                                    className="w-full bg-white border border-gray-200 text-gray-700 text-xs rounded-lg pl-3 pr-10 py-3 focus:outline-none focus:border-emerald-500 shadow-sm disabled:opacity-50"
                                    value={chatInput}
                                    onChange={(e) => setChatInput(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleChatSubmit()}
                                    disabled={isChatLoading}
                                />
                                <button
                                    className={`absolute right-2 top-2 p-1 rounded text-white transition-colors ${isChatLoading ? 'bg-gray-400' : 'bg-emerald-600 hover:bg-emerald-500'}`}
                                    onClick={handleChatSubmit}
                                    disabled={isChatLoading}
                                >
                                    {isChatLoading ? <div className="animate-spin h-3.5 w-3.5 border-2 border-white border-t-transparent rounded-full" /> : <ArrowRight size={14} />}
                                </button>
                            </div>
                        </div>

                        {/* Recent Quiz Analysis */}
                        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
                            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <Target size={18} className="text-emerald-600" /> Recent Quiz Analysis
                            </h3>
                            {recentQuizzes.length > 0 ? (
                                <div className="space-y-4">
                                    {recentQuizzes.map((quiz) => (
                                        <div key={quiz.id}>
                                            <div className="flex justify-between text-xs mb-1">
                                                <span className="text-gray-900 font-bold">{quiz.title}</span>
                                                <span className={`font-bold ${quiz.score >= 80 ? 'text-emerald-600' : quiz.score >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
                                                    {quiz.score}%
                                                </span>
                                            </div>
                                            <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden mb-2">
                                                <div
                                                    className={`h-full rounded-full ${quiz.score >= 80 ? 'bg-emerald-500' : quiz.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
                                                    style={{ width: `${quiz.score}%` }}
                                                ></div>
                                            </div>
                                            <div className="flex gap-2 items-center justify-between mt-2">
                                                <span className="text-[9px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded border border-gray-200">
                                                    {quiz.topic}
                                                </span>
                                                <span className="text-[9px] text-gray-400">
                                                    {new Date(quiz.date).toLocaleDateString()}
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-6">
                                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                                        <Target className="text-gray-400" size={18} />
                                    </div>
                                    <p className="text-xs text-gray-500">No quizzes taken yet.</p>
                                </div>
                            )}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
};

const SparklesIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-500"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" /></svg>
);
