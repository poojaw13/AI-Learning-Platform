
import React from 'react';

import { Award, Lock, Star } from 'lucide-react';
import client from '../../api/client';

export const Achievements = () => {
    interface Achievement { id: string | number; title: string; description: string; xp: number; unlocked: boolean; }
    const [achievements, setAchievements] = React.useState<Achievement[]>([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        client.get('/gamification/achievements')
            .then(res => {
                setAchievements(res.data.achievements || []);
                setLoading(false);
            })
            .catch(err => {
                console.error("Failed to fetch achievements:", err);
                setAchievements([]);
                setLoading(false);
            });
    }, []);

    if (loading) {
        return (
            <div className="bg-gray-50 font-sans text-gray-900 flex items-center justify-center h-full p-8">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
            </div>
        );
    }

    return (
        <div className="bg-transparent font-sans text-slate-900">
            <div className="p-8">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900 mb-2">My Achievements</h1>
                        <p className="text-gray-500 text-sm">Badges and milestones you've unlocked</p>
                    </div>
                    <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-xl border border-gray-200 shadow-sm">
                        <Star className="text-yellow-500" size={20} fill="currentColor" />
                        <div>
                            <span className="block text-xs text-gray-500">Total Points</span>
                            <span className="block text-lg font-bold text-gray-900">2,450</span>
                        </div>
                    </div>
                </div>

                {/* Empty State */}
                {achievements.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-[60vh] text-center p-8 bg-white rounded-3xl border border-gray-200 border-dashed">
                        <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mb-6">
                            <Award size={40} className="text-yellow-600" />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">No Achievements Yet</h2>
                        <p className="text-gray-500 max-w-md mb-8">Complete courses and take quizzes to earn your first badge!</p>
                        <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold transition-colors">
                            Go to Dashboard
                        </button>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {achievements.map((achievement) => (
                            <div key={achievement.id} className={`bg-white border ${achievement.unlocked ? 'border-yellow-200 shadow-sm' : 'border-gray-200'} rounded-2xl p-6 relative overflow-hidden group hover:border-yellow-400 transition-all shadow-sm`}>
                                {!achievement.unlocked && (
                                    <div className="absolute inset-0 bg-gray-50/60 backdrop-blur-[1px] z-10 flex items-center justify-center">
                                        <div className="bg-white/80 p-3 rounded-full border border-gray-200 shadow-sm">
                                            <Lock size={20} className="text-gray-400" />
                                        </div>
                                    </div>
                                )}

                                <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-4 ${achievement.unlocked ? 'bg-gradient-to-br from-yellow-100 to-orange-100 text-yellow-600' : 'bg-gray-100 text-gray-400'}`}>
                                    <Award size={28} />
                                </div>

                                <h3 className={`font-bold text-lg mb-1 ${achievement.unlocked ? 'text-gray-900' : 'text-gray-500'}`}>{achievement.title}</h3>
                                <p className="text-xs text-gray-500 mb-4 leading-relaxed">{achievement.description}</p>

                                <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider">
                                    <span className={achievement.unlocked ? 'text-yellow-600' : 'text-gray-400'}>{achievement.xp} XP</span>
                                    <span className={achievement.unlocked ? 'text-emerald-600' : 'text-gray-400'}>{achievement.unlocked ? 'Unlocked' : 'Locked'}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};
