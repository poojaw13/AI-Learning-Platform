import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
    Award,
    Clock,
    Target,
    Play,
    Zap,
    Sparkles
} from 'lucide-react';
import client from '../../api/client';


export const Dashboard = ({ isDemo = false }: { isDemo?: boolean }) => {
    const { user: authUser } = useAuth();
    const navigate = useNavigate();
    const user = isDemo ? { name: 'Demo Student', email: 'demo@example.com' } : authUser;

    interface Stats { coursesCompleted: number; hoursLearned: number; streak: number; skillsMastered: number; xp: number; velocity?: { name: string; xp: number }[]; }
    interface CourseLite { id: string; title: string; instructor: string; level: string; progress: number; duration: string; rating: number; students: number; _id?: string; }
    interface Recommendation { category: string; time: string; title: string; reasoning?: string; description?: string; }

    const [stats, setStats] = React.useState<Stats | null>(null);
    const [courses, setCourses] = React.useState<CourseLite[]>([]);
    const [recommendations, setRecommendations] = React.useState<Recommendation[]>([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        if (!isDemo && authUser?.role === 'ADMIN') {
            navigate('/admin');
        }
    }, [authUser, isDemo, navigate]);

    React.useEffect(() => {
        const fetchData = async () => {
            if (isDemo) {
                setStats({ coursesCompleted: 12, hoursLearned: 45, streak: 3, skillsMastered: 5, xp: 12400 });
                setCourses([
                    { id: 'demo-1', title: 'Introduction to Python AI', instructor: 'Dr. Sarah Smith', level: 'Beginner', progress: 65, duration: '4h', rating: 4.8, students: 1240 },
                    { id: 'demo-2', title: 'Advanced React Patterns', instructor: 'Pro Coder', level: 'Advanced', progress: 0, duration: '6h', rating: 4.9, students: 850 }
                ]);
                setRecommendations([
                    { category: 'Focus', time: '15m', title: 'Quick Python Quiz', reasoning: 'Refresh your memory on lists.' },
                    { category: 'Challenge', time: '30m', title: 'React Hooks Deep Dive', reasoning: 'Recommended based on your recent activity.' }
                ]);
                setLoading(false);
                return;
            }

            try {
                const [analyticsRes, coursesRes, insightsRes] = await Promise.all([
                    client.get('/analytics/dashboard'),
                    client.get('/courses'),
                    client.get('/analytics/insights')
                ]);
                setStats(analyticsRes.data);
                setCourses(coursesRes.data.courses || []);
                setRecommendations(insightsRes.data.insights || []);
            } catch (err) {
                console.error("Error fetching dashboard data:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [isDemo]);

    if (loading) return <div className="min-h-screen bg-[#0f111a] flex items-center justify-center text-white italic-none font-black uppercase tracking-widest">Initialising Control System...</div>;





    // Velocity Data for Chart
    const velocityData = stats?.velocity || [
        { name: 'Mon', xp: 0 },
        { name: 'Tue', xp: 0 },
        { name: 'Wed', xp: 0 },
        { name: 'Thu', xp: 0 },
        { name: 'Fri', xp: 0 },
        { name: 'Sat', xp: 0 },
        { name: 'Sun', xp: 0 },
    ];

    return (
        <div className="space-y-8 animate-fade-in-up">
            {/* Header / Welcome */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">
                        Welcome back, <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">{user?.name}</span>
                    </h1>
                    <p className="text-gray-400">Continue your journey to mastery.</p>
                </div>
                <div className="glass-panel px-4 py-2 rounded-full flex items-center gap-2">
                    <Zap className="text-yellow-400" size={18} />
                    <span className="text-white font-bold">{stats?.streak || 0} Day Streak</span>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {[
                    { label: 'XP Gained', value: stats?.xp.toLocaleString() || 0, icon: Sparkles, color: 'text-yellow-400' },
                    { label: 'Hours Learned', value: stats?.hoursLearned || 0, icon: Clock, color: 'text-neon-blue' },
                    { label: 'Skills Mastered', value: stats?.skillsMastered || 0, icon: Target, color: 'text-neon-purple' },
                    { label: 'Courses Completed', value: stats?.coursesCompleted || 0, icon: Award, color: 'text-neon-green' }
                ].map((stat, idx) => (
                    <div key={idx} className="glass-card p-6 flex items-center gap-4">
                        <div className={`p-3 rounded-xl bg-white/5 ${stat.color}`}>
                            <stat.icon size={24} />
                        </div>
                        <div>
                            <p className="text-2xl font-bold text-white">{stat.value}</p>
                            <p className="text-xs text-gray-400 uppercase tracking-wider">{stat.label}</p>
                        </div>
                    </div>
                ))}
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Continue Learning */}
                <div className="lg:col-span-2 space-y-6">
                    <h2 className="text-xl font-bold text-white flex items-center gap-2">
                        <Play className="text-neon-blue" /> Continue Learning
                    </h2>

                    {courses.map(course => (
                        <div key={course.id} onClick={() => navigate(`/courses/${course.id}`)} className="glass-card p-6 flex gap-6 group hover:scale-[1.01] cursor-pointer">
                            <div className="w-24 h-24 rounded-lg bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center border border-white/10 group-hover:border-neon-blue/30 transition-colors">
                                <span className="text-2xl font-bold text-white/50 group-hover:text-neon-blue/80 transition-colors">{course.title.charAt(0)}</span>
                            </div>
                            <div className="flex-1">
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <h3 className="text-lg font-bold text-white group-hover:text-neon-blue transition-colors">{course.title}</h3>
                                        <p className="text-sm text-gray-400">{course.instructor} • {course.duration} remaining</p>
                                    </div>
                                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-white/5 border border-white/10">
                                        {course.level}
                                    </span>
                                </div>

                                <div className="mt-4">
                                    <div className="flex justify-between text-xs mb-1">
                                        <span className="text-gray-400">{course.progress}% Complete</span>
                                        <span className="text-neon-blue">{course.progress}%</span>
                                    </div>
                                    <div className="h-1.5 w-full bg-space-900 rounded-full overflow-hidden">
                                        <div
                                            className="h-full bg-gradient-to-r from-neon-blue to-neon-purple rounded-full shield-glow"
                                            style={{ width: `${course.progress}%` }}
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* AI Recommendations */}
                <div className="space-y-6">
                    <h2 className="text-xl font-bold text-white flex items-center gap-2">
                        <Zap className="text-neon-purple" /> AI Recommended
                    </h2>

                    <div className="space-y-4">
                        {recommendations.map((rec, idx) => (
                            <div key={idx} className="glass-card p-4 relative overflow-hidden">
                                <div className="absolute top-0 right-0 w-16 h-16 bg-neon-purple/10 blur-xl rounded-full translate-x-1/2 -translate-y-1/2"></div>
                                <div className="relative z-10">
                                    <span className="text-[10px] font-bold uppercase tracking-wider text-neon-purple mb-1 block">
                                        {rec.category}
                                    </span>
                                    <h4 className="font-bold text-white mb-1">{rec.title}</h4>
                                    <p className="text-xs text-gray-400 mb-3">{rec.reasoning}</p>
                                    <div className="flex items-center text-xs text-gray-500">
                                        <Clock size={12} className="mr-1" /> {rec.time}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="glass-panel p-6 rounded-2xl md:col-span-2">
                        <h3 className="text-lg font-bold text-white mb-4">Learning Velocity</h3>
                        <div className="h-48 flex items-end justify-between gap-2 px-2">
                            {velocityData.map((day, idx) => (
                                <div key={idx} className="flex flex-col items-center gap-2 group w-full h-full justify-end">
                                    <div
                                        className="w-full bg-gradient-to-t from-neon-blue/20 to-neon-purple/20 rounded-t-lg transition-all duration-500 hover:from-neon-blue/40 hover:to-neon-purple/40 relative min-h-[4px]"
                                        style={{ height: `${Math.min((day.xp / 1000) * 100, 100)}%` }}
                                    >
                                        <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-black/80 px-2 py-1 rounded text-xs text-white whitespace-nowrap transition-opacity pointer-events-none border border-white/10 z-20">
                                            {day.xp} XP
                                        </div>
                                    </div>
                                    <span className="text-[10px] text-gray-500">{day.name.charAt(0)}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
