import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import client from '../../api/client';
import { Button } from '../../components/Button';
import { QuizPlayer } from '../../components/quiz/QuizPlayer';
import { BookOpen, PlayCircle, CheckCircle, Lock } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import rehypeHighlight from 'rehype-highlight';
import 'highlight.js/styles/github-dark.css';

export const CourseDetails = () => {
    interface Lesson { id: string; title: string; type: 'VIDEO' | 'QUIZ' | 'TEXT'; content?: string; data?: string; }
    interface Module { id: string; title: string; lessons: Lesson[]; }
    interface Exam { id: string; title: string; questions: string; passingScore: number; }
    interface Course { id: string; title: string; modules: Module[]; exams?: Exam[]; }

    const { id } = useParams();
    const [course, setCourse] = useState<Course | null>(null);
    const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
    const [activeExam, setActiveExam] = useState<Exam | null>(null);
    const [isQuizMode, setIsQuizMode] = useState(false);

    // Track expanded modules (Accordion)
    const [expandedModules, setExpandedModules] = useState<Set<number>>(new Set([0]));

    // Track completed lesson IDs (Fetched from backend)
    const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());

    const navigate = useNavigate();

    useEffect(() => {
        const fetchCourseAndProgress = async () => {
            try {
                const { data } = await client.get(`/courses/${id}`);
                setCourse(data);

                // Auto-select first lesson
                if (data.modules?.[0]?.lessons?.[0]) {
                    setActiveLesson(data.modules[0].lessons[0]);
                }

                // Fetch Progress
                const progressRes = await client.get(`/progress?courseId=${id}`);
                setCompletedLessons(new Set(progressRes.data.completedLessons));

            } catch (err) {
                console.error("Failed to load course data", err);
                toast.error("Could not load course.");
            }
        };
        fetchCourseAndProgress();
    }, [id]);

    const toggleModule = (index: number) => {
        const newExpanded = new Set(expandedModules);
        if (newExpanded.has(index)) newExpanded.delete(index);
        else newExpanded.add(index);
        setExpandedModules(newExpanded);
    };

    const toggleComplete = async (lessonId: string) => {
        if (completedLessons.has(lessonId)) return; // Already completed (optional: allow toggle off?)

        const newSet = new Set(completedLessons);
        newSet.add(lessonId);
        setCompletedLessons(newSet);
        toast.success("Lesson marked as complete! 🎉");

        try {
            await client.post('/progress/lesson', {
                lessonId,
                courseId: course?.id
            });
            // Re-fetch or locally update progress bar? 
            // Local update for now is fine since we calculate progress in render
        } catch (err) {
            console.error("Failed to sync progress", err);
            toast.error("Failed to save progress to server.");
        }
    };

    // Helper to check if a module is unlocked
    const isModuleUnlocked = (moduleIndex: number) => {
        if (moduleIndex === 0) return true; // Level 1 always open
        const prevModule = course?.modules[moduleIndex - 1];
        if (!prevModule) return true;

        // Check if all lessons in previous module are complete
        return prevModule.lessons.every(l => completedLessons.has(l.id));
    };

    if (!course) return <div className="flex h-screen items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div></div>;

    interface Question {
        text: string;
        options: string[];
        correctAnswer: string;
    }

    const ExamPlayer = ({ exam }: { exam: Exam }) => {
        const questions = exam.questions ? JSON.parse(exam.questions) : [];
        const [answers, setAnswers] = useState<Record<number, string>>({});
        const [score, setScore] = useState<number | null>(null);

        const handleSubmit = async () => {
            let correct = 0;
            questions.forEach((q: Question, idx: number) => {
                if (answers[idx] === q.correctAnswer) correct++;
            });
            const finalScore = (correct / questions.length) * 100;
            setScore(finalScore);

            try {
                await client.post('/exams/submit', {
                    examId: exam.id,
                    score: finalScore,
                    answers: answers
                });
                if (finalScore >= exam.passingScore) {
                    toast.success(`Congratulations! You passed with ${finalScore.toFixed(0)}%`);
                } else {
                    toast.error(`You scored ${finalScore.toFixed(0)}%. passing is ${exam.passingScore}%. Try again!`);
                }
            } catch (error) {
                console.error("Failed to submit exam:", error);
                toast.error("Failed to save exam results.");
            }
        };

        if (score !== null) {
            return (
                <div className="text-center py-20">
                    <h2 className="text-3xl font-bold mb-4">{score >= exam.passingScore ? '🎉 You Passed!' : '😔 Keep Studying'}</h2>
                    <p className="text-xl mb-6">Your Score: {score.toFixed(0)}%</p>
                    <Button onClick={() => setScore(null)}>Retake Exam</Button>
                </div>
            )
        }

        return (
            <div className="max-w-3xl mx-auto">
                <h2 className="text-2xl font-bold mb-6">{exam.title}</h2>
                {questions.map((q: Question, idx: number) => (
                    <div key={idx} className="mb-8 bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                        <h4 className="font-semibold text-lg mb-4">{idx + 1}. {q.text}</h4>
                        <div className="space-y-3">
                            {q.options.map((opt: string) => (
                                <label key={opt} className="flex items-center gap-3 p-3 rounded-lg border border-gray-100 hover:bg-blue-50 cursor-pointer transition-colors">
                                    <input
                                        type="radio"
                                        name={`q-${idx}`}
                                        value={opt}
                                        checked={answers[idx] === opt}
                                        onChange={() => setAnswers({ ...answers, [idx]: opt })}
                                        className="w-5 h-5 text-blue-600"
                                    />
                                    <span>{opt}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                ))}
                <Button onClick={handleSubmit} className="w-full py-4 text-lg">Submit Final Exam</Button>
            </div>
        );
    }

    const LessonContent = ({ lesson }: { lesson: Lesson }) => {
        const [aiContent, setAiContent] = useState<string | null>(null);
        const [isGenerating, setIsGenerating] = useState(false);

        if (lesson.type === 'QUIZ') {
            const questions = lesson.data ? JSON.parse(lesson.data) : [];
            if (questions.length === 0) return <div>No questions in this quiz.</div>;

            if (isQuizMode) {
                return <QuizPlayer lessonId={lesson.id} questions={questions} onComplete={() => { setIsQuizMode(false); toggleComplete(lesson.id); }} />
            }
            return (
                <div className="text-center py-10">
                    <h3 className="text-xl mb-4">Quiz: {lesson.title}</h3>
                    <Button onClick={() => setIsQuizMode(true)}>Start Quiz</Button>
                </div>
            )
        }

        const handleDifficultyChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
            const level = e.target.value;
            if (level === 'Adaptive (AI)') return;

            setIsGenerating(true);
            toast.info(`AI: Generating ${level} content for "${lesson.title}"...`);

            try {
                const { data } = await client.post('/ai/lesson', {
                    topic: lesson.title,
                    level: level
                });
                setAiContent(data.content);
                toast.success("Content Adapted successfully!");
            } catch {
                toast.error("Failed to generate content.");
            } finally {
                setIsGenerating(false);
            }
        };

        return (
            <div className="prose max-w-none relative animate-in fade-in duration-500">
                {/* Video Player Placeholder */}
                {lesson.type === 'VIDEO' && (
                    <div className="mb-8 bg-black rounded-xl overflow-hidden shadow-2xl aspect-video relative group cursor-pointer ring-4 ring-offset-4 ring-gray-100">
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="bg-white/10 backdrop-blur-md p-6 rounded-full group-hover:scale-110 transition-transform">
                                <PlayCircle className="w-16 h-16 text-white" fill="currentColor" />
                            </div>
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent text-white">
                            <h2 className="font-bold text-2xl mb-1">{lesson.title}</h2>
                            <p className="text-sm text-gray-300">10:24 • 1080p HD</p>
                        </div>
                    </div>
                )}

                <div className="flex justify-between items-center mb-8 bg-white p-4 rounded-xl shadow-sm border border-gray-100 sticky top-0 z-10 backdrop-blur-xl bg-white/80">
                    <div className="flex items-center gap-4">
                        <select
                            onChange={handleDifficultyChange}
                            className="text-sm border-gray-200 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 py-2 px-3"
                        >
                            <option>Adaptive (AI)</option>
                            <option value="Beginner">Beginner (Easy)</option>
                            <option value="Intermediate">Intermediate (Medium)</option>
                            <option value="Advanced">Advanced (Hard)</option>
                        </select>
                        <span className="text-xs text-gray-500 font-medium flex items-center gap-1 bg-gray-50 px-2 py-1 rounded">
                            {isGenerating ? '🤖 Generating...' : '⏱️ Pace: Normal'}
                        </span>
                    </div>
                    <div className="flex gap-2">
                        <button
                            onClick={() => toggleComplete(lesson.id)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${completedLessons.has(lesson.id)
                                ? 'bg-green-100 text-green-700'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                }`}
                        >
                            <CheckCircle size={18} className={completedLessons.has(lesson.id) ? "fill-green-600 text-white" : ""} />
                            {completedLessons.has(lesson.id) ? 'Completed' : 'Mark Complete'}
                        </button>
                    </div>
                </div>

                <div className="max-w-4xl mx-auto">
                    <h1 className="text-4xl font-extrabold text-gray-900 mb-6 tracking-tight">{lesson.title}</h1>

                    {isGenerating ? (
                        <div className="p-12 text-center text-gray-500 animate-pulse bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                            <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <span className="text-2xl">🔮</span>
                            </div>
                            <h3 className="text-lg font-bold text-gray-700">AI is tailoring content for you</h3>
                            <p className="text-sm">Analyzing your preferred learning style...</p>
                        </div>
                    ) : (
                        <div className="prose prose-lg prose-indigo max-w-none prose-headings:font-bold prose-p:leading-relaxed prose-img:rounded-2xl prose-img:shadow-lg">
                            <ReactMarkdown rehypePlugins={[rehypeHighlight]}>
                                {aiContent || lesson.content || ''}
                            </ReactMarkdown>
                        </div>
                    )}

                    {/* AI Micro-lesson Cards (Mock) */}
                    <div className="mt-12 pt-8 border-t border-gray-100">
                        <h4 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                            ⚡ Quick Review
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-amber-50 p-4 rounded-xl border border-amber-100 text-sm">
                                <span className="font-bold block mb-2 text-amber-800">Key Concept</span>
                                This lesson covers the fundamental building blocks necessary for mastering {course?.title}.
                            </div>
                            <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 text-sm">
                                <span className="font-bold block mb-2 text-emerald-800">Pro Tip</span>
                                Practice the code examples in your local IDE to build muscle memory!
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    };

    const progress = (completedLessons.size / ((course.modules || []).flatMap(m => m.lessons).length || 1)) * 100;

    return (
        <div className="min-h-screen bg-white flex flex-col md:flex-row font-sans text-gray-900">
            {/* Sidebar (Coursera Style) */}
            <div className="w-full md:w-96 bg-white border-r border-gray-200 overflow-y-auto h-[40vh] md:h-screen flex-shrink-0 flex flex-col shadow-[4px_0_24px_rgba(0,0,0,0.02)] z-20">
                <div className="p-5 border-b border-gray-100 bg-white sticky top-0 z-10">
                    <button onClick={() => navigate('/dashboard')} className="text-gray-500 hover:text-gray-900 text-sm font-medium flex items-center gap-1 mb-4 transition-colors">
                        ← Back to Dashboard
                    </button>
                    <h2 className="font-bold text-xl leading-tight mb-4 text-gray-900">{course.title}</h2>

                    {/* Progress Bar */}
                    <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                        <div className="flex justify-between text-xs font-bold text-gray-600 mb-2">
                            <span>Your Progress</span>
                            <span className="text-indigo-600">{progress.toFixed(0)}%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-indigo-600 rounded-full transition-all duration-500 ease-out" style={{ width: `${progress}%` }}></div>
                        </div>
                        {progress === 100 && (
                            <div className="mt-3 text-center">
                                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-bold">Course Completed 🏆</span>
                            </div>
                        )}
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                    {course.modules?.map((mod, modIdx) => {
                        const isUnlocked = isModuleUnlocked(modIdx);
                        const isExpanded = expandedModules.has(modIdx);

                        return (
                            <div key={mod.id} className={`border-b border-gray-100 ${!isUnlocked ? 'opacity-60 bg-gray-50' : 'bg-white'}`}>
                                <button
                                    onClick={() => isUnlocked && toggleModule(modIdx)}
                                    className="w-full text-left px-5 py-4 flex justify-between items-center hover:bg-gray-50 transition-colors"
                                    disabled={!isUnlocked}
                                >
                                    <div>
                                        <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wide">Module {modIdx + 1}</h3>
                                        <p className="text-xs text-gray-500 font-medium mt-0.5">{mod.title}</p>
                                    </div>
                                    {!isUnlocked ? <Lock size={14} className="text-gray-400" /> : (isExpanded ? <span className="text-gray-400">−</span> : <span className="text-gray-400">+</span>)}
                                </button>

                                {isExpanded && isUnlocked && (
                                    <div className="bg-gray-50/50 pb-2">
                                        {mod.lessons?.map((lesson) => {
                                            const isActive = activeLesson?.id === lesson.id && !activeExam;
                                            return (
                                                <button
                                                    key={lesson.id}
                                                    onClick={() => { setActiveLesson(lesson); setActiveExam(null); setIsQuizMode(false); }}
                                                    className={`w-full text-left px-5 py-3 text-sm flex items-start gap-3 transition-all relative ${isActive
                                                        ? 'bg-indigo-50 text-indigo-700 font-semibold'
                                                        : 'text-gray-600 hover:bg-gray-100'
                                                        }`}
                                                >
                                                    {isActive && <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-600"></div>}
                                                    <div className="mt-0.5">
                                                        {completedLessons.has(lesson.id)
                                                            ? <CheckCircle size={16} className="text-green-500 fill-green-100" />
                                                            : (lesson.type === 'VIDEO' ? <PlayCircle size={16} /> : <BookOpen size={16} />)
                                                        }
                                                    </div>
                                                    <div className="flex-1">
                                                        <span className={completedLessons.has(lesson.id) ? 'line-through text-gray-400' : ''}>{lesson.title}</span>
                                                        <span className="block text-[10px] text-gray-400 font-normal mt-0.5">10 min • {lesson.type}</span>
                                                    </div>
                                                </button>
                                            )
                                        })}
                                    </div>
                                )}
                            </div>
                        )
                    })}

                    {/* Final Exam Section */}
                    {course.exams && course.exams.length > 0 && (
                        <div className="p-4 bg-red-50/30 border-t border-red-50">
                            <h3 className="text-red-800 font-bold uppercase text-xs mb-3 px-2 tracking-wider flex items-center justify-between">
                                <span>Final Assessment</span>
                                {progress < 100 && <Lock size={12} className="text-red-300" />}
                            </h3>
                            {course.exams.map(exam => {
                                const isUnlocked = progress === 100;
                                return (
                                    <button
                                        key={exam.id}
                                        onClick={() => {
                                            if (isUnlocked) {
                                                setActiveExam(exam);
                                                setActiveLesson(null);
                                            } else {
                                                toast.error("Complete all lessons to unlock the Final Exam!");
                                            }
                                        }}
                                        disabled={!isUnlocked}
                                        className={`w-full text-left px-3 py-3 rounded-lg text-sm font-bold flex items-center gap-3 transition-colors ${activeExam?.id === exam.id
                                            ? 'bg-white shadow-sm ring-1 ring-red-100 text-red-600'
                                            : !isUnlocked
                                                ? 'text-gray-400 cursor-not-allowed bg-gray-50 opacity-60'
                                                : 'text-gray-700 hover:bg-red-50 hover:text-red-600'
                                            }`}
                                    >
                                        <span>{isUnlocked ? '🏆' : '🔒'}</span>
                                        {exam.title}
                                    </button>
                                )
                            })}
                        </div>
                    )}
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-y-auto h-screen bg-white md:bg-gray-50/30 relative">
                {activeExam ? (
                    <div className="p-8 md:p-12">
                        <ExamPlayer exam={activeExam} />
                    </div>
                ) : activeLesson ? (
                    <div className="p-8 md:p-12 max-w-5xl mx-auto bg-white min-h-screen shadow-sm md:my-8 md:rounded-2xl md:border md:border-gray-100">
                        <LessonContent lesson={activeLesson} />
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400 animate-pulse">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                            <BookOpen size={32} className="opacity-50" />
                        </div>
                        <p className="text-lg font-medium">Select a lesson to start learning</p>
                    </div>
                )}
            </div>
        </div>
    );
};
