import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Cpu, Activity, Shield, Settings, Zap, RefreshCw, Eye, CheckCircle } from 'lucide-react';
import { Button } from '../../components/Button';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { toast } from 'react-toastify';
import client from '../../api/client';

export const AIControlCenter = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [aiStatus, setAiStatus] = useState<any>(null);
    const [models, setModels] = useState([
        { id: 1, name: 'Skill Gap Analyzer', status: 'Active', accuracy: 94, latency: '45ms', type: 'Analytical' },
        { id: 2, name: 'Personalized Pathways', status: 'Active', accuracy: 91, latency: '120ms', type: 'Recommendation' },
        { id: 3, name: 'AI Tutor (Chatbot)', status: 'Active', accuracy: 88, latency: '800ms', type: 'Generative' },
        { id: 4, name: 'Micro-Lesson Generator', status: 'Inactive', accuracy: 85, latency: '2.4s', type: 'Generative' },
        { id: 5, name: 'Emotion Detection', status: 'Active', accuracy: 96, latency: '30ms', type: 'Computer Vision' },
    ]);

    useEffect(() => {
        const fetchAIStatus = async () => {
            try {
                const { data } = await client.get('/admin/ai-status');
                setAiStatus(data);
                // In a real scenario, we might merge backend data with our models list
            } catch (error) {
                console.error("Failed to fetch AI status", error);
                toast.error("Failed to connect to AI Core Systems");
            } finally {
                setLoading(false);
            }
        };
        fetchAIStatus();
    }, []);

    const fairnessData = [
        { category: 'Gender', score: aiStatus?.fairness?.gender || 98, bias: 2 },
        { category: 'Race', score: 97, bias: 3 },
        { category: 'Age', score: 99, bias: 1 },
        { category: 'Geo', score: aiStatus?.fairness?.cultural || 95, bias: 5 },
    ];

    const toggleModel = (id: number) => {
        setModels(models.map(m => {
            if (m.id === id) {
                const newStatus = m.status === 'Active' ? 'Inactive' : 'Active';
                toast.info(`${m.name} is now ${newStatus}`);
                return { ...m, status: newStatus };
            }
            return m;
        }));
    };

    const navigateToTest = (id: number) => {
        navigate(`/admin/ai/test/${id}`);
    };

    const navigateToConfig = (id: number) => {
        navigate(`/admin/ai/config/${id}`);
    };

    if (loading) return (
        <div className="flex items-center justify-center h-96">
            <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 rounded-full border-4 border-neon-blue border-t-transparent animate-spin"></div>
                <p className="text-neon-blue font-mono animate-pulse">Connecting to AI Core...</p>
            </div>
        </div>
    );

    return (
        <div className="space-y-8 animate-fade-in-up">
            {/* Header */}
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-2">
                        AI <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">Control Center</span>
                    </h1>
                    <p className="text-gray-400 text-sm mt-1">Manage AI models, monitor fairness, and configure parameters.</p>
                </div>
                <div className="flex gap-3">
                    <div
                        onClick={() => toast.success("System Status: All systems operational. 99.9% uptime.")}
                        className="bg-emerald-500/10 text-emerald-500 px-3 py-1.5 rounded-lg border border-emerald-500/20 flex items-center gap-2 text-xs font-bold cursor-pointer hover:bg-emerald-500/20 transition-colors"
                    >
                        <Activity size={14} /> System Healthy
                    </div>
                    <Button
                        variant="primary"
                        onClick={() => {
                            toast.info("Retraining sequence initiated. This process runs in the background.");
                            // Simulation: Shuffle accuracies slightly to feel "working"
                            setTimeout(() => {
                                setModels(prev => prev.map(m => ({
                                    ...m,
                                    accuracy: m.status === 'Active'
                                        ? Math.min(99, Math.max(80, m.accuracy + (Math.random() > 0.5 ? 1 : -1)))
                                        : m.accuracy
                                })));
                                toast.success("Retraining complete! Model performance updated.");
                            }, 3000);
                        }}
                        className="shadow-lg shadow-blue-500/20 flex items-center gap-2"
                    >
                        <Zap size={16} /> Retrain Models
                    </Button>
                </div>
            </div>

            {/* Models Grid */}
            <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><Cpu className="text-purple-500" size={20} /> Active Models</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
                {models.map(model => (
                    <div key={model.id} className="glass-card p-5 hover:border-neon-blue/30 transition-all group relative">
                        <div className="flex justify-between items-start mb-4">
                            <div className={`p-2 rounded-xl ${model.status === 'Active' ? 'bg-purple-500/10 text-purple-400' : 'bg-gray-700/50 text-gray-500'}`}>
                                <Cpu size={24} />
                            </div>
                            <div
                                onClick={() => toggleModel(model.id)}
                                className={`w-10 h-5 rounded-full p-0.5 cursor-pointer transition-colors ${model.status === 'Active' ? 'bg-emerald-500' : 'bg-gray-700'}`}
                            >
                                <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${model.status === 'Active' ? 'translate-x-5' : 'translate-x-0'}`}></div>
                            </div>
                        </div>

                        <h3 className="font-bold text-white text-lg mb-1">{model.name}</h3>
                        <p className="text-xs text-gray-500 mb-6">{model.type}</p>

                        <div className="grid grid-cols-2 gap-4 mb-4">
                            <div>
                                <span className="block text-[10px] text-gray-500 uppercase font-bold tracking-wider">Accuracy</span>
                                <span className={`text-lg font-bold ${model.accuracy > 90 ? 'text-emerald-400' : 'text-yellow-400'}`}>{model.accuracy}%</span>
                            </div>
                            <div>
                                <span className="block text-[10px] text-gray-500 uppercase font-bold tracking-wider">Latency</span>
                                <span className="text-lg font-bold text-blue-400">{model.latency}</span>
                            </div>
                        </div>

                        <div className="flex gap-2 border-t border-white/5 pt-4">
                            <button
                                onClick={() => navigateToConfig(model.id)}
                                className="flex-1 bg-white/5 hover:bg-white/10 text-xs font-bold py-2 rounded-lg text-gray-300 transition-colors flex items-center justify-center gap-2"
                            >
                                <Settings size={14} /> Config
                            </button>
                            <button
                                onClick={() => navigateToTest(model.id)}
                                className="flex-1 bg-white/5 hover:bg-white/10 text-xs font-bold py-2 rounded-lg text-gray-300 transition-colors flex items-center justify-center gap-2"
                            >
                                <RefreshCw size={14} /> Test
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            {/* Fairness & Explainability Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Fairness Monitor */}
                <div className="glass-panel p-6 rounded-2xl">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-lg font-bold text-white flex items-center gap-2">
                            <Shield className="text-emerald-500" size={20} /> Fairness Monitor
                        </h2>
                        <span className="text-xs text-green-400 bg-green-500/10 px-2 py-1 rounded border border-green-500/20 flex items-center gap-1">
                            <CheckCircle size={12} /> Compliant
                        </span>
                    </div>

                    <div className="h-64 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={fairnessData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#374151" horizontal={false} />
                                <XAxis type="number" hide />
                                <YAxis dataKey="category" type="category" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} width={60} />
                                <Tooltip
                                    cursor={{ fill: '#1f2937' }}
                                    contentStyle={{ backgroundColor: '#111827', border: '1px solid #374151', borderRadius: '8px', color: '#fff' }}
                                />
                                <Bar dataKey="score" fill="#10b981" radius={[0, 4, 4, 0]} barSize={20} background={{ fill: '#374151', radius: [0, 4, 4, 0] } as any} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                    <p className="text-xs text-gray-500 text-center mt-2">Fairness Score per Demographic Category</p>
                </div>

                {/* Explainability / Recent Decisions */}
                <div className="glass-panel p-6 rounded-2xl">
                    <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                        <Eye className="text-blue-500" size={20} /> Recent AI Decisions
                    </h2>
                    <div className="space-y-4">
                        {[
                            { action: 'Flagged Content', target: 'Essay #892', reason: 'High similarity to known source', confidence: '98%', time: '10m ago', status: 'Review Needed' },
                            { action: 'Adjusted Pathway', target: 'Student: John Doe', reason: 'Struggling with Quadratics', confidence: '85%', time: '1h ago', status: 'Auto-Approved' },
                            { action: 'Generated Quiz', target: 'Course: React Basics', reason: 'Routine content generation', confidence: '92%', time: '2h ago', status: 'Published' },
                        ].map((decision, i) => (
                            <div key={i} className="bg-white/5 p-4 rounded-xl border border-white/5 flex justify-between items-start hover:border-white/10 transition-colors">
                                <div>
                                    <h4 className="text-sm font-bold text-white mb-1">{decision.action}</h4>
                                    <p className="text-xs text-gray-400 mb-1">{decision.target}</p>
                                    <p className="text-[10px] text-gray-500 italic">Reason: {decision.reason}</p>
                                </div>
                                <div className="text-right">
                                    <span className={`block text-[10px] font-bold uppercase mb-1 ${decision.status === 'Review Needed' ? 'text-yellow-500' : 'text-emerald-500'
                                        }`}>{decision.status}</span>
                                    <span className="text-[10px] text-gray-500">{decision.time}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                    <Button
                        variant="secondary"
                        onClick={() => navigate('/admin/ai/decisions')}
                        className="w-full mt-4 glass-btn border-white/10"
                    >
                        View Decision Logs
                    </Button>
                </div>
            </div>
        </div>
    );
};
