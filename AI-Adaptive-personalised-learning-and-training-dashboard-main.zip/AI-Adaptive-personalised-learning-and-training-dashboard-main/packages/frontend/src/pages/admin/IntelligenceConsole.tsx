import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, TrendingDown, Users, AlertTriangle, Zap, Activity } from 'lucide-react';
import { toast } from 'react-toastify';
import client from '../../api/client';
import { Button } from '../../components/Button';

interface Risk {
    id: number;
    score: number;
    user: {
        name: string;
        department: string;
    };
}

interface DashboardStats {
    highRisk: number;
    mediumRisk: number;
    lowRisk: number;
    recentRisks: Risk[];
}

interface RecoveryStats {
    inactiveCount: number;
    recoverySuccessRate: number;
    activeComebackPlans: number;
}

interface Bottleneck {
    id: number;
    lessonId: string;
    dropped: number;
}

interface DNA {
    styles: Record<string, number>;
    avgFocus: number;
}

export const IntelligenceConsole = () => {
    const navigate = useNavigate();
    const [riskStats, setRiskStats] = useState<DashboardStats | null>(null);
    const [recoveryStats, setRecoveryStats] = useState<RecoveryStats | null>(null);
    const [bottlenecks, setBottlenecks] = useState<Bottleneck[]>([]);
    const [dna, setDna] = useState<DNA | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchIntelligence = async () => {
            try {
                const [recoveryRes, riskRes, bottleRes, dnaRes] = await Promise.all([
                    client.get('/admin-iq/recovery-stats'),
                    client.get('/admin-iq/risk-matrix'),
                    client.get('/admin-iq/bottlenecks'),
                    client.get('/admin-iq/dna-aggregates')
                ]);

                setRecoveryStats(recoveryRes.data);
                setRiskStats(riskRes.data);
                setBottlenecks(bottleRes.data);
                setDna(dnaRes.data);
            } catch (error) {
                console.error("Failed to load intelligence data", error);
                toast.error("Failed to initialize intelligence systems.");
            } finally {
                setLoading(false);
            }
        };

        fetchIntelligence();
    }, []);

    if (loading) return (
        <div className="flex items-center justify-center h-96">
            <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 rounded-full border-4 border-neon-purple border-t-transparent animate-spin"></div>
                <p className="text-neon-purple font-mono animate-pulse">Initializing Neural Interface...</p>
            </div>
        </div>
    );

    return (
        <div className="space-y-8 animate-fade-in-up">
            {/* Header */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">
                        Intelligence <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-purple to-neon-blue">Console</span>
                    </h1>
                    <p className="text-gray-400 flex items-center gap-2">
                        <Brain size={14} className="text-neon-purple" />
                        AI-powered governance, dropout prediction, and behavioral analytics.
                    </p>
                </div>
                <div className="flex gap-4">
                    <span className="bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-xl flex flex-col items-end">
                        <span className="text-[10px] text-emerald-500 font-bold uppercase">System Status</span>
                        <span className="text-white font-bold flex items-center gap-2">
                            <Activity size={14} className="animate-pulse" /> Optimal
                        </span>
                    </span>
                </div>
            </div>

            {/* KPI Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="glass-card p-6 relative overflow-hidden group hover:border-red-500/30 transition-all">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                        <TrendingDown size={64} className="text-red-500" />
                    </div>
                    <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">High Risk Students</p>
                    <h3 className="text-3xl font-black text-white">{riskStats?.highRisk || 0}</h3>
                    <p className="text-red-400 text-xs mt-2 flex items-center gap-1">
                        <AlertTriangle size={12} /> Requires Intervention
                    </p>
                </div>

                <div className="glass-card p-6 border-l-4 border-l-emerald-500">
                    <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">Recovery Rate</p>
                    <h3 className="text-3xl font-black text-white">{recoveryStats?.recoverySuccessRate || 0}%</h3>
                    <div className="w-full bg-black/40 h-1.5 rounded-full mt-4 overflow-hidden">
                        <div className="bg-emerald-500 h-1.5 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)]" style={{ width: `${recoveryStats?.recoverySuccessRate || 0}%` }}></div>
                    </div>
                </div>

                <div className="glass-card p-6">
                    <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">Inactive (7d+)</p>
                    <h3 className="text-3xl font-black text-white">{recoveryStats?.inactiveCount || 0}</h3>
                    <p className="text-yellow-500 text-xs mt-2 font-mono">
                        {recoveryStats?.activeComebackPlans || 0} Active Plans
                    </p>
                </div>

                <div className="glass-card p-6">
                    <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">Avg Focus Score</p>
                    <h3 className="text-3xl font-black text-white">{dna?.avgFocus || 0}%</h3>
                    <p className="text-neon-blue text-xs mt-2 flex items-center gap-1">
                        <Zap size={12} /> Behavioral Consistency
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Dropout Risk Matrix */}
                <div className="lg:col-span-8 glass-panel p-6 rounded-2xl">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-white flex items-center gap-2 uppercase text-sm tracking-widest">
                            <Users size={18} className="text-neon-purple" /> Dropout Risk Heatmap
                        </h3>
                        <Button
                            variant="secondary"
                            onClick={() => navigate('/admin/users?filter=risk')} // Example navigation
                            className="text-xs glass-btn border-white/10"
                        >
                            View Detailed List
                        </Button>
                    </div>

                    <div className="h-48 flex items-end gap-4 mb-8">
                        <div className="flex-1 bg-gradient-to-t from-emerald-500/20 to-transparent rounded-t-xl p-4 flex flex-col items-center justify-end border-b border-emerald-500/30">
                            <span className="text-3xl font-black text-white mb-1">{riskStats?.lowRisk || 0}</span>
                            <span className="text-emerald-400 font-bold text-xs uppercase">Low Risk</span>
                        </div>
                        <div className="flex-1 bg-gradient-to-t from-yellow-500/20 to-transparent rounded-t-xl p-4 flex flex-col items-center justify-end border-b border-yellow-500/30">
                            <span className="text-3xl font-black text-white mb-1">{riskStats?.mediumRisk || 0}</span>
                            <span className="text-yellow-400 font-bold text-xs uppercase">Medium Risk</span>
                        </div>
                        <div className="flex-1 bg-gradient-to-t from-red-500/20 to-transparent rounded-t-xl p-4 flex flex-col items-center justify-end border-b border-red-500/30">
                            <span className="text-3xl font-black text-white mb-1">{riskStats?.highRisk || 0}</span>
                            <span className="text-red-400 font-bold text-xs uppercase">High Risk</span>
                        </div>
                    </div>

                    <div className="space-y-3">
                        <h4 className="text-xs font-bold text-gray-500 uppercase mb-2">Urgent Attention Needed</h4>
                        {riskStats?.recentRisks?.length === 0 ? (
                            <p className="text-gray-500 text-sm">No critical risks detected at this moment.</p>
                        ) : (
                            riskStats?.recentRisks?.map((risk) => (
                                <div key={risk.id} className="flex justify-between items-center p-3 bg-white/5 rounded-xl border border-white/5 hover:border-red-500/30 transition-colors group">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center text-red-500 text-xs font-bold">
                                            {risk.user.name.charAt(0)}
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-white group-hover:text-red-400 transition-colors">{risk.user.name}</p>
                                            <p className="text-[10px] text-gray-500">{risk.user.department}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <span className="block text-red-400 font-bold text-sm">{(risk.score * 100).toFixed(0)}% Risk</span>
                                        <button className="text-[10px] text-neon-blue hover:text-white transition-colors underline decoration-neon-blue/30">Intervene Now</button>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                {/* Bottlenecks and Actions */}
                <div className="lg:col-span-4 space-y-6">
                    <div className="glass-card p-6">
                        <h3 className="font-bold text-white mb-6 uppercase text-sm tracking-widest flex items-center gap-2">
                            <AlertTriangle size={18} className="text-yellow-500" /> Top Bottlenecks
                        </h3>
                        <div className="space-y-4">
                            {bottlenecks.length === 0 ? (
                                <div className="py-8 text-center text-gray-500 text-xs">No critical bottlenecks detected yet.</div>
                            ) : (
                                bottlenecks.map((bottleneck) => (
                                    <div key={bottleneck.id} className="group">
                                        <div className="flex justify-between text-xs mb-1.5">
                                            <span className="text-gray-300 font-bold group-hover:text-white transition-colors">Lesson: {bottleneck.lessonId}</span>
                                            <span className="text-red-400">{bottleneck.dropped} Drops</span>
                                        </div>
                                        <div className="w-full bg-black/40 h-1.5 rounded-full overflow-hidden">
                                            <div className="bg-gradient-to-r from-orange-500 to-red-600 h-full rounded-full" style={{ width: `${Math.min((bottleneck.dropped / 20) * 100, 100)}%` }}></div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-900 to-purple-900 border border-white/10 p-6 shadow-2xl shadow-purple-500/20">
                        {/* Glow effect */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>

                        <div className="relative z-10">
                            <h4 className="text-white font-black text-lg flex items-center gap-2">
                                <Zap className="text-yellow-400 fill-yellow-400" size={20} />
                                AI Intervention Engine
                            </h4>
                            <p className="text-xs text-indigo-200 mt-2 leading-relaxed mb-4">
                                Analyzing real-time behavioral data to suggest recovery paths.
                            </p>
                            <Button
                                variant="secondary"
                                onClick={() => {
                                    toast.success("Recovery sequence initiated. Redirecting to manager...");
                                    navigate('/admin/intelligence/recovery');
                                }}
                                className="w-full bg-white text-indigo-900 hover:bg-white/90 font-bold border-none shadow-lg"
                            >
                                Launch Batch Recovery
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};


