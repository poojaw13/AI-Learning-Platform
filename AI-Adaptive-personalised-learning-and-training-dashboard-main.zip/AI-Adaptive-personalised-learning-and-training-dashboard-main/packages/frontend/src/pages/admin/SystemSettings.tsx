import { useState } from 'react';

import { Settings, Save, Lock, Smartphone, Globe, Bell, Layout } from 'lucide-react';
import { Button } from '../../components/Button';
import { toast } from 'react-toastify';

export const SystemSettings = () => {
    // Mock Settings Data
    const [settings, setSettings] = useState({
        siteName: 'Adaptive Learning Platform',
        supportEmail: 'support@adaptivelearn.com',
        maintenanceMode: false,
        enableGamification: true,
        enableSocialFeatures: true,
        allowPublicRegistration: true,
        enableAiTutor: true,
    });

    const handleToggle = (key: keyof typeof settings) => {
        setSettings(prev => {
            const newValue = !prev[key];
            const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
            toast.info(`${label} ${newValue ? 'Enabled' : 'Disabled'}`);
            return { ...prev, [key]: newValue };
        });
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSettings({ ...settings, [e.target.name]: e.target.value });
    };

    const handleSave = () => {
        toast.success("System settings saved successfully!");
    };

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            Platform Settings
                        </h1>
                        <p className="text-gray-400 text-sm mt-1">Configure global system parameters and feature flags.</p>
                    </div>
                    <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20 flex items-center gap-2">
                        <Save size={18} /> Save Changes
                    </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* General Configuration */}
                    <div className="bg-[#161b28] border border-gray-800 rounded-2xl p-6">
                        <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                            <Settings className="text-blue-500" size={20} /> General Configuration
                        </h2>

                        <div className="space-y-6">
                            <div>
                                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Platform Name</label>
                                <input
                                    type="text"
                                    name="siteName"
                                    value={settings.siteName}
                                    onChange={handleChange}
                                    className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2.5 text-gray-300 focus:outline-none focus:border-emerald-500 transition-colors"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Support Email</label>
                                <input
                                    type="email"
                                    name="supportEmail"
                                    value={settings.supportEmail}
                                    onChange={handleChange}
                                    className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2.5 text-gray-300 focus:outline-none focus:border-emerald-500 transition-colors"
                                />
                            </div>
                        </div>

                        <div className="mt-8 pt-8 border-t border-gray-800">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h3 className="font-bold text-white flex items-center gap-2"><Lock className="text-red-500" size={16} /> Maintenance Mode</h3>
                                    <p className="text-xs text-gray-500 mt-1">Lock the platform for all non-admin users.</p>
                                </div>
                                <div
                                    onClick={() => handleToggle('maintenanceMode')}
                                    className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors ${settings.maintenanceMode ? 'bg-red-500' : 'bg-gray-700'}`}
                                >
                                    <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${settings.maintenanceMode ? 'translate-x-6' : 'translate-x-0'}`}></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Feature Flags */}
                    <div className="bg-[#161b28] border border-gray-800 rounded-2xl p-6">
                        <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                            <Layout className="text-purple-500" size={20} /> Feature Management
                        </h2>

                        <div className="space-y-6">
                            {[
                                { key: 'enableGamification', label: 'Gamification System', icon: <Settings size={16} className="text-yellow-500" />, desc: 'Points, badges, and leaderboards.' },
                                { key: 'enableSocialFeatures', label: 'Social & Community', icon: <Bell size={16} className="text-blue-500" />, desc: 'Chat, study groups, and forums.' },
                                { key: 'allowPublicRegistration', label: 'Public Registration', icon: <Globe size={16} className="text-emerald-500" />, desc: 'Allow new users to sign up freely.' },
                                { key: 'enableAiTutor', label: 'AI Tutor Access', icon: <Smartphone size={16} className="text-indigo-500" />, desc: 'Enable the Gemini-powered chat assistant.' },
                            ].map((feature) => (
                                <div key={feature.key} className="flex items-center justify-between p-4 rounded-xl bg-gray-800/30 border border-gray-800">
                                    <div className="flex items-start gap-3">
                                        <div className="mt-1">{feature.icon}</div>
                                        <div>
                                            <h3 className="font-bold text-gray-200 text-sm">{feature.label}</h3>
                                            <p className="text-xs text-gray-500 mt-0.5">{feature.desc}</p>
                                        </div>
                                    </div>
                                    <div
                                        onClick={() => handleToggle(feature.key as keyof typeof settings)}
                                        className={`w-10 h-5 rounded-full p-0.5 cursor-pointer transition-colors flex-shrink-0 ${settings[feature.key as keyof typeof settings] ? 'bg-emerald-500' : 'bg-gray-700'}`}
                                    >
                                        <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${settings[feature.key as keyof typeof settings] ? 'translate-x-5' : 'translate-x-0'}`}></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
