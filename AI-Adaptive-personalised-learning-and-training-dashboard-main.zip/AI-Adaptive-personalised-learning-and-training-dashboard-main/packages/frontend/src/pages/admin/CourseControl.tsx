import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, BookOpen, Clock, Users, Edit, Eye, X, Sparkles, Loader2, Trash2 } from 'lucide-react';
import { Button } from '../../components/Button';
import { toast } from 'react-toastify';
import client from '../../api/client';

interface Course {
    id: string;
    title: string;
    description: string;
    thumbnail?: string;
    createdAt: string;
    duration?: string;
    _count?: {
        enrollments: number;
    };
}

export const CourseControl = () => {
    const navigate = useNavigate();
    const [courses, setCourses] = useState<Course[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [showAIModal, setShowAIModal] = useState(false);
    const [generating, setGenerating] = useState(false);

    // Unified state for Create/Edit
    const [courseForm, setCourseForm] = useState({ id: '', title: '', description: '', thumbnail: '' });
    const [isEditing, setIsEditing] = useState(false);
    const [aiRequest, setAiRequest] = useState({ topic: '', description: '' });

    const fetchCourses = async () => {
        try {
            const { data } = await client.get('/courses');
            setCourses(data);
        } catch (error) {
            console.error("Failed to fetch courses", error);
            toast.error("Failed to load courses");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCourses();
    }, []);

    const handleGenerateWithAI = async () => {
        try {
            if (!aiRequest.topic) {
                toast.warning("Please provide a topic for the AI");
                return;
            }
            setGenerating(true);
            toast.info("AI is crafting your course structure... this may take 20-30 seconds.");

            await client.post('/courses/generate-ai', aiRequest);

            toast.success("AI Course generated successfully!");
            setShowAIModal(false);
            setAiRequest({ topic: '', description: '' });
            fetchCourses();
        } catch (error) {
            console.error(error);
            toast.error("AI Generation failed. Please try again.");
        } finally {
            setGenerating(false);
        }
    };

    const handleDeleteCourse = async (id: string, title: string) => {
        if (!window.confirm(`Are you sure you want to delete "${title}"? This will remove all modules and lessons.`)) {
            return;
        }

        try {
            await client.delete(`/courses/${id}`);
            toast.success("Course deleted successfully");
            fetchCourses();
        } catch (error: any) {
            console.error(error);
            toast.error(error.response?.data?.message || "Failed to delete course");
        }
    };

    const handleSaveCourse = async () => {
        try {
            if (!courseForm.title || !courseForm.description) {
                toast.warning("Title and Description are required");
                return;
            }

            if (isEditing && courseForm.id) {
                await client.put(`/courses/${courseForm.id}`, courseForm);
                toast.success("Course updated successfully!");
            } else {
                await client.post('/courses', courseForm);
                toast.success("Course created successfully!");
            }

            setShowModal(false);
            setCourseForm({ id: '', title: '', description: '', thumbnail: '' });
            setIsEditing(false);
            fetchCourses();
        } catch (error) {
            console.error(error);
            toast.error(isEditing ? "Failed to update course" : "Failed to create course");
        }
    };

    const openCreateModal = () => {
        setIsEditing(false);
        setCourseForm({ id: '', title: '', description: '', thumbnail: '' });
        setShowModal(true);
    };

    const openEditModal = (course: Course) => {
        setIsEditing(true);
        setCourseForm({
            id: course.id,
            title: course.title,
            description: course.description || '',
            thumbnail: course.thumbnail || ''
        });
        setShowModal(true);
    };

    const filteredCourses = courses.filter(c =>
        c.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (loading) return (
        <div className="flex items-center justify-center h-96">
            <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 rounded-full border-4 border-neon-blue border-t-transparent animate-spin"></div>
                <p className="text-neon-blue font-mono animate-pulse">Loading Academy Content...</p>
            </div>
        </div>
    );

    return (
        <div className="space-y-8 animate-fade-in-up">
            {/* Header */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">
                        Course <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">Control Center</span>
                    </h1>
                    <p className="text-gray-400 flex items-center gap-2">
                        <BookOpen size={14} className="text-neon-pink" />
                        Manage curriculum, AI generation, and content visibility.
                    </p>
                </div>
                <div className="flex gap-3">
                    <Button
                        onClick={() => setShowAIModal(true)}
                        className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 flex items-center gap-2 border-none transition-all hover:scale-105"
                    >
                        <Sparkles size={18} /> Build with AI
                    </Button>
                    <Button
                        onClick={openCreateModal}
                        className="glass-btn border-neon-green/30 text-neon-green hover:bg-neon-green/10 flex items-center gap-2"
                    >
                        <Plus size={18} /> Create New Course
                    </Button>
                </div>
            </div>

            {/* Toolbar */}
            <div className="glass-panel p-4 rounded-xl flex items-center gap-4">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-2.5 text-gray-500 group-focus-within:text-neon-blue transition-colors" size={18} />
                    <input
                        type="text"
                        placeholder="Search courses..."
                        className="w-full bg-black/20 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-gray-300 focus:outline-none focus:border-neon-blue/50 focus:bg-black/40 transition-all placeholder:text-gray-600"
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                    <span className="bg-white/5 px-3 py-1 rounded-md border border-white/10">
                        Total Courses: <span className="text-white font-bold">{courses.length}</span>
                    </span>
                </div>
            </div>

            {/* Course Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map(course => (
                    <div key={course.id} className="glass-card group relative overflow-hidden transition-all hover:border-neon-blue/30 hover:shadow-neon-blue/10">
                        {/* Hover Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none" />

                        <div className="p-5 relative z-20">
                            <div className="flex justify-between items-start mb-4">
                                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center text-neon-blue group-hover:scale-110 transition-transform duration-300">
                                    <BookOpen size={24} />
                                </div>
                                <span className="bg-white/5 text-[10px] font-mono px-2 py-1 rounded border border-white/10 text-gray-400">
                                    {new Date(course.createdAt).toLocaleDateString()}
                                </span>
                            </div>

                            <h3 className="text-xl font-bold text-white mb-2 line-clamp-1 group-hover:text-neon-blue transition-colors">{course.title}</h3>
                            <p className="text-sm text-gray-400 mb-6 h-10 line-clamp-2 leading-relaxed">{course.description}</p>

                            <div className="flex items-center gap-4 text-gray-400 mb-6 text-xs font-medium">
                                <span className="flex items-center gap-1.5"><Users size={14} className="text-neon-green" /> {course._count?.enrollments || 0} Students</span>
                                <span className="flex items-center gap-1.5"><Clock size={14} className="text-neon-pink" /> {course.duration || 'Self-paced'}</span>
                            </div>
                            <div className="grid grid-cols-2 gap-2 mt-2">
                                <button
                                    onClick={() => navigate(`/courses/${course.id}`)}
                                    className="p-2 gap-2 flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors text-[10px] font-bold border border-white/5"
                                >
                                    <Eye size={14} /> Preview
                                </button>
                                <button
                                    onClick={() => openEditModal(course)}
                                    className="p-2 gap-2 flex items-center justify-center rounded-lg bg-white/5 hover:bg-neon-blue/10 text-gray-300 hover:text-neon-blue transition-colors text-[10px] font-bold border border-white/5 hover:border-neon-blue/30"
                                >
                                    <Edit size={14} /> Edit
                                </button>
                                <button
                                    onClick={() => handleDeleteCourse(course.id, course.title)}
                                    className="col-span-2 p-2 gap-2 flex items-center justify-center rounded-lg bg-red-500/5 hover:bg-red-500/10 text-red-400 hover:text-red-300 transition-colors text-[10px] font-bold border border-red-500/10 hover:border-red-500/30"
                                >
                                    <Trash2 size={14} /> Delete Course
                                </button>
                            </div>
                        </div>

                        {/* Decorative background glow */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-neon-blue/5 rounded-full blur-3xl -mr-10 -mt-10 group-hover:bg-neon-blue/10 transition-colors" />
                    </div>
                ))}
            </div>

            {filteredCourses.length === 0 && (
                <div className="text-center py-20 text-gray-500 glass-panel rounded-2xl border-dashed">
                    <BookOpen size={48} className="mx-auto mb-4 opacity-20" />
                    <p>No courses found. Try adjusting your search query.</p>
                </div>
            )}

            {/* Create/Edit Course Modal */}
            {
                showModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
                        <div className="glass-card w-full max-w-lg p-6 relative animate-slide-up border-neon-blue/20">
                            <button onClick={() => setShowModal(false)} className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors">
                                <X size={20} />
                            </button>
                            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                                <div className="w-10 h-10 rounded-lg bg-neon-blue/20 flex items-center justify-center text-neon-blue">
                                    {isEditing ? <Edit size={20} /> : <Plus size={20} />}
                                </div>
                                {isEditing ? 'Edit Course' : 'Create New Course'}
                            </h2>

                            <div className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Course Title</label>
                                    <input
                                        type="text"
                                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-neon-blue outline-none transition-colors placeholder:text-gray-600"
                                        placeholder="e.g. Intro to Advanced AI"
                                        value={courseForm.title}
                                        onChange={e => setCourseForm({ ...courseForm, title: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Description</label>
                                    <textarea
                                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-neon-blue outline-none transition-colors h-32 placeholder:text-gray-600 resize-none"
                                        placeholder="Course details..."
                                        value={courseForm.description}
                                        onChange={e => setCourseForm({ ...courseForm, description: e.target.value })}
                                    ></textarea>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Thumbnail URL (Optional)</label>
                                    <input
                                        type="text"
                                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-neon-blue outline-none transition-colors placeholder:text-gray-600"
                                        placeholder="https://..."
                                        value={courseForm.thumbnail}
                                        onChange={e => setCourseForm({ ...courseForm, thumbnail: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div className="mt-8 flex gap-3">
                                <Button variant="secondary" onClick={() => setShowModal(false)} className="flex-1 glass-btn border-white/10 hover:border-white/30 text-gray-300">
                                    Cancel
                                </Button>
                                <Button variant="primary" onClick={handleSaveCourse} className="flex-1 shadow-neon-blue/20">
                                    {isEditing ? 'Update Course' : 'Create Course'}
                                </Button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* AI Builder Modal */}
            {
                showAIModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
                        <div className="glass-card w-full max-w-lg p-8 relative animate-slide-up border-purple-500/30 shadow-purple-500/10">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
                            <button onClick={() => !generating && setShowAIModal(false)} className="absolute top-4 right-4 text-gray-500 hover:text-white disabled:opacity-50 transition-colors">
                                <X size={20} />
                            </button>

                            <div className="mb-8 flex items-center gap-4">
                                <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-purple-500/20">
                                    <Sparkles size={28} />
                                </div>
                                <div>
                                    <h2 className="text-2xl font-bold text-white">AI Course Builder</h2>
                                    <p className="text-sm text-gray-400">Generate a structured course with lessons in seconds.</p>
                                </div>
                            </div>

                            <div className="space-y-6 relative z-10">
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Target Topic</label>
                                    <input
                                        type="text"
                                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-purple-500 outline-none transition-colors placeholder:text-gray-600"
                                        placeholder="e.g. Master React Hooks or Python for Finance"
                                        value={aiRequest.topic}
                                        onChange={e => setAiRequest({ ...aiRequest, topic: e.target.value })}
                                        disabled={generating}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Context / Keywords (Optional)</label>
                                    <textarea
                                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-purple-500 outline-none transition-colors h-24 placeholder:text-gray-600 resize-none"
                                        placeholder="Specific areas to cover..."
                                        value={aiRequest.description}
                                        onChange={e => setAiRequest({ ...aiRequest, description: e.target.value })}
                                        disabled={generating}
                                    ></textarea>
                                </div>
                            </div>

                            <div className="mt-8 flex gap-3 relative z-10">
                                <Button variant="secondary" onClick={() => setShowAIModal(false)} className="flex-1 glass-btn border-white/10 hover:border-white/30 text-gray-300" disabled={generating}>
                                    Cancel
                                </Button>
                                <Button
                                    onClick={handleGenerateWithAI}
                                    className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 disabled:opacity-50 border-none"
                                    disabled={generating}
                                >
                                    {generating ? <span className="flex items-center gap-2"><Loader2 className="animate-spin" size={18} /> Generating...</span> : "Generate Modules"}
                                </Button>
                            </div>
                        </div>
                    </div>
                )
            }
        </div >
    );
};

