import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { ArrowLeft, Search, Filter, Download, AlertTriangle, Shield, CheckCircle, XCircle } from 'lucide-react';

export const SecurityLogs = () => {
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [filter, setFilter] = useState('All');

    // Mock Logs Data
    const logs = [
        { id: 1023, timestamp: '2023-10-24 10:45:22', event: 'Failed Login Attempt', source: '192.168.1.45', location: 'Moscow, RU', severity: 'Medium', status: 'Blocked' },
        { id: 1022, timestamp: '2023-10-24 10:42:10', event: 'Admin Login Success', source: '10.0.0.12', location: 'New York, US', severity: 'Low', status: 'Success' },
        { id: 1021, timestamp: '2023-10-24 10:30:05', event: 'SQL Injection Detected', source: '45.33.22.11', location: 'Unknown', severity: 'High', status: 'Blocked' },
        { id: 1020, timestamp: '2023-10-24 10:15:00', event: 'API Rate Limit Exceeded', source: 'Internal Service', location: 'Data Center', severity: 'Medium', status: 'Throttled' },
        { id: 1019, timestamp: '2023-10-24 09:55:12', event: 'New Device Authorized', source: '10.0.0.55', location: 'London, UK', severity: 'Low', status: 'Success' },
        { id: 1018, timestamp: '2023-10-24 09:40:33', event: 'Proctoring Flag: Multiple Faces', source: 'Exam Session #992', location: 'Student ID: 124', severity: 'High', status: 'Flagged' },
        { id: 1017, timestamp: '2023-10-24 09:35:01', event: 'Password Reset Request', source: 'User ID: 8821', location: 'Toronto, CA', severity: 'Low', status: 'Completed' },
        { id: 1016, timestamp: '2023-10-24 09:22:18', event: 'DDoS Traffic Spike', source: 'Multiple IPs', location: 'Global', severity: 'Critical', status: 'Mitigated' },
    ];

    const getSeverityColor = (severity: string) => {
        switch (severity) {
            case 'Critical': return 'text-red-600 bg-red-500/10 border-red-500/20';
            case 'High': return 'text-red-500 bg-red-500/10 border-red-500/20';
            case 'Medium': return 'text-orange-500 bg-orange-500/10 border-orange-500/20';
            case 'Low': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
            default: return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
        }
    };

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/admin/security')}
                            className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
                        >
                            <ArrowLeft size={20} />
                        </button>
                        <div>
                            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                                Security Logs
                            </h1>
                            <p className="text-gray-400 text-sm mt-1">Audit trail of all system events, threats, and access logs.</p>
                        </div>
                    </div>

                    <div className="flex gap-3">
                        <button className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm font-bold border border-gray-700 transition-colors">
                            <Download size={16} /> Export CSV
                        </button>
                    </div>
                </div>

                {/* Filters and Search */}
                <div className="bg-[#161b28] p-4 rounded-xl border border-gray-800 mb-6 flex flex-wrap gap-4 justify-between items-center">
                    <div className="relative flex-1 min-w-[300px]">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" size={18} />
                        <input
                            type="text"
                            placeholder="Search by IP, Event, or User ID..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-gray-900 border border-gray-700 rounded-lg pl-10 pr-4 py-2.5 text-gray-300 focus:outline-none focus:border-emerald-500 transition-colors"
                        />
                    </div>
                    <div className="flex gap-2">
                        {['All', 'Critical', 'High', 'Medium', 'Low'].map(level => (
                            <button
                                key={level}
                                onClick={() => setFilter(level)}
                                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${filter === level
                                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'
                                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                                    }`}
                            >
                                {level}
                            </button>
                        ))}
                    </div>
                    <button className="p-2.5 bg-gray-800 rounded-lg text-gray-400 hover:text-white border border-gray-700">
                        <Filter size={18} />
                    </button>
                </div>

                {/* Logs Table */}
                <div className="bg-[#161b28] rounded-2xl border border-gray-800 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-gray-900/50 text-xs uppercase text-gray-500 border-b border-gray-800">
                                    <th className="p-4 font-bold tracking-wider">Timestamp</th>
                                    <th className="p-4 font-bold tracking-wider">Event</th>
                                    <th className="p-4 font-bold tracking-wider">Source / IP</th>
                                    <th className="p-4 font-bold tracking-wider">Location</th>
                                    <th className="p-4 font-bold tracking-wider">Severity</th>
                                    <th className="p-4 font-bold tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-800">
                                {logs.map((log) => (
                                    <tr key={log.id} className="hover:bg-gray-800/30 transition-colors text-sm">
                                        <td className="p-4 text-gray-400 font-mono text-xs">{log.timestamp}</td>
                                        <td className="p-4 font-bold text-gray-200">
                                            {log.severity === 'Critical' && <AlertTriangle size={14} className="inline mr-2 text-red-500 mb-0.5" />}
                                            {log.event}
                                        </td>
                                        <td className="p-4 text-gray-400">{log.source}</td>
                                        <td className="p-4 text-gray-400">{log.location}</td>
                                        <td className="p-4">
                                            <span className={`px-2 py-1 rounded text-[10px] uppercase font-bold border ${getSeverityColor(log.severity)}`}>
                                                {log.severity}
                                            </span>
                                        </td>
                                        <td className="p-4">
                                            <div className="flex items-center gap-2">
                                                {log.status === 'Success' || log.status === 'Completed' ? (
                                                    <CheckCircle size={14} className="text-emerald-500" />
                                                ) : log.status === 'Mitigated' ? (
                                                    <Shield size={14} className="text-blue-500" />
                                                ) : (
                                                    <XCircle size={14} className="text-gray-500" />
                                                )}
                                                <span className={`${log.status === 'Blocked' ? 'text-red-400' :
                                                    log.status === 'Success' ? 'text-emerald-400' : 'text-gray-400'
                                                    }`}>{log.status}</span>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="p-4 border-t border-gray-800 flex justify-center">
                        <button className="text-xs text-blue-400 hover:text-blue-300 font-bold">Load More Entry Logs</button>
                    </div>
                </div>
            </div>
        </div>
    );
};
