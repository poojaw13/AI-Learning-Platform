import { useState, useEffect, useCallback } from 'react';

import { Award, Plus, FileText, CheckCircle, AlertCircle, Clock, X, Search } from 'lucide-react';
import { Button } from '../../components/Button';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip as RechartsTooltip } from 'recharts';
import client from '../../api/client';
import { toast } from 'react-toastify';

export const AssessmentManager = () => {
    interface Exam {
        id: string;
        title: string;
        type: string;
        candidates?: number;
        passRate?: number;
        status: string;
        duration: number;
        passingScore: number;
    }

    const [exams, setExams] = useState<Exam[]>([]);
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({ totalExams: 0, avgDuration: 0, avgPass: 0 });

    // Modal State
    const [showModal, setShowModal] = useState(false);
    const [showAllExams, setShowAllExams] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [newExam, setNewExam] = useState({ title: '', type: 'MCQ', duration: 60, passingScore: 70, description: '' });

    const fetchExams = useCallback(async () => {
        try {
            const { data } = await client.get('/exams');
            setExams(data);

            // Calculate Stats
            const total = data.length;
            const avgDur = total > 0 ? Math.round(data.reduce((acc: number, curr: Exam) => acc + curr.duration, 0) / total) : 0;
            const avgPass = total > 0 ? Math.round(data.reduce((acc: number, curr: Exam) => acc + (curr.passRate || 0), 0) / total) : 0;

            setStats({ totalExams: total, avgDuration: avgDur, avgPass });
        } catch (error) {
            console.error("Failed to fetch exams", error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchExams();
    }, [fetchExams]);

    const handleCreateExam = async () => {
        try {
            await client.post('/exams', { ...newExam, questions: [] });
            toast.success("Exam created successfully!");
            setShowModal(false);
            fetchExams();
        } catch (error) {
            console.error(error);
            toast.error("Failed to create exam");
        }
    };

    const filteredExams = exams.filter(e =>
        e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.type.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const passRateData = [
        { name: 'Passed', value: 85 },
        { name: 'Failed', value: 15 },
    ];
    const COLORS = ['#10b981', '#ef4444'];

    if (loading) return <div className="min-h-screen bg-[#0f111a] text-white flex items-center justify-center italic-none font-bold uppercase tracking-widest">Initialising Database...</div>;

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100 min-h-screen">
            <div className="p-8 relative">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            Assessment & Exam Manager
                        </h1>
                        <p className="text-gray-400 text-sm mt-1">Create exams, monitor proctoring, and grade submissions.</p>
                    </div>
                    <Button onClick={() => setShowModal(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20 flex items-center gap-2">
                        <Plus size={18} /> Create New Exam
                    </Button>
                </div>

                {/* Top Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div className="bg-[#161b28] p-5 rounded-2xl border border-gray-800">
                        <div className="flex justify-between items-start mb-2">
                            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400"><FileText size={20} /></div>
                            <span className="text-[10px] text-gray-500">Total Exams</span>
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.totalExams}</p>
                    </div>
                    <div className="bg-[#161b28] p-5 rounded-2xl border border-gray-800">
                        <div className="flex justify-between items-start mb-2">
                            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400"><Clock size={20} /></div>
                            <span className="text-[10px] text-gray-500">Avg Duration</span>
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.avgDuration}m</p>
                    </div>
                    <div className="bg-[#161b28] p-5 rounded-2xl border border-gray-800">
                        <div className="flex justify-between items-start mb-2">
                            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400"><CheckCircle size={20} /></div>
                            <span className="text-[10px] text-gray-500">Avg Pass Rate</span>
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.avgPass}%</p>
                    </div>
                    <div className="bg-[#161b28] p-5 rounded-2xl border border-gray-800">
                        <div className="flex justify-between items-start mb-2">
                            <div className="p-2 rounded-lg bg-red-500/10 text-red-400"><AlertCircle size={20} /></div>
                            <span className="text-[10px] text-gray-500">Flagged Attempts</span>
                        </div>
                        <p className="text-2xl font-bold text-white">0</p>
                    </div>
                </div>

                <div className="grid grid-cols-12 gap-8">
                    {/* Exam List */}
                    <div className="col-span-8 bg-[#161b28] rounded-2xl border border-gray-800 group">
                        <div className="p-4 border-b border-gray-800 flex justify-between items-center bg-[#1c2230]/50">
                            <div className="flex items-center gap-4 flex-1">
                                <h3 className="font-bold text-white flex items-center gap-2 whitespace-nowrap"><Award size={18} className="text-yellow-500" /> Recent Exams</h3>
                                <div className="relative max-w-xs w-full">
                                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                                    <input
                                        type="text"
                                        placeholder="Quick filter..."
                                        className="w-full bg-black/30 border border-gray-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white focus:border-emerald-500 outline-none transition-all"
                                        value={searchTerm}
                                        onChange={e => setSearchTerm(e.target.value)}
                                    />
                                </div>
                            </div>
                            <button
                                onClick={() => setShowAllExams(true)}
                                className="text-xs font-black uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors px-3 py-1 bg-emerald-400/5 rounded-lg border border-emerald-400/10 ml-4 hover:scale-105 active:scale-95 transition-all"
                            >
                                View All
                            </button>
                        </div>
                        <div className="max-h-[500px] overflow-y-auto custom-scrollbar">
                            {filteredExams.length === 0 ? (
                                <div className="p-12 text-center text-gray-500 flex flex-col items-center gap-3">
                                    <Search size={48} className="opacity-10" />
                                    <p>No exams found matching "{searchTerm}"</p>
                                    <button onClick={() => setSearchTerm('')} className="text-emerald-400 text-xs font-bold hover:underline">Clear search</button>
                                </div>
                            ) : (
                                <table className="min-w-full divide-y divide-gray-800">
                                    <thead className="bg-[#0f111a] sticky top-0 z-10 shadow-md">
                                        <tr>
                                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wider">Exam Title</th>
                                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wider">Type</th>
                                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wider">Candidates</th>
                                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wider">Status</th>
                                            <th className="px-6 py-4 text-right text-[10px] font-bold text-gray-500 uppercase tracking-wider">Pass Rate</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-800">
                                        {filteredExams.map((exam, idx) => (
                                            <tr key={exam.id || idx} className="hover:bg-gray-800/50 transition-colors cursor-pointer group">
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-200 group-hover:text-emerald-400 transition-colors">
                                                    {exam.title}
                                                    <span className="block text-xs text-gray-500 font-normal mt-0.5">{exam.duration} mins</span>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-xs text-gray-400">{exam.type}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-xs text-gray-300 font-medium">{exam.candidates || 0}</td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <span className={`px-2 py-0.5 inline-flex text-[10px] font-bold uppercase tracking-wide rounded-sm border ${exam.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' :
                                                        'bg-gray-700/50 text-gray-500 border-gray-600'
                                                        }`}>
                                                        {exam.status}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-right">
                                                    <span className={`text-sm font-bold ${(exam.passRate || 0) > 80 ? 'text-emerald-500' :
                                                        (exam.passRate || 0) > 60 ? 'text-yellow-500' : 'text-red-500'
                                                        }`}>
                                                        {exam.passRate}%
                                                    </span>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            )}
                        </div>
                    </div>

                    {/* Quick Stats / Charts */}
                    <div className="col-span-4 space-y-6">
                        <div className="bg-[#161b28] rounded-2xl border border-gray-800 p-6">
                            <h3 className="font-bold text-white mb-4">Overall Performance</h3>
                            <div className="h-48 w-full relative">
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie
                                            data={passRateData}
                                            cx="50%"
                                            cy="50%"
                                            innerRadius={50}
                                            outerRadius={70}
                                            fill="#8884d8"
                                            paddingAngle={5}
                                            dataKey="value"
                                        >
                                            {passRateData.map((_, index) => (
                                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                            ))}
                                        </Pie>
                                        <RechartsTooltip contentStyle={{ backgroundColor: '#111827', border: 'none', color: '#fff' }} />
                                    </PieChart>
                                </ResponsiveContainer>
                                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
                                    <span className="block text-xl font-bold text-white">85%</span>
                                    <span className="text-[10px] text-gray-500 uppercase">Pass Rate</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Create Exam Modal */}
                {showModal && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                        <div className="bg-[#161b28] border border-gray-700 rounded-2xl w-full max-w-lg p-6 relative animate-fade-in-up">
                            <button onClick={() => setShowModal(false)} className="absolute top-4 right-4 text-gray-500 hover:text-white">
                                <X size={20} />
                            </button>
                            <h2 className="text-xl font-bold text-white mb-6">Create New Exam</h2>

                            <div className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Exam Title</label>
                                    <input
                                        type="text"
                                        className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-emerald-500 outline-none transition-colors"
                                        placeholder="e.g. Advanced Python Certification"
                                        value={newExam.title}
                                        onChange={e => setNewExam({ ...newExam, title: e.target.value })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Type</label>
                                        <select
                                            className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-emerald-500 outline-none transition-colors"
                                            value={newExam.type}
                                            onChange={e => setNewExam({ ...newExam, type: e.target.value })}
                                        >
                                            <option value="MCQ">Multiple Choice</option>
                                            <option value="CODING">Coding Challenge</option>
                                            <option value="HYBRID">Hybrid</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Duration (mins)</label>
                                        <input
                                            type="number"
                                            className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-emerald-500 outline-none transition-colors"
                                            value={newExam.duration}
                                            onChange={e => setNewExam({ ...newExam, duration: parseInt(e.target.value) })}
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Passing Score (%)</label>
                                    <input
                                        type="number"
                                        className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-emerald-500 outline-none transition-colors"
                                        value={newExam.passingScore}
                                        onChange={e => setNewExam({ ...newExam, passingScore: parseInt(e.target.value) })}
                                    />
                                </div>
                            </div>

                            <div className="mt-8 flex gap-3">
                                <Button onClick={() => setShowModal(false)} className="flex-1 bg-gray-800 hover:bg-gray-700 text-white border border-gray-700">Cancel</Button>
                                <Button onClick={handleCreateExam} className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20">Create Exam</Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* View All Exams Modal */}
                {showAllExams && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[99999] flex items-center justify-center p-6 md:p-12 overflow-hidden">
                        <div className="bg-[#161b28] border border-white/10 rounded-[40px] w-full max-w-7xl max-h-[90vh] flex flex-col overflow-hidden animate-zoom-in shadow-[0_0_150px_rgba(0,0,0,0.8)]">
                            <div className="p-10 border-b border-white/5 flex justify-between items-center bg-white/2 relative">
                                <div className="max-w-4xl">
                                    <h2 className="text-4xl font-black text-white italic-none tracking-tighter uppercase leading-none">Comprehensive Registry</h2>
                                    <p className="text-gray-400 text-base mt-3 font-medium opacity-80 italic-none">Full access to all {exams.length} active cognitive assessments and proctored examinations.</p>
                                </div>
                                <button
                                    onClick={() => setShowAllExams(false)}
                                    className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-red-500/20 hover:text-red-400 transition-all border border-white/10 shrink-0"
                                >
                                    <X size={24} />
                                </button>
                            </div>

                            <div className="p-8 bg-black/20 flex-1 overflow-y-auto custom-scrollbar">
                                <div className="mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
                                    <div className="relative flex-1 w-full">
                                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
                                        <input
                                            type="text"
                                            placeholder="Deep search by title, type, or status..."
                                            className="w-full bg-gray-900/50 border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-white focus:border-neon-blue focus:ring-4 focus:ring-neon-blue/10 outline-none transition-all text-sm font-medium"
                                            value={searchTerm}
                                            onChange={e => setSearchTerm(e.target.value)}
                                        />
                                    </div>
                                    <div className="flex gap-4 w-full md:w-auto">
                                        <div className="glass-panel px-4 py-2 rounded-xl border border-white/5 flex items-center gap-2">
                                            <span className="text-[10px] font-black uppercase tracking-widest text-gray-500">Total Exams:</span>
                                            <span className="text-sm font-black text-neon-blue">{exams.length}</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="rounded-2xl border border-white/5 overflow-hidden shadow-2xl">
                                    <table className="min-w-full divide-y divide-white/5">
                                        <thead className="bg-white/5">
                                            <tr>
                                                <th className="px-8 py-5 text-left text-[11px] font-black text-gray-400 uppercase tracking-widest">Assessment Detail</th>
                                                <th className="px-8 py-5 text-left text-[11px] font-black text-gray-400 uppercase tracking-widest">Modality</th>
                                                <th className="px-8 py-5 text-left text-[11px] font-black text-gray-400 uppercase tracking-widest">Candidates</th>
                                                <th className="px-8 py-5 text-left text-[11px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                                                <th className="px-8 py-5 text-right text-[11px] font-black text-gray-400 uppercase tracking-widest">Performance</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-white/5 bg-[#0f111a]/40">
                                            {filteredExams.map((exam, idx) => (
                                                <tr key={exam.id || idx} className="hover:bg-white/5 transition-all group">
                                                    <td className="px-8 py-6 whitespace-nowrap">
                                                        <div className="flex items-center gap-4">
                                                            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center border border-white/10 group-hover:border-neon-blue/50 transition-all">
                                                                <FileText size={18} className="text-gray-400 group-hover:text-neon-blue transition-colors" />
                                                            </div>
                                                            <div>
                                                                <h4 className="text-sm font-black text-white group-hover:text-neon-blue transition-colors">{exam.title}</h4>
                                                                <div className="flex items-center gap-2 text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">
                                                                    <Clock size={10} /> {exam.duration} Minutes • Goal: {exam.passingScore}%
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-6 whitespace-nowrap">
                                                        <span className="text-xs font-black text-gray-400 uppercase tracking-widest bg-white/5 px-2 py-1 rounded border border-white/5">{exam.type}</span>
                                                    </td>
                                                    <td className="px-8 py-6 whitespace-nowrap">
                                                        <div className="flex -space-x-2">
                                                            {[1, 2, 3].map(i => (
                                                                <div key={i} className="w-6 h-6 rounded-full border-2 border-[#161b28] bg-gray-800 flex items-center justify-center text-[8px] font-bold text-gray-400">
                                                                    {String.fromCharCode(64 + i)}
                                                                </div>
                                                            ))}
                                                            <div className="w-6 h-6 rounded-full border-2 border-[#161b28] bg-gray-900 flex items-center justify-center text-[8px] font-bold text-neon-blue">
                                                                +{exam.candidates || 0}
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-6 whitespace-nowrap">
                                                        <div className="flex items-center gap-2">
                                                            <div className={`w-1.5 h-1.5 rounded-full ${exam.status === 'ACTIVE' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-gray-500'}`}></div>
                                                            <span className={`text-[10px] font-black uppercase tracking-widest ${exam.status === 'ACTIVE' ? 'text-emerald-400' : 'text-gray-500'}`}>
                                                                {exam.status}
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-6 whitespace-nowrap text-right">
                                                        <div className="flex flex-col items-end">
                                                            <span className={`text-lg font-black tracking-tighter ${exam.passRate && exam.passRate > 80 ? 'text-emerald-400' : 'text-yellow-400'}`}>
                                                                {exam.passRate}%
                                                            </span>
                                                            <div className="w-24 h-1 bg-gray-800 rounded-full mt-2 overflow-hidden border border-white/5">
                                                                <div className={`h-full bg-gradient-to-r ${exam.passRate && exam.passRate > 80 ? 'from-emerald-500 to-teal-400' : 'from-yellow-400 to-orange-400'}`} style={{ width: `${exam.passRate}%` }}></div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div className="p-6 border-t border-white/5 bg-white/5 flex justify-center uppercase tracking-[0.2em] text-[9px] font-black text-gray-600">
                                Total Assessment Integrity Index: High Accuracy Stream
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

