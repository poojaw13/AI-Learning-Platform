import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

import { ArrowLeft, Save, Sliders, Activity } from 'lucide-react';
import { Button } from '../../components/Button';
import { toast } from 'react-toastify';

export const ModelConfig = () => {
    const { modelId } = useParams();
    const navigate = useNavigate();

    // Mock configuration state
    const [config, setConfig] = useState({
        threshold: 85,
        latencyBudget: 50,
        learningRate: 0.001,
        batchSize: 32,
        biasMitigation: true,
        autoRetrain: false
    });

    const handleSave = () => {
        toast.success("Model configuration saved successfully!");
        // Simulate API call delay
        setTimeout(() => navigate('/admin/ai'), 1000);
    };

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="flex items-center gap-4 mb-8">
                    <button
                        onClick={() => navigate('/admin/ai')}
                        className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
                    >
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            Model Configuration
                        </h1>
                        <p className="text-gray-400 text-sm mt-1">Adjust hyperparameters and operational settings for Model #{modelId}</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Main Configuration Panel */}
                    <div className="bg-[#161b28] p-6 rounded-2xl border border-gray-800">
                        <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                            <Sliders size={20} className="text-emerald-500" /> Core Parameters
                        </h2>

                        <div className="space-y-6">
                            <div>
                                <label className="flex justify-between text-sm font-bold text-gray-400 mb-2">
                                    Confidence Threshold
                                    <span className="text-emerald-400">{config.threshold}%</span>
                                </label>
                                <input
                                    type="range"
                                    min="50"
                                    max="99"
                                    value={config.threshold}
                                    onChange={(e) => setConfig({ ...config, threshold: parseInt(e.target.value) })}
                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                                />
                                <p className="text-xs text-gray-500 mt-1">Minimum confidence score required for automated decisions.</p>
                            </div>

                            <div>
                                <label className="flex justify-between text-sm font-bold text-gray-400 mb-2">
                                    Max Latency (ms)
                                    <span className="text-blue-400">{config.latencyBudget}ms</span>
                                </label>
                                <input
                                    type="range"
                                    min="10"
                                    max="500"
                                    value={config.latencyBudget}
                                    onChange={(e) => setConfig({ ...config, latencyBudget: parseInt(e.target.value) })}
                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Learning Rate</label>
                                    <input
                                        type="number"
                                        step="0.0001"
                                        value={config.learningRate}
                                        onChange={(e) => setConfig({ ...config, learningRate: parseFloat(e.target.value) })}
                                        className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-emerald-500 outline-none transition-colors"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Batch Size</label>
                                    <select
                                        value={config.batchSize}
                                        onChange={(e) => setConfig({ ...config, batchSize: parseInt(e.target.value) })}
                                        className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-emerald-500 outline-none transition-colors"
                                    >
                                        <option value="16">16</option>
                                        <option value="32">32</option>
                                        <option value="64">64</option>
                                        <option value="128">128</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Advanced Settings */}
                    <div className="space-y-6">
                        <div className="bg-[#161b28] p-6 rounded-2xl border border-gray-800">
                            <h2 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                                <Activity size={20} className="text-purple-500" /> Operational Modes
                            </h2>

                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-xl border border-gray-700">
                                    <div>
                                        <h4 className="font-bold text-gray-200">Bias Mitigation</h4>
                                        <p className="text-xs text-gray-500">Apply adversarial filtering to reduce demographic bias.</p>
                                    </div>
                                    <div
                                        onClick={() => setConfig({ ...config, biasMitigation: !config.biasMitigation })}
                                        className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors ${config.biasMitigation ? 'bg-purple-600' : 'bg-gray-600'}`}
                                    >
                                        <div className={`w-4 h-4 bg-white rounded-full transition-transform ${config.biasMitigation ? 'translate-x-6' : ''}`}></div>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-xl border border-gray-700">
                                    <div>
                                        <h4 className="font-bold text-gray-200">Auto-Retrain</h4>
                                        <p className="text-xs text-gray-500">Automatically schedule retraining when drift &gt; 5%.</p>
                                    </div>
                                    <div
                                        onClick={() => setConfig({ ...config, autoRetrain: !config.autoRetrain })}
                                        className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-colors ${config.autoRetrain ? 'bg-emerald-600' : 'bg-gray-600'}`}
                                    >
                                        <div className={`w-4 h-4 bg-white rounded-full transition-transform ${config.autoRetrain ? 'translate-x-6' : ''}`}></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-4">
                            <Button onClick={() => navigate('/admin/ai')} className="flex-1 bg-gray-800 hover:bg-gray-700 text-white border border-gray-700">
                                Cancel
                            </Button>
                            <Button onClick={handleSave} className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2">
                                <Save size={18} /> Save Config
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
