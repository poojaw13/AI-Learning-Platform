
import { Shield, Lock, AlertTriangle, Activity, Server, Database, Globe, XCircle } from 'lucide-react';
import { toast } from 'react-toastify';
import { Button } from '../../components/Button';


export const SecurityDashboard = () => {
    // Mock Data
    const threats = [
        { id: 1, type: 'Failed Login', source: 'IP 192.168.1.45', location: 'Moscow, RU', time: '2 mins ago', severity: 'Medium' },
        { id: 2, type: 'SQL Injection Attempt', source: 'User Agent: Bot', location: 'Unknown', time: '15 mins ago', severity: 'High' },
        { id: 3, type: 'Proctoring Flag', source: 'Exam Session #8992', location: 'Student ID: 124', time: '1 hour ago', severity: 'Low' },
        { id: 4, type: 'API Rate Limit', source: 'Service: Analytics', location: 'Internal', time: '3 hours ago', severity: 'Medium' },
    ];

    const healthStatus = [
        { name: 'Primary Database', status: 'Operational', latency: '12ms', icon: Database },
        { name: 'Redis Cache', status: 'Operational', latency: '4ms', icon: Server },
        { name: 'API Gateway', status: 'Operational', latency: '45ms', icon: Globe },
        { name: 'AI Inference Node', status: 'Busy', latency: '850ms', icon: Activity },
    ];

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            Security & Integrity
                        </h1>
                        <p className="text-gray-400 text-sm mt-1">Monitor threats, system health, and compliance logs.</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                    {/* Security Score Card */}
                    <div className="lg:col-span-2 bg-gradient-to-r from-emerald-900/50 to-teal-900/50 rounded-2xl p-8 border border-emerald-500/30 flex items-center justify-between">
                        <div>
                            <div className="flex items-center gap-2 mb-2">
                                <Shield className="text-emerald-400" size={32} />
                                <h2 className="text-2xl font-bold text-white">System Secure</h2>
                            </div>
                            <p className="text-emerald-200/80 max-w-lg">
                                No critical vulnerabilities detected. All firewalls and monitoring systems are active. Last scan completed 15 mins ago.
                            </p>
                        </div>
                        <div className="text-center">
                            <span className="block text-5xl font-bold text-white mb-1">98%</span>
                            <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">Security Score</span>
                        </div>
                    </div>

                    {/* Active Alerts Count */}
                    <div className="bg-[#161b28] border border-gray-800 rounded-2xl p-6 flex flex-col justify-center items-center text-center">
                        <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mb-4 text-red-500">
                            <AlertTriangle size={32} />
                        </div>
                        <h3 className="text-3xl font-bold text-white mb-1">3</h3>
                        <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Active Alerts</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Live Threat Feed */}
                    <div className="bg-[#161b28] border border-gray-800 rounded-2xl overflow-hidden">
                        <div className="p-6 border-b border-gray-800 flex justify-between items-center">
                            <h3 className="font-bold text-white flex items-center gap-2"><Lock size={18} className="text-red-400" /> Live Threat Monitor</h3>
                            <Button
                                onClick={() => toast.info("Opening detailed security logs...")}
                                className="py-1 px-3 text-xs bg-gray-800 hover:bg-gray-700"
                            >
                                View Logs
                            </Button>
                        </div>
                        <div className="p-0">
                            {threats.map(threat => (
                                <div key={threat.id} className="p-4 border-b border-gray-800/50 flex items-center justify-between hover:bg-gray-800/30 transition-colors">
                                    <div className="flex items-start gap-3">
                                        <div className="mt-1">
                                            {threat.severity === 'High' ? <XCircle size={16} className="text-red-500" /> : <AlertTriangle size={16} className="text-yellow-500" />}
                                        </div>
                                        <div>
                                            <h4 className="text-sm font-bold text-gray-200">{threat.type}</h4>
                                            <p className="text-xs text-gray-500">{threat.source} • {threat.location}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${threat.severity === 'High' ? 'bg-red-500/10 text-red-500 border-red-500/20' :
                                            threat.severity === 'Medium' ? 'bg-orange-500/10 text-orange-500 border-orange-500/20' :
                                                'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                                            }`}>
                                            {threat.severity}
                                        </span>
                                        <span className="block text-[10px] text-gray-600 mt-1">{threat.time}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* System Health Status */}
                    <div className="bg-[#161b28] border border-gray-800 rounded-2xl overflow-hidden">
                        <div className="p-6 border-b border-gray-800">
                            <h3 className="font-bold text-white flex items-center gap-2"><Activity size={18} className="text-emerald-400" /> System Health</h3>
                        </div>
                        <div className="p-6 grid grid-cols-1 gap-4">
                            {healthStatus.map((item, index) => (
                                <div key={index} className="flex items-center justify-between p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                                    <div className="flex items-center gap-4">
                                        <div className="p-2 bg-gray-800 rounded-lg text-blue-400">
                                            <item.icon size={20} />
                                        </div>
                                        <div>
                                            <h4 className="text-sm font-bold text-gray-200">{item.name}</h4>
                                            <span className={`text-xs flex items-center gap-1.5 ${item.status === 'Operational' ? 'text-emerald-500' : 'text-yellow-500'}`}>
                                                <div className={`w-1.5 h-1.5 rounded-full ${item.status === 'Operational' ? 'bg-emerald-500' : 'bg-yellow-500'}`}></div>
                                                {item.status}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <span className="block text-xs font-bold text-gray-400">{item.latency}</span>
                                        <span className="text-[10px] text-gray-600 uppercase">Latency</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
