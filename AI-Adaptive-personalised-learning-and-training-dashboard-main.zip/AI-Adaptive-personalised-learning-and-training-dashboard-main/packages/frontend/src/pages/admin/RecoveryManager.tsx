import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { ArrowLeft, CheckCircle, Clock, FileText, Send, Zap } from 'lucide-react';
import { toast } from 'react-toastify';

export const RecoveryManager = () => {
    const navigate = useNavigate();

    // Mock Recovery Plans
    const [plans, setPlans] = useState([
        {
            id: 1,
            student: "Alex Morgan",
            risk: 92,
            course: "Computer Science 101",
            status: "Ready",
            modules: ["Variable Scope Refresher", "Memory Management Visualizer"],
            generatedAt: "2 mins ago"
        },
        {
            id: 2,
            student: "Sarah Connor",
            risk: 88,
            course: "Physics 202",
            status: "Ready",
            modules: ["Kinematics Practice Set", "Force Vectors Interactive"],
            generatedAt: "2 mins ago"
        },
        {
            id: 3,
            student: "John Smith",
            risk: 75,
            course: "Calculus I",
            status: "Processing",
            modules: [],
            generatedAt: "Just now"
        },
    ]);

    const handleDeploy = (id: number) => {
        setPlans(plans.map(p => p.id === id ? { ...p, status: 'Deployed' } : p));
        toast.success("Recovery plan sent to student portal!");
    };

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="flex items-center gap-4 mb-8">
                    <button
                        onClick={() => navigate('/admin/intelligence')}
                        className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
                    >
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            <Zap className="text-yellow-400" size={24} />
                            Batch Recovery Manager
                        </h1>
                        <p className="text-gray-400 text-sm mt-1">Review and deploy AI-generated intervention content.</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* List of Plans */}
                    <div className="lg:col-span-2 space-y-4">
                        {plans.map((plan) => (
                            <div key={plan.id} className="bg-[#161b28] border border-gray-800 p-6 rounded-2xl flex justify-between items-center group hover:border-gray-700 transition-all">
                                <div>
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 font-bold">
                                            {plan.student.charAt(0)}
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-white">{plan.student}</h3>
                                            <p className="text-xs text-gray-500">{plan.course}</p>
                                        </div>
                                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ml-2 ${plan.risk > 90 ? 'bg-red-500/10 text-red-500' : 'bg-orange-500/10 text-orange-500'
                                            }`}>
                                            {plan.risk}% Risk
                                        </span>
                                    </div>

                                    <div className="ml-13 pl-13">
                                        {plan.status === 'Processing' ? (
                                            <div className="flex items-center gap-2 text-xs text-indigo-400 animate-pulse">
                                                <Zap size={12} /> Generating content...
                                            </div>
                                        ) : (
                                            <div className="flex gap-2 mt-3">
                                                {plan.modules.map((mod, i) => (
                                                    <span key={i} className="flex items-center gap-1 text-[10px] bg-indigo-500/10 text-indigo-300 px-2 py-1 rounded border border-indigo-500/20">
                                                        <FileText size={10} /> {mod}
                                                    </span>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div className="text-right flex flex-col items-end gap-3">
                                    <span className="text-[10px] text-gray-500 flex items-center gap-1">
                                        <Clock size={10} /> {plan.generatedAt}
                                    </span>

                                    {plan.status === 'Deployed' ? (
                                        <button disabled className="px-4 py-2 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 rounded-xl text-xs font-bold flex items-center gap-2 cursor-default">
                                            <CheckCircle size={14} /> Deployed
                                        </button>
                                    ) : plan.status === 'Processing' ? (
                                        <button disabled className="px-4 py-2 bg-gray-800 text-gray-500 rounded-xl text-xs font-bold cursor-wait">
                                            Please Wait
                                        </button>
                                    ) : (
                                        <button
                                            onClick={() => handleDeploy(plan.id)}
                                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors shadow-lg shadow-indigo-500/20"
                                        >
                                            <Send size={14} /> Deploy Plan
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Sidebar Stats */}
                    <div className="space-y-6">
                        <div className="bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border border-indigo-500/20 p-6 rounded-2xl">
                            <h3 className="font-bold text-white mb-4">Batch Summary</h3>
                            <div className="space-y-4">
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-gray-400">Total Students</span>
                                    <span className="font-bold text-white">3</span>
                                </div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-gray-400">Est. Recovery Rate</span>
                                    <span className="font-bold text-emerald-400">+12%</span>
                                </div>
                                <div className="w-full h-px bg-gray-700 my-4"></div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-gray-400">Status</span>
                                    <span className="text-indigo-400 font-bold flex items-center gap-2">
                                        <span className="relative flex h-2 w-2">
                                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                                            <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                                        </span>
                                        Active
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
