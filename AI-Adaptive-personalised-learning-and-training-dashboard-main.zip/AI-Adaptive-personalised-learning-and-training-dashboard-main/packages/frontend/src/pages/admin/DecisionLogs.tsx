import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { ArrowLeft, Search, Brain } from 'lucide-react';

export const DecisionLogs = () => {
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [filter, setFilter] = useState('All');

    // Mock Decision Logs
    const decisions = [
        { id: 1, action: 'Flagged Content', target: 'Essay #892', reason: 'High similarity to known source', confidence: 98, time: '10m ago', status: 'Review Needed' },
        { id: 2, action: 'Adjusted Pathway', target: 'Student: John Doe', reason: 'Struggling with Quadratics', confidence: 85, time: '1h ago', status: 'Auto-Approved' },
        { id: 3, action: 'Generated Quiz', target: 'Course: React Basics', reason: 'Routine content generation', confidence: 92, time: '2h ago', status: 'Published' },
        { id: 4, action: 'Detected Emotion', target: 'Student: Sarah C.', reason: 'Frustration signal in chat', confidence: 78, time: '3h ago', status: 'Flagged' },
        { id: 5, action: 'Recommended Resource', target: 'Student: Mike T.', reason: 'Prerequisite gap identified', confidence: 89, time: '4h ago', status: 'Auto-Approved' },
        { id: 6, action: 'Blocked Login', target: 'IP 192.168.1.5', reason: 'Suspicious location pattern', confidence: 99, time: '5h ago', status: 'Blocked' },
    ];

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Published':
            case 'Auto-Approved': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
            case 'Review Needed':
            case 'Flagged': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
            case 'Blocked': return 'text-red-500 bg-red-500/10 border-red-500/20';
            default: return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
        }
    };

    const filteredDecisions = decisions.filter(decision => {
        const matchesSearch =
            decision.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
            decision.target.toLowerCase().includes(searchTerm.toLowerCase()) ||
            decision.reason.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesFilter = filter === 'All' || decision.status === filter;

        return matchesSearch && matchesFilter;
    });

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/admin/ai')}
                            className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
                        >
                            <ArrowLeft size={20} />
                        </button>
                        <div>
                            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                                <Brain className="text-purple-500" size={24} />
                                AI Decision Logs
                            </h1>
                            <p className="text-gray-400 text-sm mt-1">Audit trail of automated decisions, reasoning, and confidence scores.</p>
                        </div>
                    </div>
                </div>

                {/* Filters */}
                <div className="bg-[#161b28] p-4 rounded-xl border border-gray-800 mb-6 flex flex-wrap gap-4 justify-between items-center">
                    <div className="relative flex-1 min-w-[300px]">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" size={18} />
                        <input
                            type="text"
                            placeholder="Search by Target, Action, or Reason..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-gray-900 border border-gray-700 rounded-lg pl-10 pr-4 py-2.5 text-gray-300 focus:outline-none focus:border-purple-500 transition-colors"
                        />
                    </div>
                    <div className="flex gap-2">
                        {['All', 'Auto-Approved', 'Review Needed', 'Flagged'].map(level => (
                            <button
                                key={level}
                                onClick={() => setFilter(level)}
                                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${filter === level
                                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                                    }`}
                            >
                                {level}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Decisions Table */}
                <div className="bg-[#161b28] rounded-2xl border border-gray-800 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-gray-900/50 text-xs uppercase text-gray-500 border-b border-gray-800">
                                    <th className="p-4 font-bold tracking-wider">Action / Target</th>
                                    <th className="p-4 font-bold tracking-wider">Reasoning</th>
                                    <th className="p-4 font-bold tracking-wider">Confidence</th>
                                    <th className="p-4 font-bold tracking-wider">Status</th>
                                    <th className="p-4 font-bold tracking-wider">Time</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-800">
                                {filteredDecisions.length > 0 ? (
                                    filteredDecisions.map((decision) => (
                                        <tr key={decision.id} className="hover:bg-gray-800/30 transition-colors text-sm">
                                            <td className="p-4">
                                                <div className="font-bold text-gray-200">{decision.action}</div>
                                                <div className="text-xs text-gray-500 mt-1">{decision.target}</div>
                                            </td>
                                            <td className="p-4 text-gray-400 italic">"{decision.reason}"</td>
                                            <td className="p-4">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-16 bg-gray-700 h-1.5 rounded-full overflow-hidden">
                                                        <div
                                                            className={`h-full rounded-full ${decision.confidence > 90 ? 'bg-emerald-500' : 'bg-yellow-500'}`}
                                                            style={{ width: `${decision.confidence}%` }}
                                                        ></div>
                                                    </div>
                                                    <span className="text-xs font-bold text-gray-400">{decision.confidence}%</span>
                                                </div>
                                            </td>
                                            <td className="p-4">
                                                <span className={`px-2 py-1 rounded text-[10px] uppercase font-bold border ${getStatusColor(decision.status)}`}>
                                                    {decision.status}
                                                </span>
                                            </td>
                                            <td className="p-4 text-gray-500 text-xs">{decision.time}</td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan={5} className="p-12 text-center text-gray-500 italic">
                                            No decisions match your search criteria.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                    <div className="p-4 border-t border-gray-800 flex justify-center">
                        <button className="text-xs text-blue-400 hover:text-blue-300 font-bold">Load More Decisions</button>
                    </div>
                </div>
            </div>
        </div>
    );
};
