import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

import { ArrowLeft, Play, CheckCircle, AlertTriangle, Terminal, Activity } from 'lucide-react';
import { Button } from '../../components/Button';

export const ModelTesting = () => {
    const { modelId } = useParams();
    const navigate = useNavigate();
    const [isRunning, setIsRunning] = useState(false);
    const [logs, setLogs] = useState<string[]>([]);
    const [progress, setProgress] = useState(0);
    const [status, setStatus] = useState<'idle' | 'running' | 'success' | 'failed'>('idle');

    const runDiagnostics = () => {
        setIsRunning(true);
        setStatus('running');
        setLogs(['Initializing test environment...']);
        setProgress(10);

        const steps = [
            { msg: 'Loading validation dataset (10,000 samples)...', time: 1000, prog: 30 },
            { msg: 'Checking inference latency...', time: 2000, prog: 50 },
            { msg: 'Verifying output schema...', time: 3000, prog: 70 },
            { msg: 'Running bias check...', time: 4000, prog: 90 },
            { msg: 'Test suite completed successfully.', time: 5000, prog: 100 },
        ];

        steps.forEach((step) => {
            setTimeout(() => {
                setLogs(prev => [...prev, `> ${step.msg}`]);
                setProgress(step.prog);
                if (step.prog === 100) {
                    setIsRunning(false);
                    setStatus('success');
                }
            }, step.time);
        });
    };

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                <div className="flex items-center gap-4 mb-8">
                    <button
                        onClick={() => navigate('/admin/ai')}
                        className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
                    >
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                            Model Diagnostics
                        </h1>
                        <p className="text-gray-400 text-sm mt-1">Run validation tests for Model #{modelId}</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2">
                        <div className="bg-[#161b28] rounded-2xl border border-gray-800 overflow-hidden shadow-xl">
                            <div className="bg-gray-900 px-4 py-2 border-b border-gray-800 flex items-center gap-2">
                                <Terminal size={14} className="text-gray-500" />
                                <span className="text-xs font-mono text-gray-400">Live Diagnostic Terminal</span>
                            </div>
                            <div className="p-6 font-mono text-sm h-96 overflow-y-auto space-y-2">
                                {logs.length === 0 && <span className="text-gray-600">Click 'Run Diagnostics' to start...</span>}
                                {logs.map((log, i) => (
                                    <div key={i} className="text-emerald-400">{log}</div>
                                ))}
                                {isRunning && (
                                    <div className="animate-pulse text-emerald-500">_</div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <div className="bg-[#161b28] p-6 rounded-2xl border border-gray-800">
                            <h3 className="font-bold text-white mb-4">Test Status</h3>

                            <div className="mb-6">
                                <div className="flex justify-between text-xs text-gray-400 mb-2">
                                    <span>Progress</span>
                                    <span>{progress}%</span>
                                </div>
                                <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden">
                                    <div
                                        className="bg-emerald-500 h-full transition-all duration-500 ease-out"
                                        style={{ width: `${progress}%` }}
                                    ></div>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <div className={`flex items-center gap-3 p-3 rounded-xl border ${status === 'success' ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-gray-800 border-gray-700'}`}>
                                    <CheckCircle size={18} className={status === 'success' ? 'text-emerald-500' : 'text-gray-600'} />
                                    <span className={status === 'success' ? 'text-emerald-400' : 'text-gray-500'}>Validation Check</span>
                                </div>
                                <div className={`flex items-center gap-3 p-3 rounded-xl border ${progress > 50 ? 'bg-blue-500/10 border-blue-500/20' : 'bg-gray-800 border-gray-700'}`}>
                                    <Activity size={18} className={progress > 50 ? 'text-blue-500' : 'text-gray-600'} />
                                    <span className={progress > 50 ? 'text-blue-400' : 'text-gray-500'}>Latency Check</span>
                                </div>
                                <div className={`flex items-center gap-3 p-3 rounded-xl border ${progress > 80 ? 'bg-purple-500/10 border-purple-500/20' : 'bg-gray-800 border-gray-700'}`}>
                                    <AlertTriangle size={18} className={progress > 80 ? 'text-purple-500' : 'text-gray-600'} />
                                    <span className={progress > 80 ? 'text-purple-400' : 'text-gray-500'}>Bias Audit</span>
                                </div>
                            </div>

                            <Button
                                onClick={runDiagnostics}
                                disabled={isRunning}
                                className="w-full mt-6 bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
                            >
                                {isRunning ? 'Running...' : <><Play size={16} /> Run Diagnostics</>}
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
