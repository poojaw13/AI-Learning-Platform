import { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import client from '../../api/client';
import { Button } from '../../components/Button';
import { Activity, Users, AlertTriangle, Cpu, BookOpen, Award, TrendingUp, AlertCircle, Lock, Shield, Zap } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export const AdminDashboard = () => {
    // Data State
    const [loading, setLoading] = useState(true);
    const [showGlobalActions, setShowGlobalActions] = useState(false);
    const [isLockdownActive, setIsLockdownActive] = useState(false);
    const [kpis, setKpis] = useState<any[]>([]);
    const [growthData, setGrowthData] = useState<{ name: string; students: number; courses: number }[]>([]);
    const [skillDistribution, setSkillDistribution] = useState<{ name: string; value: number }[]>([]);
    const [recentAlerts, setRecentAlerts] = useState<{ id: string; description: string; severity: string; createdAt: string }[]>([]);

    // Action Handlers
    const handleLockdown = () => {
        setIsLockdownActive(!isLockdownActive);
        toast.warning(isLockdownActive ? "Security lockdown deactivated." : "SYSTEM LOCKDOWN INITIATED. Access restricted.");
        setShowGlobalActions(false);
    };

    const handleClearCache = () => {
        toast.promise(
            new Promise(resolve => setTimeout(resolve, 1500)),
            {
                pending: 'Clearing AI Model Cache...',
                success: 'AI Models Refreshed successfully',
                error: 'Failed to clear cache'
            }
        );
        setShowGlobalActions(false);
    };

    const handleBroadcast = () => {
        const msg = prompt("Enter broadcast message for all users:");
        if (msg) toast.success(`Broadcast sent: "${msg}"`);
        setShowGlobalActions(false);
    };

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const { data } = await client.get('/analytics/admin-stats');
                if (data && data.kpis) {
                    setKpis([
                        { label: 'Total Users', val: data.kpis.totalUsers, color: 'text-neon-blue', icon: Users, change: 'Active Database' },
                        { label: 'Active Today', val: data.kpis.activeToday, color: 'text-neon-green', icon: Activity, change: 'Real-time' },
                        { label: 'Courses Active', val: data.kpis.coursesActive, color: 'text-neon-purple', icon: BookOpen, change: `${data.kpis.totalCourses} total` },
                        { label: 'Certificates', val: data.kpis.totalCertificates, color: 'text-yellow-400', icon: Award, change: 'Lifetime' },
                        { label: 'AI Status', val: data.kpis.systemStatus, color: 'text-neon-green', icon: Cpu, change: '99.9% uptime' },
                        { label: 'Integrity Alerts', val: data.kpis.integrityAlerts, color: 'text-red-500', icon: AlertTriangle, change: 'Requires Action' },
                    ]);
                    setGrowthData(data.growthData || []);
                    setSkillDistribution(data.skillDistribution || []);
                    setRecentAlerts(data.recentAlerts || []);
                }
            } catch (error) {
                console.error("Failed to fetch admin stats", error);
            } finally {
                setLoading(false);
            }
        };
        fetchStats();
    }, []);

    if (loading) return (
        <div className="flex items-center justify-center h-96">
            <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 rounded-full border-4 border-neon-blue border-t-transparent animate-spin"></div>
                <p className="text-neon-blue font-mono animate-pulse">Initializing Command Center...</p>
            </div>
        </div>
    );

    return (
        <div className={`space-y-8 animate-fade-in-up ${isLockdownActive ? 'ring-4 ring-red-500/50 rounded-2xl p-4' : ''}`}>
            {isLockdownActive && (
                <div className="bg-red-500/10 border border-red-500/30 p-4 rounded-xl flex items-center justify-between animate-pulse">
                    <div className="flex items-center gap-3">
                        <AlertTriangle className="text-red-500" />
                        <div>
                            <p className="text-red-500 font-bold uppercase tracking-widest text-sm">Emergency Lockdown Active</p>
                            <p className="text-red-400/70 text-xs">All non-admin API write operations are currently restricted.</p>
                        </div>
                    </div>
                    <Button variant="danger" size="sm" onClick={() => setIsLockdownActive(false)}>Deactivate</Button>
                </div>
            )}

            {/* Header */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">
                        Admin <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">Command Center</span>
                    </h1>
                    <p className="text-gray-400 flex items-center gap-2">
                        <Shield size={14} className="text-neon-green" />
                        System Operational • Real-time Monitoring Active
                    </p>
                </div>
                <div className="flex gap-3">
                    <div className={`glass-panel px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${isLockdownActive ? 'bg-red-500 text-white border-red-400' : 'bg-red-500/5 text-red-400 border-red-500/20'}`}>
                        <Lock size={14} /> Security Level: {isLockdownActive ? 'TERMINAL' : 'HIGH'}
                    </div>
                    <Button
                        variant="primary"
                        className="shadow-neon-blue/20"
                        onClick={() => setShowGlobalActions(true)}
                    >
                        <Zap size={16} className="mr-2" /> Global Actions
                    </Button>
                </div>
            </div>

            {/* Global Actions Modal */}
            {showGlobalActions && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
                    <div className="glass-panel w-full max-w-md p-8 rounded-3xl border border-white/10 shadow-2xl relative animate-in zoom-in-95 duration-300">
                        <button
                            onClick={() => setShowGlobalActions(false)}
                            className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
                        >
                            <Lock size={20} />
                        </button>

                        <div className="text-center mb-8">
                            <div className="w-16 h-16 bg-neon-blue/20 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-neon-blue/30 shadow-neon-blue/20 shadow-lg">
                                <Zap className="text-neon-blue" size={32} />
                            </div>
                            <h2 className="text-2xl font-bold text-white">Global Actions</h2>
                            <p className="text-gray-400 text-sm mt-1">Execute system-wide administrative protocols</p>
                        </div>

                        <div className="space-y-4">
                            <button
                                onClick={handleBroadcast}
                                className="w-full flex items-center gap-4 p-4 glass-card bg-white/5 hover:bg-neon-blue/10 border border-white/5 hover:border-neon-blue/30 rounded-2xl transition-all group"
                            >
                                <div className="p-3 bg-neon-blue/10 rounded-xl group-hover:scale-110 transition-transform">
                                    <Activity size={20} className="text-neon-blue" />
                                </div>
                                <div className="text-left">
                                    <p className="text-white font-bold">Broadcast Message</p>
                                    <p className="text-gray-500 text-xs text-wrap">Send an urgent alert to all active users</p>
                                </div>
                            </button>

                            <button
                                onClick={handleClearCache}
                                className="w-full flex items-center gap-4 p-4 glass-card bg-white/5 hover:bg-neon-purple/10 border border-white/5 hover:border-neon-purple/30 rounded-2xl transition-all group"
                            >
                                <div className="p-3 bg-neon-purple/10 rounded-xl group-hover:scale-110 transition-transform">
                                    <Cpu size={20} className="text-neon-purple" />
                                </div>
                                <div className="text-left">
                                    <p className="text-white font-bold">Clear AI Model Cache</p>
                                    <p className="text-gray-500 text-xs">Force refresh of adaptive learning pathways</p>
                                </div>
                            </button>

                            <button
                                onClick={handleLockdown}
                                className={`w-full flex items-center gap-4 p-4 glass-card transition-all group rounded-2xl border ${isLockdownActive ? 'bg-emerald-500/10 border-emerald-500/30 hover:bg-emerald-500/20' : 'bg-red-500/10 border-red-500/30 hover:bg-red-500/20'}`}
                            >
                                <div className={`p-3 rounded-xl group-hover:scale-110 transition-transform ${isLockdownActive ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}>
                                    <Shield size={20} className={isLockdownActive ? 'text-emerald-500' : 'text-red-500'} />
                                </div>
                                <div className="text-left">
                                    <p className="text-white font-bold">{isLockdownActive ? 'Resume Operations' : 'Emergency Lockdown'}</p>
                                    <p className="text-gray-500 text-xs">{isLockdownActive ? 'Allow normal platform activity' : 'Restrict all API write operations'}</p>
                                </div>
                            </button>
                        </div>

                        <button
                            onClick={() => setShowGlobalActions(false)}
                            className="w-full mt-8 py-3 text-gray-400 hover:text-white font-mono text-xs uppercase tracking-widest hover:bg-white/5 rounded-xl transition-all"
                        >
                            Cancel Protocol
                        </button>
                    </div>
                </div>
            )}

            {/* 1. KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {kpis.map((stat, i) => (
                    <div key={i} className="glass-card p-5 group hover:border-white/20">
                        <div className="flex justify-between items-start mb-2">
                            <div className={`p-2 rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors ${stat.color}`}>
                                <stat.icon size={18} />
                            </div>
                            {stat.change && <span className="text-[10px] text-gray-500 font-mono">{stat.change}</span>}
                        </div>
                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">{stat.label}</h4>
                        <p className={`text-2xl font-bold text-white group-hover:scale-105 transition-transform origin-left`}>{stat.val}</p>
                    </div>
                ))}
            </div>

            {/* 2. Visual Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* User Growth Chart */}
                <div className="lg:col-span-8 glass-card p-6">
                    <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                        <TrendingUp size={18} className="text-neon-blue" /> Platform Growth
                    </h3>
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={growthData}>
                                <defs>
                                    <linearGradient id="colorStudents" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#00f3ff" stopOpacity={0.3} />
                                        <stop offset="95%" stopColor="#00f3ff" stopOpacity={0} />
                                    </linearGradient>
                                    <linearGradient id="colorCourses" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#bc13fe" stopOpacity={0.3} />
                                        <stop offset="95%" stopColor="#bc13fe" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                                <XAxis dataKey="name" stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: 'rgba(3, 0, 20, 0.9)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', boxShadow: '0 0 20px rgba(0,0,0,0.5)' }}
                                    itemStyle={{ color: '#fff' }}
                                />
                                <Area type="monotone" dataKey="students" stroke="#00f3ff" strokeWidth={3} fillOpacity={1} fill="url(#colorStudents)" />
                                <Area type="monotone" dataKey="courses" stroke="#bc13fe" strokeWidth={3} fillOpacity={1} fill="url(#colorCourses)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Skill Distribution */}
                <div className="lg:col-span-4 glass-card p-6 flex flex-col">
                    <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                        <Award size={18} className="text-neon-purple" /> Skill Mastery
                    </h3>
                    <div className="flex-1 min-h-[250px] relative">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={skillDistribution.length > 0 ? skillDistribution : [{ name: 'No Data', value: 1 }]}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                    stroke="none"
                                >
                                    {skillDistribution.map((_, index) => (
                                        <Cell key={`cell-${index}`} fill={['#00f3ff', '#bc13fe', '#ff0055', '#fbbf24'][index % 4]} />
                                    ))}
                                </Pie>
                                <Tooltip contentStyle={{ backgroundColor: 'rgba(3, 0, 20, 0.9)', border: '1px solid rgba(255,255,255,0.1)', color: '#fff' }} />
                            </PieChart>
                        </ResponsiveContainer>
                        {/* Legend */}
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
                            <span className="block text-2xl font-bold text-white">{skillDistribution.reduce((acc, curr) => acc + curr.value, 0)}</span>
                            <span className="text-[10px] text-gray-500 uppercase tracking-widest">Mastery</span>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mt-4">
                        {skillDistribution.map((s, i) => (
                            <div key={i} className="flex items-center gap-2 text-xs text-gray-400 glass-panel px-2 py-1 rounded">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: ['#00f3ff', '#bc13fe', '#ff0055', '#fbbf24'][i % 4] }}></div>
                                <span className="font-medium text-white">{s.name}</span>
                                <span className="ml-auto opacity-50">{s.value}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* 3. AI & System Status Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* AI Control Preview */}
                <div className="glass-card p-6 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-neon-purple/20 blur-3xl -mr-20 -mt-20 group-hover:bg-neon-purple/30 transition-all duration-700"></div>
                    <div className="relative z-10">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="font-bold text-white flex items-center gap-2">
                                <Cpu className="text-neon-purple" size={18} /> AI Control Center
                            </h3>
                            <div className="flex gap-2">
                                <span className="text-[10px] font-mono text-neon-green bg-neon-green/10 px-2 py-0.5 rounded border border-neon-green/20">v2.4.0 Online</span>
                            </div>
                        </div>

                        <div className="space-y-4 mb-6">
                            <div className="flex justify-between items-center text-sm border-b border-white/5 pb-2">
                                <span className="text-gray-400">Content Generator</span>
                                <span className="flex items-center gap-2 text-neon-green shadow-neon-green/20"><div className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse"></div> Active</span>
                            </div>
                            <div className="flex justify-between items-center text-sm border-b border-white/5 pb-2">
                                <span className="text-gray-400">Proctoring AI</span>
                                <span className="flex items-center gap-2 text-neon-green"><div className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse"></div> Monitoring</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-gray-400">Bias Detection</span>
                                <span className="text-neon-blue font-bold">98.5% Accuracy</span>
                            </div>
                        </div>

                        <Button variant="outline" className="w-full glass-btn hover:bg-neon-purple/20 hover:border-neon-purple/50 text-white">
                            Configure AI Parameters
                        </Button>
                    </div>
                </div>

                {/* Recent Integrity Alerts */}
                <div className="glass-card p-6">
                    <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                        <AlertCircle className="text-red-500" size={18} /> Recent Security Alerts
                    </h3>
                    <div className="space-y-3">
                        {recentAlerts.length > 0 ? recentAlerts.map(alert => (
                            <div key={alert.id} className={`flex items-start gap-3 p-3 rounded-xl border transition-all ${alert.severity === 'HIGH' ? 'bg-red-500/10 border-red-500/20 hover:bg-red-500/20 shadow-red-500/10 shadow-lg' : 'bg-orange-500/10 border-orange-500/20'}`}>
                                <AlertTriangle size={16} className={`${alert.severity === 'HIGH' ? 'text-red-500' : 'text-orange-500'} mt-0.5`} />
                                <div className="flex-1">
                                    <div className="flex justify-between items-start">
                                        <p className={`text-sm font-bold ${alert.severity === 'HIGH' ? 'text-red-200' : 'text-orange-200'}`}>{alert.severity} INTUSION</p>
                                        <span className="text-[10px] text-gray-500 font-mono">{new Date(alert.createdAt).toLocaleTimeString()}</span>
                                    </div>
                                    <p className={`text-xs ${alert.severity === 'HIGH' ? 'text-red-400/70' : 'text-orange-400/70'} mt-1`}>{alert.description}</p>
                                </div>
                            </div>
                        )) : (
                            <div className="flex flex-col items-center justify-center py-10 text-gray-500 gap-2">
                                <Shield size={32} className="text-neon-green opacity-20" />
                                <span className="text-xs uppercase tracking-widest text-white/20">No Threats Detected</span>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
