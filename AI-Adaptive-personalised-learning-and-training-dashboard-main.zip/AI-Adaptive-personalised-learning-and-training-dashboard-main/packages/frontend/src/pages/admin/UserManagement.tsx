import { useState, useEffect } from 'react';
import client from '../../api/client';
import { Search, Filter, MoreVertical, Shield, AlertTriangle, CheckCircle, XCircle, Users, Lock } from 'lucide-react';
import { Button } from '../../components/Button';
import { toast } from 'react-toastify';

interface User {
    id: string;
    name: string;
    email: string;
    role: 'STUDENT' | 'TEACHER' | 'ADMIN';
    status: 'Active' | 'Suspended';
    risk: 'Critical' | 'High' | 'Medium' | 'Low';
    progress: number;
}

export const UserManagement = () => {
    // Data State
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterRole, setFilterRole] = useState('ALL');
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [showAddModal, setShowAddModal] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [isResettingPassword, setIsResettingPassword] = useState(false);
    const [resetPasswordValue, setResetPasswordValue] = useState('');
    const [editForm, setEditForm] = useState({ name: '', email: '', role: 'STUDENT' });
    const [newUser, setNewUser] = useState({
        name: '',
        email: '',
        password: '',
        role: 'STUDENT'
    });

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const { data } = await client.get('/admin/users');
                setUsers(data);
            } catch {
                toast.error("Failed to load users");
            } finally {
                setLoading(false);
            }
        };
        fetchUsers();
    }, []);

    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(e.target.value.toLowerCase());
    };

    const toggleStatus = async (id: string) => {
        try {
            await client.patch(`/admin/users/${id}/toggle-status`);
            setUsers(users.map(u => {
                if (u.id === id) {
                    const newStatus = u.status === 'Active' ? 'Suspended' : 'Active';
                    toast.success(`User ${u.name} is now ${newStatus}`);
                    return { ...u, status: newStatus };
                }
                return u;
            }));
        } catch (error) {
            console.error("Failed to toggle user status", error);
            toast.error("Failed to update user status");
        }
    };

    const handleResetPassword = async (id: string) => {
        if (!resetPasswordValue) {
            toast.error("Please enter a new password");
            return;
        }
        setSubmitting(true);
        try {
            const { data } = await client.patch(`/admin/users/${id}/reset-password`, { password: resetPasswordValue });
            toast.success(data.message || "Password reset successfully");
            setIsResettingPassword(false);
            setResetPasswordValue('');
        } catch (error: any) {
            toast.error(error.response?.data?.message || "Failed to reset password");
        } finally {
            setSubmitting(false);
        }
    };

    const handleEditProfile = (user: User) => {
        setSelectedUser(user);
        setEditForm({ name: user.name, email: user.email, role: user.role });
        setIsEditing(true);
    };

    const handleUpdateUser = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedUser) return;
        setSubmitting(true);
        try {
            const { data } = await client.patch(`/admin/users/${selectedUser.id}`, editForm);
            setUsers(users.map(u => u.id === selectedUser.id ? { ...u, ...data } : u));
            setSelectedUser({ ...selectedUser, ...data });
            toast.success("User updated successfully");
            setIsEditing(false);
        } catch (error: any) {
            toast.error(error.response?.data?.message || "Failed to update user");
        } finally {
            setSubmitting(false);
        }
    };

    const handleAddUser = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setNewUser(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const { data } = await client.post('/admin/users', newUser);
            setUsers([data, ...users]);
            toast.success("User created successfully");
            setShowAddModal(false);
            setNewUser({ name: '', email: '', password: '', role: 'STUDENT' });
        } catch (error: any) {
            toast.error(error.response?.data?.message || "Failed to create user");
        } finally {
            setSubmitting(false);
        }
    };

    const filteredUsers = users.filter(user => {
        const matchesSearch = user.name.toLowerCase().includes(searchTerm) || user.email.toLowerCase().includes(searchTerm);
        const matchesRole = filterRole === 'ALL' || user.role === filterRole;
        return matchesSearch && matchesRole;
    });

    if (loading) return (
        <div className="flex items-center justify-center h-96">
            <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 rounded-full border-4 border-neon-blue border-t-transparent animate-spin"></div>
                <p className="text-neon-blue font-mono animate-pulse">Loading User Database...</p>
            </div>
        </div>
    );

    return (
        <div className="space-y-8 animate-fade-in-up">
            {/* Header */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">
                        User <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">Management</span>
                    </h1>
                    <p className="text-gray-400 flex items-center gap-2">
                        <Users size={14} className="text-neon-green" />
                        Total Users: {users.length} • Active: {users.filter(u => u.status === 'Active').length}
                    </p>
                </div>
                <Button
                    variant="primary"
                    className="shadow-neon-blue/20 group"
                    onClick={() => setShowAddModal(true)}
                >
                    <Users size={16} className="mr-2 group-hover:scale-110 transition-transform" /> Add New User
                </Button>
            </div>

            {/* Filters & Search */}
            <div className="flex gap-4 glass-panel p-4 rounded-xl">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-2.5 text-gray-400 group-focus-within:text-neon-blue transition-colors" size={18} />
                    <input
                        type="text"
                        placeholder="Search by name or email..."
                        className="w-full bg-black/20 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-gray-300 focus:outline-none focus:border-neon-blue/50 focus:bg-black/40 transition-all placeholder:text-gray-600"
                        onChange={handleSearch}
                    />
                </div>
                <div className="relative">
                    <Filter className="absolute left-3 top-2.5 text-gray-400" size={18} />
                    <select
                        className="bg-black/20 border border-white/10 rounded-lg pl-10 pr-8 py-2 text-sm text-gray-300 focus:outline-none focus:border-neon-blue/50 focus:bg-black/40 appearance-none cursor-pointer hover:border-white/20 transition-all"
                        onChange={(e) => setFilterRole(e.target.value)}
                        value={filterRole}
                    >
                        <option value="ALL">All Roles</option>
                        <option value="STUDENT">Students</option>
                        <option value="TEACHER">Teachers</option>
                        <option value="ADMIN">Admins</option>
                    </select>
                </div>
            </div>

            {/* Users Table */}
            <div className="glass-card overflow-hidden">
                <table className="min-w-full divide-y divide-white/10">
                    <thead className="bg-black/20">
                        <tr>
                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">User Profile</th>
                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Role</th>
                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Risk Level</th>
                            <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Progress</th>
                            <th className="px-6 py-4 text-right text-[10px] font-bold text-gray-400 uppercase tracking-widest">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {filteredUsers.length > 0 ? (
                            filteredUsers.map((user) => (
                                <tr key={user.id} className="hover:bg-white/5 transition-colors group">
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500/20 to-purple-600/20 border border-white/10 flex items-center justify-center text-sm font-bold text-white shadow-inner">
                                                {user.name.charAt(0)}
                                            </div>
                                            <div>
                                                <div className="text-sm font-bold text-gray-200 group-hover:text-neon-blue transition-colors">{user.name}</div>
                                                <div className="text-xs text-gray-500">{user.email}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase border ${user.role === 'ADMIN' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20 shadow-purple-500/10' :
                                            user.role === 'TEACHER' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20 shadow-blue-500/10' :
                                                'bg-gray-700/30 text-gray-400 border-gray-600/30'
                                            }`}>
                                            {user.role}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center gap-2">
                                            <div className={`w-1.5 h-1.5 rounded-full ${user.status === 'Active' ? 'bg-emerald-500 shadow-emerald-500/50' : 'bg-red-500 shadow-red-500/50'}`}></div>
                                            <span className={`text-xs font-medium ${user.status === 'Active' ? 'text-emerald-400' : 'text-red-400'}`}>
                                                {user.status}
                                            </span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center gap-1.5">
                                            {user.risk === 'Critical' && <AlertTriangle size={14} className="text-red-500" />}
                                            {user.risk === 'High' && <AlertTriangle size={14} className="text-orange-500" />}
                                            {user.risk === 'Medium' && <AlertTriangle size={14} className="text-yellow-500" />}
                                            {user.risk === 'Low' && <Shield size={14} className="text-emerald-500" />}
                                            <span className={`text-xs font-medium ${user.risk === 'Critical' ? 'text-red-500' :
                                                user.risk === 'High' ? 'text-orange-500' :
                                                    user.risk === 'Medium' ? 'text-yellow-500' :
                                                        'text-emerald-500'
                                                }`}>
                                                {user.risk}
                                            </span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="w-24 bg-black/40 h-1.5 rounded-full overflow-hidden border border-white/5">
                                            <div className="bg-gradient-to-r from-neon-blue to-neon-purple h-full rounded-full" style={{ width: `${user.progress}%` }}></div>
                                        </div>
                                        <span className="text-[10px] text-gray-500 mt-1 block font-mono">{user.progress}% Completed</span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right">
                                        <div className="flex justify-end gap-2">
                                            <button
                                                onClick={() => toggleStatus(user.id)}
                                                className={`p-2 rounded-lg border transition-all ${user.status === 'Active'
                                                    ? 'border-red-500/20 text-red-400 hover:bg-red-500/10 hover:border-red-500/40'
                                                    : 'border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/10 hover:border-emerald-500/40'
                                                    }`}
                                                title={user.status === 'Active' ? "Suspend User" : "Activate User"}
                                            >
                                                {user.status === 'Active' ? <Lock size={14} /> : <CheckCircle size={14} />}
                                            </button>
                                            <button
                                                onClick={() => setSelectedUser(user)}
                                                className="p-2 rounded-lg border border-white/10 text-gray-400 hover:text-white hover:bg-white/5 hover:border-white/30 transition-all"
                                                title="View Details"
                                            >
                                                <MoreVertical size={14} />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                                    <Users size={32} className="mx-auto mb-2 opacity-20" />
                                    No users found matching your filters.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* User Details Modal */}
            {selectedUser && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
                    <div className="glass-card w-full max-w-lg p-6 relative animate-slide-up border-neon-blue/20 shadow-neon-blue/10">
                        <button
                            onClick={() => {
                                setSelectedUser(null);
                                setIsEditing(false);
                                setIsResettingPassword(false);
                                setResetPasswordValue('');
                            }}
                            className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
                        >
                            <XCircle size={20} />
                        </button>

                        <div className="flex items-center gap-5 mb-8">
                            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 p-[1px] shadow-lg shadow-purple-500/20">
                                <div className="w-full h-full bg-black/40 backdrop-blur-xl rounded-2xl flex items-center justify-center text-3xl font-bold text-white">
                                    {selectedUser.name.charAt(0)}
                                </div>
                            </div>
                            <div>
                                {isEditing ? (
                                    <div className="space-y-2">
                                        <input
                                            type="text"
                                            value={editForm.name}
                                            onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                                            className="bg-black/20 border border-white/10 rounded-lg px-3 py-1 text-lg font-bold text-white focus:outline-none focus:border-neon-blue/50"
                                        />
                                        <input
                                            type="email"
                                            value={editForm.email}
                                            onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                                            className="bg-black/20 border border-white/10 rounded-lg px-3 py-1 text-sm text-gray-300 focus:outline-none focus:border-neon-blue/50 block w-full"
                                        />
                                    </div>
                                ) : (
                                    <>
                                        <h2 className="text-2xl font-bold text-white">{selectedUser.name}</h2>
                                        <p className="text-sm text-gray-400 mb-2">{selectedUser.email}</p>
                                    </>
                                )}
                                <div className="flex gap-2 mt-2">
                                    {isEditing ? (
                                        <select
                                            value={editForm.role}
                                            onChange={(e) => setEditForm({ ...editForm, role: e.target.value as any })}
                                            className="bg-black/20 border border-white/10 rounded px-2 py-0.5 text-[10px] font-bold uppercase text-gray-300 focus:outline-none"
                                        >
                                            <option value="STUDENT">Student</option>
                                            <option value="TEACHER">Teacher</option>
                                            <option value="ADMIN">Admin</option>
                                        </select>
                                    ) : (
                                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-white/5 text-gray-300 border border-white/10">
                                            {selectedUser.role}
                                        </span>
                                    )}
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${selectedUser.status === 'Active' ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/10' : 'border-red-500/30 text-red-400 bg-red-500/10'
                                        }`}>
                                        {selectedUser.status}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4 mb-8">
                            {isResettingPassword ? (
                                <div className="glass-panel p-4 rounded-xl border-neon-blue/20 bg-neon-blue/5 shadow-inner">
                                    <h3 className="text-xs font-bold text-neon-blue uppercase tracking-widest mb-3 flex items-center gap-2">
                                        <Lock size={12} /> Set New Password
                                    </h3>
                                    <input
                                        type="password"
                                        placeholder="Enter new secure password"
                                        value={resetPasswordValue}
                                        onChange={(e) => setResetPasswordValue(e.target.value)}
                                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:outline-none focus:border-neon-blue/50 transition-all placeholder:text-gray-600"
                                        autoFocus
                                    />
                                    <p className="text-[10px] text-gray-500 mt-2 italic">A strong password should be at least 8 characters.</p>
                                </div>
                            ) : (
                                <div className="glass-panel p-4 rounded-xl border-white/5 bg-white/5">
                                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Academic Performance</h3>
                                    <div className="space-y-4">
                                        <div>
                                            <div className="flex justify-between text-sm mb-2">
                                                <span className="text-gray-400">Course Progress</span>
                                                <span className="text-neon-blue font-bold">{selectedUser.progress}%</span>
                                            </div>
                                            <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden border border-white/5">
                                                <div className="bg-gradient-to-r from-neon-blue to-neon-purple h-full rounded-full shadow-lg shadow-neon-blue/20" style={{ width: `${selectedUser.progress}%` }}></div>
                                            </div>
                                        </div>
                                        <div className="flex justify-between items-center text-sm pt-2 border-t border-white/5">
                                            <span className="text-gray-400">Risk Assessment</span>
                                            <span className={`font-bold flex items-center gap-1 ${selectedUser.risk === 'Critical' ? 'text-red-500' :
                                                selectedUser.risk === 'High' ? 'text-orange-500' :
                                                    selectedUser.risk === 'Medium' ? 'text-yellow-500' : 'text-emerald-500'
                                                }`}>
                                                {selectedUser.risk === 'Critical' ? <AlertTriangle size={14} /> : <Shield size={14} />}
                                                {selectedUser.risk} Risk
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="flex gap-3">
                            {isResettingPassword ? (
                                <>
                                    <Button
                                        variant="secondary"
                                        className="flex-1 glass-btn border-white/10 hover:border-white/30 text-gray-300"
                                        onClick={() => {
                                            setIsResettingPassword(false);
                                            setResetPasswordValue('');
                                        }}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        variant="primary"
                                        className="flex-1 shadow-neon-blue/20"
                                        onClick={() => handleResetPassword(selectedUser.id)}
                                        isLoading={submitting}
                                    >
                                        Confirm Reset
                                    </Button>
                                </>
                            ) : isEditing ? (
                                <>
                                    <Button
                                        variant="secondary"
                                        className="flex-1 glass-btn border-white/10 hover:border-white/30 text-gray-300"
                                        onClick={() => setIsEditing(false)}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        variant="primary"
                                        className="flex-1 shadow-neon-blue/20"
                                        onClick={handleUpdateUser}
                                        isLoading={submitting}
                                    >
                                        Save Changes
                                    </Button>
                                </>
                            ) : (
                                <>
                                    <Button
                                        variant="secondary"
                                        className="flex-1 glass-btn border-white/10 hover:border-white/30 text-gray-300"
                                        onClick={() => setIsResettingPassword(true)}
                                    >
                                        Reset Password
                                    </Button>
                                    <Button
                                        variant="primary"
                                        className="flex-1 shadow-neon-purple/20"
                                        onClick={() => handleEditProfile(selectedUser)}
                                    >
                                        Edit Profile
                                    </Button>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            )}
            {/* Add New User Modal */}
            {showAddModal && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-fade-in">
                    <div className="glass-card w-full max-w-md p-6 relative animate-slide-up border-neon-blue/20 shadow-neon-blue/10">
                        <button
                            onClick={() => setShowAddModal(false)}
                            className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
                        >
                            <XCircle size={20} />
                        </button>

                        <div className="flex items-center gap-3 mb-6">
                            <div className="p-3 bg-neon-blue/10 rounded-xl">
                                <Users size={24} className="text-neon-blue" />
                            </div>
                            <div>
                                <h2 className="text-xl font-bold text-white">Add New User</h2>
                                <p className="text-xs text-gray-400">Create a new student, teacher, or admin</p>
                            </div>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1.5 ml-1">Full Name</label>
                                <input
                                    required
                                    type="text"
                                    name="name"
                                    value={newUser.name}
                                    onChange={handleAddUser}
                                    placeholder="Enter full name"
                                    className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-sm text-gray-200 focus:outline-none focus:border-neon-blue/50 focus:bg-black/40 transition-all"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1.5 ml-1">Email Address</label>
                                <input
                                    required
                                    type="email"
                                    name="email"
                                    value={newUser.email}
                                    onChange={handleAddUser}
                                    placeholder="email@example.com"
                                    className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-sm text-gray-200 focus:outline-none focus:border-neon-blue/50 focus:bg-black/40 transition-all"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1.5 ml-1">Password</label>
                                <input
                                    required
                                    type="password"
                                    name="password"
                                    value={newUser.password}
                                    onChange={handleAddUser}
                                    placeholder="••••••••"
                                    className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-sm text-gray-200 focus:outline-none focus:border-neon-blue/50 focus:bg-black/40 transition-all"
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1.5 ml-1">Assign Role</label>
                                <select
                                    name="role"
                                    value={newUser.role}
                                    onChange={handleAddUser}
                                    className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-3 text-sm text-gray-200 focus:outline-none focus:border-neon-blue/50 focus:bg-black/40 transition-all appearance-none cursor-pointer"
                                >
                                    <option value="STUDENT">Student</option>
                                    <option value="TEACHER">Teacher</option>
                                    <option value="ADMIN">Administrator</option>
                                </select>
                            </div>

                            <div className="pt-4 flex gap-3">
                                <Button
                                    type="button"
                                    variant="secondary"
                                    onClick={() => setShowAddModal(false)}
                                    className="flex-1 glass-btn border-white/10 hover:border-white/30 text-gray-300"
                                >
                                    Cancel
                                </Button>
                                <Button
                                    type="submit"
                                    variant="primary"
                                    isLoading={submitting}
                                    className="flex-1 shadow-neon-blue/20"
                                >
                                    Create User
                                </Button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};
