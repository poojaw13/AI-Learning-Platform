
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useState, useEffect } from 'react';
import client from '../../api/client';

import { Play, Code, FileText, Zap } from 'lucide-react';

export const AssessmentsHub = () => {
    const navigate = useNavigate();
    interface Challenge { id: number; title: string; difficulty: string; xp: number; }
    interface Exam { id: string; title: string; type: string; duration: number; status: string; candidates?: number; }
    const [dailyChallenges, setDailyChallenges] = useState<Challenge[]>([]);
    const [exams, setExams] = useState<Exam[]>([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [challengesRes, examsRes] = await Promise.all([
                    client.get('/assessments/daily'),
                    client.get('/exams')
                ]);
                setDailyChallenges(challengesRes.data.challenges || []);
                setExams(examsRes.data || []);
            } catch (error) {
                console.error("Failed to load data", error);
                setDailyChallenges([{ id: 101, title: "Offline Mode: Reverse String", difficulty: "Easy", xp: 10 }]);
            }
        };
        fetchData();
    }, []);

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-white mb-2">Assessments Hub</h1>
                        <p className="text-gray-400 text-sm">Test your skills with adaptive quizzes, coding challenges, and mock exams.</p>
                    </div>
                    <div className="bg-[#161b28] px-4 py-2 rounded-xl border border-gray-800">
                        <span className="block text-xs text-gray-500">Global Rank</span>
                        <span className="text-lg font-bold text-emerald-500">#1,402</span>
                    </div>
                </div>

                {/* Mock Exams Section */}
                <section className="mb-12">
                    <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                        <FileText className="text-emerald-500" size={24} /> Full Mock Exams
                        <span className="text-[10px] font-bold bg-purple-500/20 text-purple-400 px-2 py-0.5 rounded-full uppercase tracking-wide">New</span>
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {exams.length > 0 ? exams.map((exam) => (
                            <div key={exam.id} className="bg-[#161b28] rounded-2xl border border-gray-800 p-6 hover:border-gray-600 transition-all">
                                <div className="flex justify-between items-start mb-4">
                                    <span className="bg-gray-800 text-gray-400 text-xs font-bold px-2 py-1 rounded">{exam.duration} Mins</span>
                                    <span className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">{exam.status}</span>
                                </div>
                                <h3 className="font-bold text-lg text-white mb-2">{exam.title}</h3>
                                <p className="text-gray-400 text-xs mb-6 leading-relaxed">Type: {exam.type}. Comprehensive test based on curriculum.</p>
                                <button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors" onClick={() => toast.info(`Starting Exam: ${exam.title} (Mock)`)}>
                                    <Play size={16} /> Start Exam
                                </button>
                            </div>
                        )) : (
                            <div className="col-span-full text-center py-8 text-gray-500">
                                No exams scheduled at the moment.
                            </div>
                        )}
                    </div>
                </section>

                {/* Coding Challenges Section */}
                <section>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <Code className="text-blue-500" size={24} /> Daily Coding Challenges
                        </h2>
                        <span className="text-xs font-mono text-purple-400 bg-purple-900/20 px-3 py-1.5 rounded border border-purple-500/30 flex items-center gap-2">
                            <Zap size={12} /> AI Refreshed: {new Date().toLocaleDateString()}
                        </span>
                    </div>

                    <div className="bg-[#161b28] rounded-2xl border border-gray-800 p-6">
                        {dailyChallenges.length === 0 ? (
                            <div className="text-center py-6 text-gray-500">Loading AI Challenges...</div>
                        ) : (
                            <div className="space-y-4">
                                {dailyChallenges.map((challenge, idx) => (
                                    <div key={idx} className="flex items-center justify-between p-4 bg-[#0f111a] border border-gray-800 rounded-xl hover:border-gray-600 transition-colors">
                                        <div className="flex items-center gap-4">
                                            <div className={`w-1.5 h-12 rounded-full ${challenge.difficulty === 'Hard' ? 'bg-red-500' :
                                                challenge.difficulty === 'Medium' ? 'bg-yellow-500' : 'bg-green-500'
                                                }`}></div>
                                            <div>
                                                <h4 className="font-bold text-white">{challenge.title}</h4>
                                                <span className={`text-xs font-bold ${challenge.difficulty === 'Hard' ? 'text-red-500' :
                                                    challenge.difficulty === 'Medium' ? 'text-yellow-500' : 'text-green-500'
                                                    }`}>{challenge.difficulty}</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <div className="text-right mr-4">
                                                <span className="block text-sm font-bold text-purple-400">+{challenge.xp} XP</span>
                                                <span className="text-[10px] text-gray-500">Reward</span>
                                            </div>
                                            <button className="bg-gray-800 hover:bg-gray-700 text-white px-5 py-2 rounded-lg font-bold text-sm border border-gray-700 transition-all" onClick={() => navigate(`/challenges/${challenge.id}`)}>
                                                Solve
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </section>
            </div>
        </div>
    );
};
