
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '../../components/Button';
import { toast } from 'react-toastify';
import client from '../../api/client';

export const CodingChallengePage = () => {
    const { id } = useParams();
    const navigate = useNavigate();

    interface Challenge {
        id: string;
        title: string;
        difficulty: string;
        description: string;
        example: string;
        constraints: string[];
        starterCode: Record<string, string>;
    }

    const [challenge, setChallenge] = useState<Challenge | null>(null);
    const [loading, setLoading] = useState(true);
    const [language, setLanguage] = useState("javascript");
    const [code, setCode] = useState("");
    const [output, setOutput] = useState("");

    useEffect(() => {
        const fetchChallenge = async () => {
            try {
                // If no ID, we might need a default or redirect. For now, let's assume valid ID or fetch list.
                // If ID is missing, we could fetch a list and take the first one, or redirect.
                // Given the route /assessment/:id, ID should be there. 
                // However, previous mock had a 'default'.
                if (!id) {
                    toast.error("Challenge ID missing");
                    return;
                }

                const { data } = await client.get(`/challenges/${id}`);
                setChallenge(data);

                // Initialize code
                const starter = data.starterCode?.[language] || data.starterCode?.["javascript"] || "";
                setCode(starter);

            } catch (error) {
                console.error("Failed to load challenge", error);
                toast.error("Failed to load challenge. Loading default mock for demo if DB empty.");
                // Optional: Fallback to mock if API fails during transition? 
                // No, goal is to use real data.
            } finally {
                setLoading(false);
            }
        };
        fetchChallenge();
    }, [id]);

    // Update code when language changes
    useEffect(() => {
        if (challenge?.starterCode) {
            const starter = challenge.starterCode[language] || challenge.starterCode["javascript"] || "";
            // Only reset if code is empty or matches previous starter? 
            // Simple behavior: just set it for now or keep user changes if complex logic.
            // Let's reset to starter for simplicity as per previous mock behavior.
            setCode(starter);
        }
    }, [language, challenge]);

    const handleRun = () => {
        // Mock run on frontend for immediate feedback (or we could call a lighter API)
        setOutput("Running tests on Cloud Runner v2.1...\n\nTest Case 1: [Running...]");

        setTimeout(() => {
            setOutput(`Running tests...\n\nTest Case 1: Passed ✅\nTest Case 2: Passed ✅\nTest Case 3: Failed ❌\n   Reason: Output mismatch on edge case.\n   (Note: Full remote execution pending implementation)`);
        }, 800);
    };

    const handleSubmit = async () => {
        try {
            if (!challenge) return;

            const res = await client.post('/challenges/submit', {
                challengeId: challenge.id,
                code,
                language
            });

            const { message, output, submission } = res.data;
            setOutput(output);

            if (submission.status === "PASSED") {
                toast.success(message);
                setTimeout(() => navigate('/student/assessments'), 1500);
            } else {
                toast.error("Solution Failed Test Cases");
            }
        } catch (error) {
            console.error("Submission error", error);
            toast.error("Failed to submit solution");
        }
    };

    if (loading) return (
        <div className="flex items-center justify-center h-full min-h-[500px]">
            <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 rounded-full border-4 border-neon-blue border-t-transparent animate-spin"></div>
                <p className="text-neon-blue font-mono animate-pulse">Loading Challenge Environment...</p>
            </div>
        </div>
    );

    if (!challenge) return (
        <div className="flex items-center justify-center h-full min-h-[500px] text-gray-400">
            Challenge not found.
        </div>
    );

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)] font-sans animate-fade-in-up">
            {/* Header */}
            <div className="glass-panel p-4 flex justify-between items-center mb-4 rounded-xl border border-white/5">
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/10" onClick={() => navigate('/student/assessments')}>
                        ← Back
                    </Button>
                    <h1 className="font-bold text-lg text-white flex items-center gap-2">
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">Challenge:</span>
                        {challenge.title}
                    </h1>
                    <span className={`text-xs font-bold px-2 py-1 rounded-lg border ${challenge.difficulty === 'Hard' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                            challenge.difficulty === 'Medium' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' :
                                'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        }`}>{challenge.difficulty}</span>
                </div>
                <div className="flex items-center gap-3">
                    <select
                        value={language}
                        onChange={(e) => setLanguage(e.target.value)}
                        className="bg-black/40 border border-white/10 text-gray-200 text-sm font-medium rounded-lg px-3 py-1.5 focus:border-neon-blue/50 outline-none transition-colors"
                    >
                        <option value="javascript">JavaScript</option>
                        <option value="python">Python</option>
                        <option value="cpp">C++</option>
                    </select>
                    <Button variant="secondary" size="sm" className="glass-btn border-white/10 hover:border-white/20" onClick={() => setCode(challenge.starterCode[language] || "")}>Reset</Button>
                </div>
            </div>

            <div className="flex-1 flex gap-4 overflow-hidden">
                {/* Problem Description */}
                <div className="w-1/3 glass-panel rounded-xl overflow-hidden flex flex-col border border-white/5">
                    <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
                        <h2 className="text-xl font-bold mb-4 text-white">Description</h2>
                        <p className="mb-6 text-gray-300 leading-relaxed whitespace-pre-wrap text-sm">{challenge.description}</p>

                        <div className="bg-black/30 p-4 rounded-xl mb-6 border border-white/5">
                            <h3 className="font-bold mb-2 text-gray-200 text-xs uppercase tracking-wider">Example</h3>
                            <pre className="font-mono text-xs text-emerald-400 whitespace-pre-wrap">
                                {challenge.example}
                            </pre>
                        </div>

                        <h3 className="font-bold mb-2 text-gray-200 text-xs uppercase tracking-wider">Constraints</h3>
                        <ul className="list-disc pl-5 text-sm space-y-1 text-gray-400 marker:text-neon-blue">
                            {challenge.constraints && challenge.constraints.map((c: string, i: number) => <li key={i}>{c}</li>)}
                        </ul>
                    </div>
                </div>

                {/* Code Editor Area */}
                <div className="w-2/3 flex flex-col gap-4">
                    <div className="flex-1 relative glass-panel rounded-xl overflow-hidden border border-white/5 group">
                        <div className="absolute top-0 left-0 right-0 h-8 bg-black/20 flex items-center px-4 border-b border-white/5 z-10">
                            <span className="text-xs font-mono text-gray-500">main.{language === 'javascript' ? 'js' : language === 'python' ? 'py' : 'cpp'}</span>
                        </div>
                        {/* Simple textarea simulating an editor */}
                        <textarea
                            value={code}
                            onChange={(e) => setCode(e.target.value)}
                            className="w-full h-full bg-[#0a0a0a]/80 pt-10 text-gray-300 font-mono p-4 resize-none focus:outline-none leading-relaxed text-sm selection:bg-neon-blue/30"
                            spellCheck={false}
                        />
                    </div>

                    {/* Output / Console */}
                    <div className="h-48 glass-panel rounded-xl overflow-hidden flex flex-col border border-white/5">
                        <div className="bg-black/20 px-4 py-2 text-xs font-bold text-gray-400 flex justify-between items-center border-b border-white/5">
                            <span className="uppercase tracking-widest text-[10px]">Console Output</span>
                            <div className="flex gap-2">
                                <Button size="sm" variant="secondary" className="glass-btn text-xs py-1 h-auto border-white/10" onClick={handleRun}>Run Code</Button>
                                <Button size="sm" className="bg-neon-blue/10 text-neon-blue border border-neon-blue/50 hover:bg-neon-blue/20 text-xs py-1 h-auto" onClick={handleSubmit}>Submit Solution</Button>
                            </div>
                        </div>
                        <pre className="p-4 font-mono text-xs text-gray-400 overflow-y-auto flex-1 whitespace-pre-wrap bg-[#0a0a0a]/50">
                            {output || <span className="text-gray-600 italic">Run code to see output...</span>}
                        </pre>
                    </div>
                </div>
            </div>
        </div>
    );
};
