
import { Award, Star, TrendingUp, Crown, Zap, Lock, Unlock } from 'lucide-react';

export const TeacherRewards = () => {
    // Mock Leaderboard Data
    const leaderboard = [
        { rank: 1, name: "Kumar", score: 2850, students: 124, role: "Senior Teacher" },
        { rank: 2, name: "Sarah M.", score: 2420, students: 98, role: "Instructor" },
        { rank: 3, name: "David L.", score: 2100, students: 85, role: "Assistant Prof" },
        { rank: 4, name: "Emma W.", score: 1850, students: 110, role: "Teacher" },
        { rank: 5, name: "James B.", score: 1600, students: 60, role: "Instructor" },
    ];

    // Levels Configuration
    const currentLevel = 1;
    const stats = { currentXP: 450, nextLevelXP: 1000, completion: 45 };

    const levels = Array.from({ length: 10 }, (_, i) => {
        const level = i + 1;
        const isUnlocked = level <= currentLevel;
        const isNext = level === currentLevel + 1;

        return {
            level,
            title: `Level ${level}`,
            reward: [
                "Bronze Badge", "Silver Badge", "Gold Badge", "Platinum Badge", "Diamond Badge",
                "Master Educator", "Grandmaster", "Legend", "Sage", "Visionary"
            ][i],
            perks: [
                "Profile Badge", "Custom Avatar", "Analytics Pro", "Priority Support", "Course Spotlight",
                "Beta Features", "Workshop Access", "Mentorship Role", "Revenue Share +", "Platform Partner"
            ][i],
            xpRequired: level * 1000,
            status: isUnlocked ? 'Unlocked' : isNext ? 'In Progress' : 'Locked'
        };
    });

    return (
        <div className="bg-slate-50 font-sans text-slate-900">
            <div className="p-8">
                {/* Header */}
                <div className="mb-10">
                    <h1 className="text-3xl font-black text-slate-900 flex items-center gap-3">
                        <Award className="text-amber-500" size={32} />
                        Teacher Rewards & Leaderboard
                    </h1>
                    <p className="text-slate-500 mt-2">Level up your teaching journey, earn perks, and compete with peers.</p>
                </div>

                {/* Main Stats Card */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 mb-10 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-8 opacity-5">
                        <Crown size={180} />
                    </div>

                    <div className="relative z-10 flex justify-between items-end">
                        <div>
                            <span className="text-xs font-bold uppercase tracking-widest text-indigo-600 mb-2 block">Current Status</span>
                            <div className="flex items-end gap-4">
                                <h2 className="text-5xl font-black text-slate-900">Level {currentLevel}</h2>
                                <span className="text-lg font-bold text-slate-400 mb-2">/ 10</span>
                            </div>
                            <p className="text-slate-500 mt-2 font-medium">Bronze Badge • {stats.currentXP} XP Earned</p>
                        </div>
                        <div className="text-right">
                            <h3 className="text-xl font-bold text-slate-700 mb-2">Next Reward: Silver Badge</h3>
                            <div className="w-64 bg-slate-100 h-3 rounded-full overflow-hidden">
                                <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full" style={{ width: `${stats.completion}%` }}></div>
                            </div>
                            <p className="text-xs text-slate-400 mt-2 font-bold">{stats.nextLevelXP - stats.currentXP} XP to Level {currentLevel + 1}</p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-12 gap-8">
                    {/* Level Progression */}
                    <div className="col-span-8">
                        <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                            <Star className="text-indigo-500" size={24} /> Progression Path
                        </h2>
                        <div className="space-y-4">
                            {levels.map((lvl) => (
                                <div
                                    key={lvl.level}
                                    className={`relative p-6 rounded-2xl border transition-all ${lvl.status === 'Unlocked' ? 'bg-white border-emerald-200 shadow-sm' :
                                        lvl.status === 'In Progress' ? 'bg-gradient-to-r from-white to-indigo-50/50 border-indigo-200 shadow-md transform scale-[1.02]' :
                                            'bg-slate-50 border-slate-200 opacity-60 grayscale'
                                        }`}
                                >
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-5">
                                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-xl shadow-inner ${lvl.status === 'Unlocked' ? 'bg-emerald-100 text-emerald-600' :
                                                lvl.status === 'In Progress' ? 'bg-indigo-100 text-indigo-600' :
                                                    'bg-slate-200 text-slate-400'
                                                }`}>
                                                {lvl.level}
                                            </div>
                                            <div>
                                                <h3 className={`font-bold text-lg ${lvl.status === 'Unlocked' ? 'text-emerald-900' :
                                                    lvl.status === 'In Progress' ? 'text-indigo-900' :
                                                        'text-slate-500'
                                                    }`}>{lvl.reward}</h3>
                                                <p className="text-sm text-slate-500 flex items-center gap-2">
                                                    <Zap size={12} className={lvl.status === 'Unlocked' ? 'text-emerald-500' : 'text-slate-400'} />
                                                    Unlocks: <span className="font-bold">{lvl.perks}</span>
                                                </p>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-4">
                                            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{lvl.xpRequired} XP</span>
                                            {lvl.status === 'Unlocked' ? (
                                                <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-200">
                                                    <Unlock size={14} />
                                                </div>
                                            ) : lvl.status === 'In Progress' ? (
                                                <div className="w-8 h-8 rounded-full bg-indigo-500 text-white flex items-center justify-center animate-pulse">
                                                    <TrendingUp size={14} />
                                                </div>
                                            ) : (
                                                <div className="w-8 h-8 rounded-full bg-slate-300 text-slate-500 flex items-center justify-center">
                                                    <Lock size={14} />
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    {lvl.status === 'In Progress' && (
                                        <div className="mt-4 w-full bg-indigo-100/50 h-1.5 rounded-full overflow-hidden">
                                            <div className="bg-indigo-500 h-full rounded-full w-[45%]"></div>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Leaderboard */}
                    <div className="col-span-4">
                        <div className="bg-white rounded-2xl border border-slate-200 p-6 sticky top-8">
                            <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                                <TrendingUp className="text-emerald-500" size={24} /> Top Educators
                            </h2>

                            <div className="space-y-4">
                                {leaderboard.map((teacher, index) => (
                                    <div key={index} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                                        <div className={`w-8 h-8 flex items-center justify-center font-black text-sm rounded-lg ${index === 0 ? 'bg-amber-100 text-amber-600' :
                                            index === 1 ? 'bg-slate-200 text-slate-600' :
                                                index === 2 ? 'bg-orange-100 text-orange-600' :
                                                    'bg-slate-50 text-slate-400'
                                            }`}>
                                            #{teacher.rank}
                                        </div>
                                        <div className="flex-1">
                                            <h4 className="font-bold text-slate-800 text-sm">{teacher.name}</h4>
                                            <p className="text-[10px] text-slate-500">{teacher.role}</p>
                                        </div>
                                        <div className="text-right">
                                            <span className="block font-black text-indigo-600 text-sm">{teacher.score}</span>
                                            <span className="block text-[10px] text-slate-400">{teacher.students} students</span>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <button className="w-full mt-6 py-3 rounded-xl border border-slate-200 text-slate-500 font-bold text-xs hover:bg-slate-50 transition-colors">
                                View Full Rankings
                            </button>

                            <div className="mt-8 bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                                <h4 className="font-bold text-indigo-900 text-sm mb-2">💡 Pro Tip</h4>
                                <p className="text-xs text-indigo-700 leading-relaxed">
                                    Increase your rank by hosting live sessions and responding to student queries within 2 hours.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
