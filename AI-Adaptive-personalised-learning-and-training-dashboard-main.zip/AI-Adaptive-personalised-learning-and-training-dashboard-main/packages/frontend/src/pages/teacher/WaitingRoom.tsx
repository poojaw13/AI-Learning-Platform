import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
    Video, Mic, MicOff, VideoOff, 
    Sparkles, Shield, Cpu, RefreshCw,
    AlertCircle, ArrowRight
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const WaitingRoom = () => {
    const { sessionId } = useParams();
    const { user } = useAuth();
    const navigate = useNavigate();
    const videoRef = useRef<HTMLVideoElement>(null);

    const [isMuted, setIsMuted] = useState(false);
    const [isCamOff, setIsCamOff] = useState(false);
    const [isConnecting, setIsConnecting] = useState(false);
    const [aiFeedback, setAiFeedback] = useState("Analysing environment architecture...");

    useEffect(() => {
        if (!isCamOff && videoRef.current) {
            navigator.mediaDevices.getUserMedia({ video: true, audio: true })
                .then(stream => {
                    if (videoRef.current) videoRef.current.srcObject = stream;
                })
                .catch(err => console.error("Media error:", err));
        } else if (videoRef.current && videoRef.current.srcObject) {
            const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
            tracks.forEach(track => track.stop());
            videoRef.current.srcObject = null;
        }

        const tips = [
            "Tip: Ensure you're in a quiet environment for optimal focus tracking.",
            "AI Insight: Your background lighting is sufficient for facial sentiment analysis.",
            "System Note: Using a headset significantly improves audio clarity.",
            "Integrity Alert: Remember, session participation is tracked for certifications."
        ];
        let i = 0;
        const interval = setInterval(() => {
            setAiFeedback(tips[i % tips.length]);
            i++;
        }, 4000);
        return () => clearInterval(interval);
    }, [isCamOff]);

    const handleJoin = () => {
        setIsConnecting(true);
        // Simulate connecting to the session
        setTimeout(() => {
            navigate(`/teacher/live-lounge/${sessionId}`);
        }, 2000);
    };

    return (
        <div className="min-h-screen bg-[#0f111a] flex items-center justify-center p-6 text-white font-sans overflow-hidden">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[120px] -mr-32 -mt-32 animate-pulse"></div>
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[120px] -ml-32 -mb-32"></div>

            <div className="max-w-5xl w-full grid grid-cols-12 gap-10 relative z-10">
                {/* Video Preview Section */}
                <div className="col-span-12 lg:col-span-7">
                    <div className="relative aspect-video bg-[#161b28] rounded-[40px] border border-gray-800 shadow-2xl overflow-hidden group">
                        {isCamOff ? (
                            <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/50 backdrop-blur-xl">
                                <div className="w-24 h-24 rounded-full bg-gray-800 border-2 border-gray-700 flex items-center justify-center text-4xl font-black text-gray-600">
                                    {user?.name?.[0] || 'U'}
                                </div>
                                <p className="mt-4 text-xs font-black uppercase tracking-widest text-gray-500">Camera is deactivated</p>
                            </div>
                        ) : (
                            <video 
                                ref={videoRef} 
                                autoPlay 
                                muted 
                                className="w-full h-full object-cover mirror"
                            />
                        )}

                        {/* Controls Overlay */}
                        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4">
                            <button 
                                onClick={() => setIsMuted(!isMuted)}
                                className={`p-4 rounded-2xl transition-all ${isMuted ? 'bg-red-500 shadow-xl shadow-red-500/20' : 'bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20'}`}
                            >
                                {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
                            </button>
                            <button 
                                onClick={() => setIsCamOff(!isCamOff)}
                                className={`p-4 rounded-2xl transition-all ${isCamOff ? 'bg-red-500 shadow-xl shadow-red-500/20' : 'bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20'}`}
                            >
                                {isCamOff ? <VideoOff size={24} /> : <Video size={24} />}
                            </button>
                        </div>

                        {/* Status Badges */}
                        <div className="absolute top-6 left-6 flex gap-2">
                            <div className="px-3 py-1.5 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl flex items-center gap-2 text-[10px] font-black uppercase tracking-widest">
                                <Shield size={12} className="text-emerald-500" /> Secure Encryption
                            </div>
                        </div>
                    </div>

                    <div className="mt-6 p-6 bg-indigo-500/5 border border-indigo-500/10 rounded-3xl flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                            <Sparkles size={20} />
                        </div>
                        <div>
                            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest leading-none mb-1">AI Setup Feedback</p>
                            <p className="text-xs text-gray-400 font-medium italic">{aiFeedback}</p>
                        </div>
                    </div>
                </div>

                {/* Info & Join Section */}
                <div className="col-span-12 lg:col-span-5 flex flex-col justify-center">
                    <div className="mb-10">
                        <div className="inline-flex items-center gap-2 bg-indigo-500/10 text-indigo-400 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-4 border border-indigo-500/20">
                            <RefreshCw size={12} className="animate-spin" /> Connection Pending
                        </div>
                        <h1 className="text-5xl font-black leading-tight tracking-tighter mb-4 italic-none">
                            PRE-FLIGHT<br />CONTROL
                        </h1>
                        <p className="text-gray-400 text-lg">You're about to join the session. Verify your neural link and audio output before the teacher admits you.</p>
                    </div>

                    <div className="space-y-6 mb-10">
                        <div className="flex items-start gap-4">
                            <div className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center text-gray-400 shrink-0">
                                <Video size={16} />
                            </div>
                            <div>
                                <h4 className="text-sm font-black uppercase tracking-wider text-gray-200">Session Protocol</h4>
                                <p className="text-xs text-gray-500 mt-1">Advanced React Patterns • Module 4.2</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4">
                            <div className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center text-gray-400 shrink-0">
                                <Cpu size={16} />
                            </div>
                            <div>
                                <h4 className="text-sm font-black uppercase tracking-wider text-gray-200">Neural Sync</h4>
                                <p className="text-xs text-gray-500 mt-1">Emotion profiling and focus tracking enabled.</p>
                            </div>
                        </div>
                    </div>

                    <button 
                        onClick={handleJoin}
                        disabled={isConnecting}
                        className={`w-full py-5 rounded-[24px] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all active:scale-95 shadow-2xl ${
                            isConnecting 
                            ? 'bg-gray-800 text-gray-500 cursor-not-allowed' 
                            : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-500/20'
                        }`}
                    >
                        {isConnecting ? (
                            <>Initialising Matrix...</>
                        ) : (
                            <>Join Live Session <ArrowRight size={18} /></>
                        )}
                    </button>

                    <div className="mt-6 flex items-center gap-3 text-[10px] text-gray-600 font-bold uppercase tracking-widest">
                        <AlertCircle size={14} /> Only authorised learners can access this node.
                    </div>
                </div>
            </div>
        </div>
    );
};
