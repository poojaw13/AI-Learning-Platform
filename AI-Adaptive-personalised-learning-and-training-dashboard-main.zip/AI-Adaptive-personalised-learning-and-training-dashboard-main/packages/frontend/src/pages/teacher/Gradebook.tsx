import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

import { ArrowLeft, Save, Download, Filter, Search } from 'lucide-react';
import { Button } from '../../components/Button';
import client from '../../api/client';
import { toast } from 'react-toastify';

interface Student {
    id: string;
    name: string;
    email: string;
    assignments: number;
    midterms: number;
    final: number;
    attendance: number;
}

export const Gradebook = () => {
    const { classId } = useParams();
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');

    const [students, setStudents] = useState<Student[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStudents = async () => {
            try {
                const res = await client.get(`/teacher/classes/${classId}/students`);
                setStudents(res.data);
            } catch (err) {
                console.error("Failed to fetch gradebook data", err);
                toast.error("Failed to load gradebook");
            } finally {
                setLoading(false);
            }
        };
        if (classId) fetchStudents();
    }, [classId]);

    const handleSave = () => {
        toast.success("Gradebook saved successfully!");
    };

    const filteredStudents = students.filter(s =>
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="bg-[#0f111a] font-sans text-gray-100">
            <div className="p-8">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/teacher')}
                            className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
                        >
                            <ArrowLeft size={20} />
                        </button>
                        <div>
                            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                                Gradebook: {classId ? `Class ${classId}` : 'Class Details'}
                            </h1>
                            <p className="text-gray-400 text-sm mt-1">Manage student grades and performance.</p>
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-500/20 flex items-center gap-2">
                            <Save size={18} /> Save Changes
                        </Button>
                        <Button className="bg-gray-800 hover:bg-gray-700 text-white border border-gray-700 flex items-center gap-2">
                            <Download size={18} /> Export CSV
                        </Button>
                    </div>
                </div>

                {/* Toolbar */}
                <div className="flex justify-between items-center mb-6 bg-[#161b28] p-4 rounded-xl border border-gray-800">
                    <div className="relative w-96">
                        <Search className="absolute left-3 top-2.5 text-gray-500" size={18} />
                        <input
                            type="text"
                            placeholder="Search students..."
                            className="w-full bg-gray-900 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-sm text-gray-300 focus:outline-none focus:border-emerald-500 transition-colors"
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center gap-2">
                        <Filter size={18} className="text-gray-500" />
                        <span className="text-sm text-gray-400">Filter by: All Students</span>
                    </div>
                </div>

                {/* Grades Table */}
                {loading ? (
                    <div className="text-center py-12 text-gray-400">Loading gradebook data...</div>
                ) : (
                    <div className="bg-[#161b28] rounded-2xl border border-gray-800 overflow-hidden shadow-xl">
                        <table className="min-w-full divide-y divide-gray-800">
                            <thead className="bg-[#0f111a]">
                                <tr>
                                    <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wider">Student</th>
                                    <th className="px-6 py-4 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wider">Assignments (40%)</th>
                                    <th className="px-6 py-4 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wider">Midterms (30%)</th>
                                    <th className="px-6 py-4 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wider">Final (30%)</th>
                                    <th className="px-6 py-4 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wider">Attendance</th>
                                    <th className="px-6 py-4 text-right text-[10px] font-bold text-gray-500 uppercase tracking-wider">Total Grade</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-800">
                                {filteredStudents.map((student) => {
                                    const total = (student.assignments * 0.4) + (student.midterms * 0.3) + (student.final * 0.3);
                                    return (
                                        <tr key={student.id} className="hover:bg-gray-800/50 transition-colors">
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold border border-indigo-500/30">
                                                        {student.name.charAt(0)}
                                                    </div>
                                                    <div>
                                                        <div className="text-sm font-bold text-gray-200">{student.name}</div>
                                                        <div className="text-xs text-gray-500">{student.email}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className="text-sm font-mono text-gray-300 bg-gray-900 px-2 py-1 rounded border border-gray-700">{student.assignments}</span>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className="text-sm font-mono text-gray-300 bg-gray-900 px-2 py-1 rounded border border-gray-700">{student.midterms}</span>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className="text-sm font-mono text-gray-300 bg-gray-900 px-2 py-1 rounded border border-gray-700">{student.final}</span>
                                            </td>
                                            <td className="px-6 py-4 text-center text-sm text-gray-400">
                                                {student.attendance}%
                                            </td>
                                            <td className="px-6 py-4 text-right whitespace-nowrap">
                                                <span className={`text-sm font-bold ${total >= 90 ? 'text-emerald-400' : total >= 80 ? 'text-blue-400' : total >= 70 ? 'text-yellow-400' : 'text-red-400'}`}>
                                                    {total.toFixed(1)}%
                                                </span>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
};
