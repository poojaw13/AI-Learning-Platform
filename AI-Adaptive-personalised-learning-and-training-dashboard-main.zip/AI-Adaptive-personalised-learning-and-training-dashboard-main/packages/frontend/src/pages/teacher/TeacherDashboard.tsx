import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { Users, BookOpen, AlertCircle, TrendingUp, Plus } from 'lucide-react';
import client from '../../api/client';
import { toast } from 'react-toastify';

export const TeacherDashboard = () => {
    const navigate = useNavigate();
    interface ClassInfo { id: string; name: string; section: string; students: number; avg: number; next: string }
    interface AtRiskStudent { id: string; name: string; reason: string }
    interface Student { id: string; name: string; email: string; class: string; grade: string }
    interface ClassStudent { id: string; name: string; email: string; avatar?: string; progress?: number; grade: string }

    const [classes, setClasses] = useState<ClassInfo[]>([]);
    const [atRisk, setAtRisk] = useState<AtRiskStudent[]>([]);
    const [students, setStudents] = useState<Student[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedClass, setSelectedClass] = useState<ClassInfo | null>(null);
    const [classStudents, setClassStudents] = useState<ClassStudent[]>([]);
    const [loadingStudents, setLoadingStudents] = useState(false);

    useEffect(() => {
        const loadData = async () => {
            try {
                const [classesRes, riskRes, studentsRes] = await Promise.all([
                    client.get('/teacher/classes'),
                    client.get('/teacher/students/at-risk'),
                    client.get('/teacher/students')
                ]);
                setClasses(classesRes.data);
                setAtRisk(riskRes.data);
                setStudents(studentsRes.data);
            } catch (err) {
                console.error("Failed to fetch teacher data", err);
                toast.error("Failed to load dashboard");
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, []);

    useEffect(() => {
        if (selectedClass) {
            const fetchClassStudents = async () => {
                setLoadingStudents(true);
                try {
                    const res = await client.get(`/teacher/classes/${selectedClass.id}/students`);
                    setClassStudents(res.data);
                } catch (error) {
                    console.error("Failed to fetch class students", error);
                    toast.error("Failed to load student roster");
                } finally {
                    setLoadingStudents(false);
                }
            }
            fetchClassStudents();
        }
    }, [selectedClass]);

    const totalStudents = classes.reduce((acc, curr) => acc + (curr.students || 0), 0);
    const avgCompletion = Math.round(classes.reduce((acc, curr) => acc + (curr.avg || 0), 0) / (classes.length || 1));

    if (loading) return <div className="min-h-screen flex items-center justify-center text-neon-blue font-mono uppercase tracking-widest animate-pulse">Loading Teacher Dashboard...</div>;

    return (
        <div className="flex flex-col font-sans text-gray-100">
            {/* Header */}
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Teacher Dashboard</h1>
                    <p className="text-gray-400 text-sm">Manage classes, track student progress, and assignments.</p>
                </div>
                <div className="flex gap-4">
                    <button onClick={() => navigate('/admin/assessments')} className="glass-btn bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500/30 shadow-lg shadow-emerald-500/20 flex items-center gap-2">
                        <Plus size={16} /> Create Assignment
                    </button>
                </div>
            </div>

            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="glass-card p-6 flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                        <div className="bg-blue-500/10 p-3 rounded-xl border border-blue-500/20">
                            <Users className="text-blue-400" size={24} />
                        </div>
                        <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Total Students</span>
                    </div>
                    <div>
                        <h3 className="text-3xl font-bold text-white mb-1">{totalStudents}</h3>
                        <p className="text-xs text-gray-400">Across {classes.length} active classes</p>
                    </div>
                </div>

                <div className="glass-card p-6 flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                        <div className="bg-purple-500/10 p-3 rounded-xl border border-purple-500/20">
                            <BookOpen className="text-purple-400" size={24} />
                        </div>
                        <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Avg. Completion</span>
                    </div>
                    <div>
                        <h3 className="text-3xl font-bold text-white mb-1">{avgCompletion}%</h3>
                        <p className="text-xs text-emerald-400 flex items-center gap-1">
                            <TrendingUp size={12} /> +4% this week
                        </p>
                    </div>
                </div>

                <div className="glass-card p-6 flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                        <div className="bg-red-500/10 p-3 rounded-xl border border-red-500/20">
                            <AlertCircle className="text-red-400" size={24} />
                        </div>
                        <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">At-Risk Students</span>
                    </div>
                    <div>
                        <h3 className="text-3xl font-bold text-white mb-1">{atRisk.length}</h3>
                        <p className="text-xs text-red-400 font-bold">Needs attention</p>
                    </div>
                </div>
            </div>

            {/* Main Content Split */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Class List */}
                <div className="lg:col-span-8 space-y-6">
                    <h2 className="text-xl font-bold text-white flex items-center gap-2">Active Classes</h2>

                    <div className="space-y-4">
                        {classes.map((cls, i) => (
                            <div key={i} className="glass-card p-5 group cursor-pointer hover:border-emerald-500/30 transition-all duration-300">
                                <div className="flex justify-between items-center mb-4">
                                    <div>
                                        <div className="flex items-center gap-3 mb-1">
                                            <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors">{cls.name}</h3>
                                            <span className="text-xs bg-white/5 text-gray-400 px-2 py-0.5 rounded border border-white/10">{cls.section}</span>
                                        </div>
                                        <p className="text-xs text-gray-500">{cls.students} Students • Avg. Grade: {cls.avg}%</p>
                                    </div>
                                    <div className="h-10 w-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-emerald-500/10 group-hover:text-emerald-400 transition-colors">
                                        <TrendingUp size={18} />
                                    </div>
                                </div>
                                <div className="bg-black/20 rounded-lg p-3 flex justify-between items-center text-xs border border-white/5">
                                    <span className="text-gray-400">Upcoming: <span className="text-gray-200 font-bold">{cls.next}</span></span>
                                    <button
                                        onClick={() => setSelectedClass(cls)}
                                        className="text-emerald-400 font-bold hover:text-emerald-300 hover:underline"
                                    >
                                        View Details
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Sidebar / At Risk */}
                <div className="lg:col-span-4 space-y-6">
                    <div className="glass-panel p-6 rounded-2xl">
                        <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                            <AlertCircle size={18} className="text-red-500" /> Students at Risk
                        </h3>
                        <div className="space-y-4">
                            {atRisk.map((s, i) => (
                                <div key={i} className="flex items-start gap-3 p-3 bg-red-500/10 rounded-xl border border-red-500/20 hover:bg-red-500/20 transition-colors">
                                    <div className="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center text-red-500 text-xs font-bold mt-1 shadow-inner shadow-red-500/30">
                                        {s.name[0]}
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-bold text-gray-200">{s.name}</h4>
                                        <p className="text-xs text-red-400 mb-2">{s.reason}</p>
                                        <button className="text-[10px] bg-red-500/10 hover:bg-red-500/20 text-red-400 px-2 py-1 rounded border border-red-500/30 transition-colors">
                                            Contact Student
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="glass-panel p-6 rounded-2xl">
                        <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                            <Users size={18} className="text-blue-500" /> Student Directory
                        </h3>
                        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                            {students.length > 0 ? students.map((student, i) => (
                                <div key={i} className="flex justify-between items-center p-3 hover:bg-white/5 rounded-xl transition-all border border-transparent hover:border-white/5">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-300 font-bold text-[10px] border border-white/10">
                                            {student.name[0]}
                                        </div>
                                        <div>
                                            <h4 className="text-xs font-bold text-gray-200">{student.name}</h4>
                                            <p className="text-[9px] text-gray-500">{student.email}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-[10px] font-bold text-blue-400">{student.grade}</div>
                                        <div className="text-[9px] text-gray-500">{student.class}</div>
                                    </div>
                                </div>
                            )) : (
                                <div className="py-8 text-center text-gray-500 text-xs italic">
                                    No students enrolled yet
                                </div>
                            )}
                        </div>
                        <button
                            onClick={() => navigate('/teacher/analytics')}
                            className="w-full mt-4 py-2 text-[10px] font-black text-blue-400 uppercase tracking-widest border-t border-white/5 pt-4 hover:text-blue-300 transition-colors"
                        >
                            View Detailed List
                        </button>
                    </div>

                </div>

                {/* Class Details Modal */}
                {selectedClass && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                        <div className="glass-card w-full max-w-2xl p-6 relative animate-fade-in-up shadow-2xl bg-gray-900 border border-white/10">
                            <button
                                onClick={() => setSelectedClass(null)}
                                className="absolute top-4 right-4 text-gray-400 hover:text-white p-1 hover:bg-white/10 rounded-full transition-colors"
                            >
                                <span className="text-xl font-bold leading-none">&times;</span>
                            </button>

                            <div className="mb-6">
                                <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 mb-2 inline-block">
                                    {selectedClass.section}
                                </span>
                                <h2 className="text-2xl font-bold text-white">{selectedClass.name}</h2>
                                <p className="text-gray-400 text-sm mt-1">{selectedClass.students} Students Enrolled</p>
                            </div>

                            <div className="grid grid-cols-3 gap-4 mb-8">
                                <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                                    <div className="text-xs text-gray-500 uppercase font-bold mb-1">Avg. Grade</div>
                                    <div className="text-2xl font-bold text-white">{selectedClass.avg}%</div>
                                </div>
                                <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                                    <div className="text-xs text-gray-500 uppercase font-bold mb-1">Attendance</div>
                                    <div className="text-2xl font-bold text-white">92%</div>
                                </div>
                                <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                                    <div className="text-xs text-gray-500 uppercase font-bold mb-1">Next Quiz</div>
                                    <div className="text-sm font-bold text-white mt-1">{selectedClass.next}</div>
                                </div>
                            </div>

                            <h3 className="font-bold text-white mb-4">Student Roster Preview</h3>
                            <div className="space-y-2 mb-8 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                                {loadingStudents ? (
                                    <div className="text-center py-4 text-gray-500 text-sm animate-pulse">Loading roster...</div>
                                ) : classStudents.length > 0 ? (
                                    classStudents.map((s, i) => (
                                        <div key={i} className="flex justify-between items-center p-3 hover:bg-white/5 rounded-lg border border-transparent hover:border-white/5 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center text-xs font-bold overflow-hidden border border-white/10">
                                                    {s.avatar ? <img src={s.avatar} alt={s.name} className="w-full h-full object-cover" /> : s.name[0]}
                                                </div>
                                                <div>
                                                    <div className="text-sm font-bold text-gray-200">{s.name}</div>
                                                    <div className="text-xs text-gray-500">{s.email}</div>
                                                </div>
                                            </div>
                                            <div className="text-sm font-bold text-emerald-400">
                                                {Math.round(s.progress || 0)}%
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="text-center py-4 text-gray-500 text-sm">No students enrolled yet.</div>
                                )}
                            </div>

                            <div className="flex gap-3 pt-4 border-t border-white/10">
                                <button
                                    onClick={() => setSelectedClass(null)}
                                    className="flex-1 py-2.5 rounded-xl border border-gray-600 text-gray-400 font-bold text-sm hover:bg-white/5 hover:text-white transition-colors"
                                >
                                    Close
                                </button>
                                <button
                                    onClick={() => {
                                        toast.success(`Opening gradebook for ${selectedClass.name}`);
                                        navigate(`/teacher/gradebook/${selectedClass.id}`);
                                        setSelectedClass(null);
                                    }}
                                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 shadow-lg shadow-emerald-500/20 transition-colors"
                                >
                                    Manage Gradebook
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

