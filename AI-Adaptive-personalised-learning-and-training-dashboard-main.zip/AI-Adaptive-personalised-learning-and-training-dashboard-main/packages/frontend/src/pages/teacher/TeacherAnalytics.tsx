import { useNavigate } from 'react-router-dom';

import {
    Search,
    Filter,
    Download,
    TrendingUp,
    Users,
    BookOpen,
    User,
    ArrowLeft,
    ChevronRight,
    Sparkles,
    Calendar
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import client from '../../api/client';

interface AnalyticsStudent {
    id: string;
    name: string;
    course: string;
    attendance: string;
    status: string;
    lastSession: string;
    performance: string;
}

export const TeacherAnalytics = () => {
    const navigate = useNavigate();
    const [searchQuery, setSearchQuery] = useState('');
    const [studentAnalytics, setStudentAnalytics] = useState<AnalyticsStudent[]>([]);
    const [loading, setLoading] = useState(true);

    const [totalModules, setTotalModules] = useState(0);

    useEffect(() => {
        const fetchAnalytics = async () => {
            try {
                // Fetch students
                const resStudents = await client.get('/teacher/students');
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                const mappedData = resStudents.data.map((s: any) => ({
                    id: s.id,
                    name: s.name,
                    course: s.class,
                    attendance: s.grade,
                    status: parseInt(s.grade) > 75 ? "Active" : "Needs Review",
                    lastSession: "Real-time Data",
                    performance: parseInt(s.grade) > 90 ? "Excellent" : parseInt(s.grade) > 70 ? "Good" : "Average"
                }));
                setStudentAnalytics(mappedData);

                // Fetch classes for module count
                const resClasses = await client.get('/teacher/classes');
                if (resClasses.data) {
                    const modulesCount = resClasses.data.reduce((acc: number, curr: { modulesCount: number }) => acc + (curr.modulesCount || 0), 0);
                    setTotalModules(modulesCount);
                }

            } catch (err) {
                console.error("Analytics fetch failed", err);
                toast.error("Failed to load real-time analytics");
            } finally {
                setLoading(false);
            }
        };
        fetchAnalytics();
    }, []);

    const handleExport = () => {
        toast.info("Preparing CSV export...");

        try {
            // Define CSV headers
            const headers = ["Student Name", "Enrolled Course", "Attendance %", "Status", "Last Session", "Performance"];

            // Format data rows
            const rows = studentAnalytics.map(s => [
                s.name,
                s.course,
                s.attendance,
                s.status,
                s.lastSession,
                s.performance
            ]);

            // Combine headers and rows
            const csvContent = [
                headers.join(","),
                ...rows.map(row => row.map(cell => `"${cell}"`).join(","))
            ].join("\n");

            // Create Blob and trigger download
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");

            link.setAttribute("href", url);
            link.setAttribute("download", `student_analytics_${new Date().toISOString().split('T')[0]}.csv`);
            link.style.visibility = 'hidden';

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            setTimeout(() => {
                toast.success("Student analytics exported successfully!");
            }, 500);
        } catch (error) {
            toast.error("Failed to export CSV. Please try again.");
            console.error("CSV Export Error:", error);
        }
    };

    const handleGenerateInsight = () => {
        toast.info("AI is analyzing student patterns...");
        setTimeout(() => {
            toast.success("AI Insights generated! Check individual student profiles for details.");
        }, 2000);
    };

    if (loading) return <div className="min-h-screen bg-gray-50 flex items-center justify-center text-gray-900 font-bold uppercase tracking-widest">Loading Real-time Analytics...</div>;

    const filteredStudents = studentAnalytics.filter(s =>
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.course.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const averageAttendance = studentAnalytics.length > 0
        ? (studentAnalytics.reduce((acc, curr) => acc + parseInt(curr.attendance), 0) / studentAnalytics.length).toFixed(1)
        : "0.0";

    const underperformingCount = studentAnalytics.filter(s => s.status === "Needs Review").length;

    return (
        <div className="bg-transparent font-sans text-slate-900">
            <div className="p-8">
                {/* Header */}
                <div className="flex justify-between items-center mb-10">
                    <div className="flex items-center gap-6">
                        <button
                            onClick={() => navigate('/teacher/live-classes')}
                            className="bg-white p-3 rounded-2xl border border-gray-200 text-gray-500 hover:text-indigo-600 hover:border-indigo-100 transition-all shadow-sm group"
                        >
                            <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
                        </button>
                        <div>
                            <h1 className="text-3xl font-black text-gray-900 leading-tight">Student Intelligence Panel</h1>
                            <p className="text-gray-500 text-sm mt-1">Comprehensive cross-course attendance and engagement analytics.</p>
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <button
                            onClick={handleExport}
                            className="bg-white text-gray-900 border border-gray-200 px-6 py-3 rounded-2xl flex items-center gap-2 transition-all text-sm font-bold hover:border-gray-300 active:scale-95"
                        >
                            <Download size={18} /> Export CSV
                        </button>
                        <button
                            onClick={handleGenerateInsight}
                            className="bg-indigo-600 text-white px-6 py-3 rounded-2xl flex items-center gap-2 transition-all text-sm font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 active:scale-95"
                        >
                            <Sparkles size={18} /> Generate AI Insight
                        </button>
                    </div>
                </div>

                {/* Top Highlight Cards */}
                <div className="grid grid-cols-3 gap-8 mb-10">
                    <div className="bg-gradient-to-br from-slate-900 to-indigo-900 p-8 rounded-[40px] text-white shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-12 -mt-12 backdrop-blur-xl"></div>
                        <Users className="text-indigo-400 mb-6" size={32} />
                        <h2 className="text-4xl font-black mb-1">{averageAttendance}%</h2>
                        <p className="text-indigo-200 text-sm font-medium">Average Attendance Rate</p>
                        <div className="mt-6 flex items-center gap-2 text-xs font-bold text-emerald-400">
                            <TrendingUp size={14} /> +2.4% vs last month
                        </div>
                    </div>

                    <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-xl shadow-gray-100/50">
                        <BookOpen className="text-emerald-600 mb-6" size={32} />
                        <h2 className="text-4xl font-black text-gray-900 mb-1">{underperformingCount}</h2>
                        <p className="text-gray-500 text-sm font-medium">Underperforming Students</p>
                        <div className="mt-6 text-xs font-bold text-amber-500 flex items-center gap-1">
                            <Filter size={14} /> Attention Required
                        </div>
                    </div>

                    <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-xl shadow-gray-100/50">
                        <Calendar className="text-indigo-600 mb-6" size={32} />
                        <h2 className="text-4xl font-black text-gray-900 mb-1">{totalModules}</h2>
                        <p className="text-gray-500 text-sm font-medium">Active Course Modules</p>
                        <button
                            onClick={() => navigate('/admin/courses')}
                            className="mt-6 text-xs font-black text-indigo-600 uppercase tracking-widest hover:underline flex items-center gap-2"
                        >
                            View All <ChevronRight size={14} />
                        </button>
                    </div>
                </div>

                {/* Main Student Intelligence Table */}
                <div className="bg-white border border-gray-200 rounded-[40px] p-2 shadow-sm">
                    <div className="p-8 pb-4 flex flex-col md:flex-row justify-between items-center gap-6">
                        <h2 className="text-xl font-black text-gray-900">Student Analytics Roster</h2>
                        <div className="flex items-center gap-4 w-full md:w-auto">
                            <div className="relative flex-1 md:w-80">
                                <Search size={18} className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" />
                                <input
                                    type="text"
                                    placeholder="Search by student or course..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="w-full pl-14 pr-6 py-3.5 bg-gray-50 border border-white focus:bg-white focus:ring-8 focus:ring-indigo-500/5 focus:border-indigo-500 outline-none transition-all text-sm font-bold rounded-3xl"
                                />
                            </div>
                            <button className="bg-gray-50 p-3.5 rounded-2xl border border-gray-100 text-gray-500 hover:bg-gray-100 transition-all active:scale-95">
                                <Filter size={20} />
                            </button>
                        </div>
                    </div>

                    <div className="overflow-x-auto p-4">
                        <table className="w-full text-left border-separate border-spacing-y-2">
                            <thead>
                                <tr>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Student Information</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Enrolled Course</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Attendance %</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Engagement</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredStudents.map((s) => (
                                    <tr key={s.id} className="group hover:bg-gray-50 transition-all">
                                        <td className="px-6 py-5 bg-white rounded-l-[24px] group-hover:bg-gray-50 transition-colors">
                                            <div className="flex items-center gap-4">
                                                <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-black text-sm group-hover:scale-110 transition-transform">
                                                    {s.name.substring(0, 2).toUpperCase()}
                                                </div>
                                                <div>
                                                    <div className="text-sm font-black text-gray-900">{s.name}</div>
                                                    <div className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">Joined: 2024</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-5 bg-white group-hover:bg-gray-50 transition-colors">
                                            <div className="flex items-center gap-2">
                                                <BookOpen size={14} className="text-gray-300" />
                                                <span className="text-sm font-bold text-gray-700">{s.course}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-5 bg-white group-hover:bg-gray-50 transition-colors">
                                            <div className="flex flex-col items-center">
                                                <span className={`text-sm font-black ${parseInt(s.attendance) > 90 ? 'text-emerald-600' :
                                                    parseInt(s.attendance) > 75 ? 'text-indigo-600' : 'text-red-600'
                                                    }`}>{s.attendance}</span>
                                                <div className="w-20 h-1 bg-gray-100 rounded-full mt-1.5 overflow-hidden">
                                                    <div
                                                        className={`h-full rounded-full ${parseInt(s.attendance) > 90 ? 'bg-emerald-500' :
                                                            parseInt(s.attendance) > 75 ? 'bg-indigo-500' : 'bg-red-500'
                                                            }`}
                                                        style={{ width: s.attendance }}
                                                    ></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-5 bg-white group-hover:bg-gray-50 transition-colors">
                                            <span className={`inline-flex items-center px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest ${s.performance === 'Excellent' || s.performance === 'Distinction'
                                                ? 'bg-emerald-50 text-emerald-600'
                                                : s.performance === 'Good'
                                                    ? 'bg-indigo-50 text-indigo-600'
                                                    : 'bg-red-50 text-red-600'
                                                }`}>
                                                {s.performance}
                                            </span>
                                        </td>
                                        <td className="px-6 py-5 bg-white rounded-r-[24px] text-right group-hover:bg-gray-50 transition-colors">
                                            <button className="p-2 bg-gray-50 rounded-xl text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 transition-all">
                                                <User size={18} />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    <div className="p-8 text-center bg-gray-50/50 mt-4 rounded-b-[40px] border-t border-gray-100">
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                            End of results • Showing {filteredStudents.length} Students
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};
