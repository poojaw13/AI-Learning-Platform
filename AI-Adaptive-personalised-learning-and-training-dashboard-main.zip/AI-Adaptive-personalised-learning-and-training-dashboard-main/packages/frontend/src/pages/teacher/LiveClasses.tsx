import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { Video, Clock, Calendar, X, History, TrendingUp, Sparkles, Plus } from 'lucide-react';
import client from '../../api/client';
import { toast } from 'react-toastify';
import { useAuth } from '../../context/AuthContext';

export const LiveClasses = () => {
    const navigate = useNavigate();
    const { user } = useAuth();
    interface LiveSession { id: string; title: string; startTime: string; duration: string; class: string }
    interface ClassInfo { id: string; name: string; section: string; students: number; avg: number; next: string }

    const [classes, setClasses] = useState<ClassInfo[]>([]);
    const [liveSessions, setLiveSessions] = useState<LiveSession[]>([]);
    const [isLiveModalOpen, setIsLiveModalOpen] = useState(false);
    const [newSession, setNewSession] = useState({ title: '', classId: '', time: '', duration: '60' });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadData = async () => {
            try {
                // Always fetch live sessions
                const sessionsRes = await client.get('/teacher/live-sessions');
                setLiveSessions(sessionsRes.data);

                // Only fetch classes if teacher/admin
                if (user?.role === 'TEACHER' || user?.role === 'ADMIN') {
                    const classesRes = await client.get('/teacher/classes');
                    setClasses(classesRes.data);
                    // Auto-select first class if available
                    if (classesRes.data.length > 0) {
                        setNewSession(prev => ({ ...prev, classId: classesRes.data[0].id }));
                    }
                }
            } catch (err) {
                console.error("Failed to fetch data", err);
                // Don't show error toast for students if it's just a permission issue on classes
                if (user?.role === 'TEACHER') {
                    toast.error("Failed to load live classes");
                }
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, [user]);

    const handleCreateSession = async () => {
        if (!newSession.title || !newSession.classId || !newSession.time) {
            toast.error("Please fill in all session details");
            return;
        }

        try {
            await client.post('/teacher/live-sessions', {
                title: newSession.title,
                classId: newSession.classId,
                startTime: newSession.time,
                duration: newSession.duration
            });

            // Optimistically update or re-fetch. Let's re-fetch or just append basic data
            // The backend returns the created object, but we format it on GET.
            // For simplicity, let's just reload or append manually with formatting.
            // Formatting: startTime needs to be formatted match the GET format "Weekday, HH:MM PM"
            // Since we don't have that formatter handy here easily without duplicate logic, 
            // let's just re-fetch or assume the user accepts the refresh.
            // Actually, we can just fetch all again to be safe and consistent.

            const sessionsRes = await client.get('/teacher/live-sessions');
            setLiveSessions(sessionsRes.data);

            setIsLiveModalOpen(false);
            setNewSession({ title: '', classId: '', time: '', duration: '60' });
            toast.success("Live session scheduled successfully!");
        } catch (err) {
            console.error("Failed to create session", err);
            toast.error("Failed to schedule session");
        }
    };

    if (loading) return <div className="min-h-screen flex items-center justify-center text-neon-blue font-mono uppercase tracking-widest animate-pulse">Loading Live Classes...</div>;

    return (
        <div className="flex flex-col font-sans text-gray-100">
            <div className="relative">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-white mb-2">Live Virtual Classes</h1>
                        <p className="text-gray-400 text-sm">{user?.role === 'TEACHER' || user?.role === 'ADMIN' ? 'Schedule and manage your live interactive sessions.' : 'Join your upcoming live sessions.'}</p>
                    </div>
                    {(user?.role === 'TEACHER' || user?.role === 'ADMIN') && (
                        <button
                            onClick={() => setIsLiveModalOpen(true)}
                            className="glass-btn bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 border-indigo-500/30 shadow-lg shadow-indigo-500/20 flex items-center gap-2"
                        >
                            <Plus size={18} /> Schedule New Session
                        </button>
                    )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                    {/* Left Column: Upcoming Sessions */}
                    <div className={(user?.role === 'TEACHER' || user?.role === 'ADMIN') ? "col-span-1 md:col-span-8 space-y-6" : "col-span-1 md:col-span-12 space-y-6"}>
                        <div className="flex items-center justify-between">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                <Video className="text-indigo-400" size={20} /> Scheduled Sessions
                            </h2>
                            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">{liveSessions.length} Active</span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {liveSessions.map((ls) => (
                                <div key={ls.id} className="glass-card p-6 group relative overflow-hidden flex flex-col justify-between h-full hover:border-indigo-500/30 transition-all duration-300">
                                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full -mr-10 -mt-10 blur-2xl group-hover:bg-indigo-500/20 transition-colors"></div>
                                    <div className="relative z-10">
                                        <div className="flex justify-between items-start mb-4">
                                            <div>
                                                <span className="text-[10px] bg-indigo-500/10 text-indigo-300 px-2 py-1 rounded border border-indigo-500/20 font-bold uppercase tracking-wider mb-2 inline-block">
                                                    {ls.class}
                                                </span>
                                                <h4 className="text-lg font-bold text-white leading-tight mb-1">{ls.title}</h4>
                                            </div>
                                            <div className="bg-indigo-500/20 text-indigo-300 p-2 rounded-xl border border-indigo-500/30 group-hover:scale-110 transition-transform">
                                                <Video size={20} />
                                            </div>
                                        </div>

                                        <div className="space-y-2 mb-6">
                                            <div className="flex items-center gap-3 text-sm text-gray-400 font-medium">
                                                <Clock size={16} className="text-indigo-400" /> {ls.startTime}
                                            </div>
                                            <div className="flex items-center gap-3 text-sm text-gray-400 font-medium">
                                                <Calendar size={16} className="text-indigo-400" /> {ls.duration}
                                            </div>
                                        </div>

                                        <button
                                            onClick={() => {
                                                const path = user?.role === 'TEACHER'
                                                    ? `/teacher/live-lounge/${ls.id}`
                                                    : `/virtual-class/waiting-room/${ls.id}`;
                                                navigate(path);
                                            }}
                                            className="w-full py-2.5 bg-indigo-600/10 text-indigo-300 border border-indigo-500/30 rounded-xl text-xs font-black hover:bg-indigo-600 hover:text-white hover:border-indigo-500 transition-all uppercase tracking-widest"
                                        >
                                            {user?.role === 'TEACHER' ? 'Go to Live Session' : 'Join Session'}
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {liveSessions.length === 0 && (
                            <div className="glass-panel p-12 text-center border-dashed border-2 border-white/5">
                                <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-4 text-gray-500">
                                    <Video size={32} />
                                </div>
                                <h3 className="text-white font-bold text-lg mb-1">No sessions scheduled</h3>
                                <p className="text-gray-500 text-sm mb-6">Create your first live session to start engaging with students.</p>
                                {(user?.role === 'TEACHER' || user?.role === 'ADMIN') && (
                                    <button onClick={() => setIsLiveModalOpen(true)} className="text-indigo-400 font-bold text-sm hover:text-indigo-300">
                                        + Schedule Session
                                    </button>
                                )}
                            </div>
                        )}
                    </div>

                    {/* Right Column: Attendance & Stats - Teacher Only */}
                    {(user?.role === 'TEACHER' || user?.role === 'ADMIN') && (
                        <div className="col-span-1 md:col-span-4 space-y-6">
                            {/* Attendance History */}
                            <div className="glass-panel p-6 rounded-3xl relative">
                                <div className="flex items-center justify-between mb-6">
                                    <h3 className="font-bold text-white flex items-center gap-2">
                                        <History size={18} className="text-emerald-400" /> Recent Attendance
                                    </h3>
                                    <button
                                        onClick={() => toast.success("Attendance logs prepared for download!")}
                                        className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 transition-colors hover:bg-emerald-500/20"
                                    >
                                        Export Logs
                                    </button>
                                </div>

                                <div className="space-y-4">
                                    {[
                                        { id: '1', title: "React Basics", date: "Jan 20", attended: "42/45", class: "CS101", trend: "+2%" },
                                        { id: '2', title: "Advanced Python", date: "Jan 18", attended: "115/120", class: "PY201", trend: "-1%" }
                                    ].map((record, i) => (
                                        <div key={i} className="group cursor-pointer" onClick={() => navigate(`/teacher/attendance-report/${record.id}`)}>
                                            <div className="flex justify-between items-center mb-1">
                                                <span className="text-[10px] font-black text-gray-500 uppercase tracking-tighter">{record.class} • {record.date}</span>
                                                <span className={`text-[10px] font-bold ${record.trend.startsWith('+') ? 'text-emerald-400' : 'text-amber-400'}`}>
                                                    {record.trend}
                                                </span>
                                            </div>
                                            <div className="flex justify-between items-center p-3 bg-white/5 group-hover:bg-emerald-500/10 rounded-xl border border-white/5 group-hover:border-emerald-500/30 transition-all">
                                                <h4 className="text-xs font-bold text-gray-300 group-hover:text-white transition-colors">{record.title}</h4>
                                                <span className="text-xs font-black text-emerald-400">{record.attended}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <button
                                    onClick={() => navigate('/teacher/analytics')}
                                    className="w-full mt-6 py-3 bg-black/40 text-gray-400 border border-white/5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:text-white hover:bg-white/5 transition-colors"
                                >
                                    View Full Analytics
                                </button>
                            </div>

                            {/* Quick Stats Card */}
                            <div className="glass-card bg-gradient-to-br from-indigo-900/50 to-purple-900/50 p-6 text-white border-indigo-500/30 relative overflow-hidden">
                                <div className="absolute inset-0 bg-indigo-500/10 blur-3xl"></div>
                                <div className="relative z-10">
                                    <div className="flex items-center gap-2 mb-6 opacity-80 font-bold text-[10px] uppercase tracking-widest text-indigo-300">
                                        <TrendingUp size={14} /> Performance Sync
                                    </div>
                                    <div className="space-y-1 mb-8">
                                        <h2 className="text-3xl font-black text-white neon-text-subtle">94.2%</h2>
                                        <p className="text-xs text-gray-400">Average session attendance</p>
                                    </div>
                                    <div className="flex items-center gap-2 bg-black/20 p-3 rounded-xl backdrop-blur-md border border-white/10">
                                        <Sparkles size={16} className="text-yellow-300" />
                                        <p className="text-[10px] font-medium leading-relaxed text-gray-300">
                                            "Your interactive quizzes are boosting student presence by 12%."
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Create Live Session Modal */}
                {isLiveModalOpen && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[70] flex items-center justify-center p-4">
                        <div className="glass-card border-white/10 bg-space-950/90 rounded-[32px] w-full max-w-md p-8 relative animate-fade-in-up shadow-2xl">
                            <button
                                onClick={() => setIsLiveModalOpen(false)}
                                className="absolute top-6 right-6 text-gray-400 hover:text-white p-2 hover:bg-white/10 rounded-full transition-colors"
                            >
                                <X size={20} />
                            </button>

                            <div className="mb-8">
                                <div className="w-12 h-12 bg-indigo-500/20 border border-indigo-500/30 rounded-2xl flex items-center justify-center mb-4 text-indigo-400">
                                    <Video size={24} />
                                </div>
                                <h2 className="text-2xl font-black text-white">Schedule Session</h2>
                                <p className="text-gray-400 text-sm mt-1">Ready to start a new learning journey?</p>
                            </div>

                            <div className="space-y-5">
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Session Hero Title</label>
                                    <input
                                        type="text"
                                        value={newSession.title}
                                        onChange={(e) => setNewSession({ ...newSession, title: e.target.value })}
                                        placeholder="e.g. Masterclass: Node.js Performance"
                                        className="w-full px-5 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-white/5 focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 text-white outline-none transition-all font-medium text-sm placeholder-gray-600"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Select Active Class</label>
                                    <select
                                        value={newSession.classId}
                                        onChange={(e) => setNewSession({ ...newSession, classId: e.target.value })}
                                        className="w-full px-5 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-white/5 focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 text-white outline-none transition-all font-medium text-sm"
                                    >
                                        <option value="" className="bg-space-950 text-gray-400">Choose a class...</option>
                                        {classes.map(c => <option key={c.id} value={c.id} className="bg-space-950 text-white">{c.name}</option>)}
                                    </select>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Date & Time</label>
                                        <input
                                            type="datetime-local"
                                            value={newSession.time}
                                            onChange={(e) => setNewSession({ ...newSession, time: e.target.value })}
                                            className="w-full px-5 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-white/5 focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 text-white outline-none transition-all font-medium text-sm scheme-dark"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Duration</label>
                                        <select
                                            value={newSession.duration}
                                            onChange={(e) => setNewSession({ ...newSession, duration: e.target.value })}
                                            className="w-full px-5 py-3 bg-black/40 border border-white/10 rounded-xl focus:bg-white/5 focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 text-white outline-none transition-all font-medium text-sm"
                                        >
                                            <option value="45" className="bg-space-950">45 min</option>
                                            <option value="60" className="bg-space-950">60 min</option>
                                            <option value="90" className="bg-space-950">90 min</option>
                                            <option value="120" className="bg-space-950">120 min</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <button
                                onClick={handleCreateSession}
                                className="w-full mt-10 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-sm shadow-lg shadow-indigo-600/20 transition-all active:scale-95 uppercase tracking-widest"
                            >
                                Launch Schedule
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
