import { useNavigate } from 'react-router-dom';

import { Video, Users, MessageSquare, Star, Search, Filter } from 'lucide-react';

export const TeacherDirectory = () => {
    const navigate = useNavigate();
    // Mock Teacher Data
    const teachers = [
        { id: 1, name: "Dr. Sarah Miller", subject: "Computer Science", liveSessions: 42, interactions: 1540, rating: 4.9, avatar: "SM" },
        { id: 2, name: "Prof. Alan Turing", subject: "Algorithms", liveSessions: 38, interactions: 1250, rating: 5.0, avatar: "AT" },
        { id: 3, name: "Emily Chen", subject: "Data Science", liveSessions: 25, interactions: 980, rating: 4.8, avatar: "EC" },
        { id: 4, name: "James Wilson", subject: "Physics", liveSessions: 18, interactions: 720, rating: 4.7, avatar: "JW" },
        { id: 5, name: "Linda Martinez", subject: "Mathematics", liveSessions: 30, interactions: 1100, rating: 4.9, avatar: "LM" },
        { id: 6, name: "Robert Fox", subject: "Web Development", liveSessions: 12, interactions: 450, rating: 4.6, avatar: "RF" },
    ];

    return (
        <div className="bg-slate-50 font-sans text-slate-900">
            <div className="p-8">
                {/* Header */}
                <div className="mb-8 flex justify-between items-end">
                    <div>
                        <h1 className="text-3xl font-black text-slate-900 flex items-center gap-3">
                            <Users className="text-indigo-600" size={32} />
                            Teacher Directory
                        </h1>
                        <p className="text-slate-500 mt-2">Explore our faculty, their contributions, and student engagement metrics.</p>
                    </div>
                </div>

                {/* Filters */}
                <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-8 flex gap-4">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input
                            type="text"
                            placeholder="Search teachers by name or subject..."
                            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                        />
                    </div>
                    <button className="flex items-center gap-2 px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors">
                        <Filter size={18} /> Filter
                    </button>
                </div>

                {/* Teacher Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {teachers.map((teacher) => (
                        <div key={teacher.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 hover:shadow-md transition-shadow">
                            <div className="flex items-center gap-4 mb-6">
                                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white text-xl font-bold shadow-lg shadow-indigo-200">
                                    {teacher.avatar}
                                </div>
                                <div>
                                    <h3 className="font-bold text-lg text-slate-900">{teacher.name}</h3>
                                    <p className="text-sm text-slate-500">{teacher.subject}</p>
                                    <div className="flex items-center gap-1 text-amber-500 mt-1">
                                        <Star size={12} fill="currentColor" />
                                        <span className="text-xs font-bold">{teacher.rating}</span>
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-6">
                                <div className="text-center p-3 bg-indigo-50 rounded-xl">
                                    <div className="flex items-center justify-center text-indigo-500 mb-1">
                                        <Video size={18} />
                                    </div>
                                    <span className="block font-black text-slate-900 text-lg">{teacher.liveSessions}</span>
                                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Live Sessions</span>
                                </div>
                                <div className="text-center p-3 bg-emerald-50 rounded-xl">
                                    <div className="flex items-center justify-center text-emerald-500 mb-1">
                                        <MessageSquare size={18} />
                                    </div>
                                    <span className="block font-black text-slate-900 text-lg">{teacher.interactions}</span>
                                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Interactions</span>
                                </div>
                            </div>

                            <button
                                onClick={() => navigate(`/teachers/${teacher.id}`)}
                                className="w-full mt-6 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-bold hover:bg-slate-800 transition-colors shadow-lg shadow-slate-200"
                            >
                                View Profile
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
