import { useNavigate, useParams } from 'react-router-dom';

import {
    ArrowLeft,
    Download,
    Search,
    Filter,
    User,
    Mail,
    Calendar,
    CheckCircle2,
    XCircle,
    TrendingUp,
    BookOpen
} from 'lucide-react';
import { useState } from 'react';

export const AttendanceReport = () => {
    const { sessionId } = useParams();
    const navigate = useNavigate();
    const [searchQuery, setSearchQuery] = useState('');

    // Mock data for the report
    const sessionDetails = {
        title: sessionId === '1' ? 'Advanced React Patterns' : 'Advanced Python',
        course: sessionId === '1' ? 'CS101' : 'PY201',
        date: 'Jan 20, 2026',
        instructor: 'Dr. Kumar',
        totalStudents: 45,
        present: 42,
        absent: 3,
        attendanceRate: '93.3%'
    };

    const students = [
        { id: 1, name: "Sarah Miller", email: "sarah.m@university.edu", status: "Present", courseProgress: "88%", overallAttendance: "95%" },
        { id: 2, name: "Alan Turing", email: "a.turing@encigma.net", status: "Present", courseProgress: "92%", overallAttendance: "98%" },
        { id: 3, name: "Emily Chen", email: "e.chen@tech.com", status: "Absent", courseProgress: "75%", overallAttendance: "82%" },
        { id: 4, name: "James Wilson", email: "j.wilson@stud.org", status: "Present", courseProgress: "81%", overallAttendance: "90%" },
        { id: 5, name: "Grace Hopper", email: "grace.h@navy.mil", status: "Present", courseProgress: "95%", overallAttendance: "100%" },
        { id: 6, name: "Linus Torvalds", email: "torvalds@kernel.org", status: "Present", courseProgress: "90%", overallAttendance: "92%" },
        { id: 7, name: "Ada Lovelace", email: "ada@poetic.ai", status: "Present", courseProgress: "98%", overallAttendance: "99%" },
        { id: 8, name: "Richard Feynman", email: "physics@calc.edu", status: "Absent", courseProgress: "60%", overallAttendance: "70%" },
    ];

    const filteredStudents = students.filter(s =>
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="bg-transparent font-sans text-slate-900">
            <div className="p-8">
                {/* Back Button & Header */}
                <div className="mb-8 flex items-center justify-between">
                    <div className="flex items-center gap-6">
                        <button
                            onClick={() => navigate('/teacher/live-classes')}
                            className="bg-white p-3 rounded-2xl border border-gray-200 text-gray-500 hover:text-indigo-600 hover:border-indigo-100 transition-all shadow-sm group"
                        >
                            <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
                        </button>
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border border-indigo-100">
                                    {sessionDetails.course}
                                </span>
                                <span className="text-gray-400 text-xs font-medium opacity-50">•</span>
                                <span className="text-gray-500 text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                                    <Calendar size={12} /> {sessionDetails.date}
                                </span>
                            </div>
                            <h1 className="text-2xl font-black text-gray-900">{sessionDetails.title}</h1>
                        </div>
                    </div>
                    <button className="bg-slate-900 text-white px-6 py-3 rounded-2xl flex items-center gap-2 transition-all text-sm font-bold shadow-lg shadow-slate-200 hover:bg-slate-800 active:scale-95">
                        <Download size={18} /> Export Full Report
                    </button>
                </div>

                {/* Session Stats Grid */}
                <div className="grid grid-cols-4 gap-6 mb-8">
                    {[
                        { label: 'Total Enrolled', value: sessionDetails.totalStudents, icon: User, color: 'indigo' },
                        { label: 'Attended', value: sessionDetails.present, icon: CheckCircle2, color: 'emerald' },
                        { label: 'Missed', value: sessionDetails.absent, icon: XCircle, color: 'red' },
                        { label: 'Session Rate', value: sessionDetails.attendanceRate, icon: TrendingUp, color: 'blue' }
                    ].map((stat, i) => (
                        <div key={i} className="bg-white p-6 rounded-3xl border border-gray-200 shadow-sm relative overflow-hidden group">
                            <div className={`absolute top-0 right-0 w-20 h-20 bg-${stat.color}-50 rounded-full -mr-8 -mt-8 opacity-50 group-hover:scale-110 transition-transform`}></div>
                            <div className="relative z-10 flex justify-between items-end">
                                <div>
                                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{stat.label}</p>
                                    <h3 className="text-2xl font-black text-gray-900">{stat.value}</h3>
                                </div>
                                <div className={`p-3 bg-${stat.color}-100 text-${stat.color}-600 rounded-2xl`}>
                                    <stat.icon size={20} />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Students Table Section */}
                <div className="bg-white border border-gray-200 rounded-[32px] overflow-hidden shadow-sm">
                    {/* Table Filters */}
                    <div className="p-6 border-b border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
                        <h2 className="text-lg font-bold text-gray-900">Student Participation Details</h2>
                        <div className="flex items-center gap-3 w-full md:w-auto">
                            <div className="relative flex-1 md:w-64">
                                <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                                <input
                                    type="text"
                                    placeholder="Search student or email..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="w-full pl-11 pr-4 py-2.5 bg-gray-50 border border-gray-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                                />
                            </div>
                            <button className="bg-gray-50 p-2.5 rounded-2xl border border-gray-100 text-gray-500 hover:bg-gray-100 transition-all">
                                <Filter size={20} />
                            </button>
                        </div>
                    </div>

                    {/* Table */}
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-gray-50/50">
                                    <th className="px-8 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Student Info</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Course Progress</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Overall Attendance</th>
                                    <th className="px-8 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                                {filteredStudents.map((student) => (
                                    <tr key={student.id} className="group hover:bg-gray-50/80 transition-colors">
                                        <td className="px-8 py-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-black text-xs shadow-md border-2 border-white">
                                                    {student.name.substring(0, 2).toUpperCase()}
                                                </div>
                                                <div>
                                                    <div className="text-sm font-bold text-gray-900">{student.name}</div>
                                                    <div className="text-[10px] text-gray-400 font-medium flex items-center gap-1">
                                                        <Mail size={10} /> {student.email}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${student.status === 'Present'
                                                ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                                                : 'bg-red-50 text-red-600 border border-red-100'
                                                }`}>
                                                <span className={`w-1.5 h-1.5 rounded-full ${student.status === 'Present' ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
                                                {student.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <div className="flex items-center gap-3">
                                                <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                                    <div
                                                        className="h-full bg-indigo-500 rounded-full"
                                                        style={{ width: student.courseProgress }}
                                                    ></div>
                                                </div>
                                                <span className="text-xs font-black text-indigo-700">{student.courseProgress}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-2">
                                                <TrendingUp size={14} className="text-emerald-500" />
                                                <span className="text-sm font-bold text-gray-700">{student.overallAttendance}</span>
                                            </div>
                                        </td>
                                        <td className="px-8 py-4 text-right">
                                            <button className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">
                                                View Profile
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {filteredStudents.length === 0 && (
                        <div className="p-12 text-center text-gray-400">
                            <Search size={32} className="mx-auto mb-4 opacity-20" />
                            <p className="text-sm font-bold">No students matched your search</p>
                        </div>
                    )}

                    <div className="p-6 bg-gray-50/50 border-t border-gray-100 text-center">
                        <button className="text-[10px] font-black text-gray-400 uppercase tracking-widest hover:text-indigo-600 transition-colors">
                            Load All Students
                        </button>
                    </div>
                </div>

                {/* Additional Insight */}
                <div className="mt-8 bg-indigo-600 rounded-3xl p-8 text-white relative overflow-hidden shadow-xl shadow-indigo-100">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 backdrop-blur-3xl"></div>
                    <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
                        <div className="flex items-center gap-6">
                            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                <BookOpen size={32} />
                            </div>
                            <div>
                                <h3 className="text-xl font-black mb-1">Weekly Course Overview</h3>
                                <p className="text-indigo-100 text-sm font-medium">This class is maintaining a 12% higher engagement rate compared to previous cohort.</p>
                            </div>
                        </div>
                        <button className="bg-white text-indigo-600 px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg hover:bg-indigo-50 transition-all active:scale-95">
                            Improve Engagement
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
