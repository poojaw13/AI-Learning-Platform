import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
    Mic, MicOff, Video, VideoOff, Hand,
    Settings, PhoneOff,
    Send, Sparkles,
    Monitor
} from 'lucide-react';
import { toast } from 'react-toastify';
import { useAuth } from '../../context/AuthContext';

declare global {
    interface Window {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        JitsiMeetExternalAPI: any;
    }
}

export const LiveLounge = () => {
    const { sessionId } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();
    const jitsiContainerRef = useRef<HTMLDivElement>(null);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const jitsiApiRef = useRef<any>(null);

    const [isMuted, setIsMuted] = useState(false);
    const [isCamOff, setIsCamOff] = useState(false);
    const [isSharing, setIsSharing] = useState(false);
    const [activeTab, setActiveTab] = useState<'chat' | 'participants' | 'attendance'>('chat');
    const [message, setMessage] = useState('');
    const [engagement, setEngagement] = useState(85);

    const participants = [
        { id: 1, name: user?.name || "Member", role: user?.role || "STUDENT", avatar: user?.name?.[0] || "U", status: "Present" },
        { id: 2, name: "Sarah Miller", role: "STUDENT", avatar: "S", status: "Hand Raised" },
        { id: 3, name: "Alan Turing", role: "STUDENT", avatar: "A", status: "Present" },
        { id: 4, name: "Emily Chen", role: "STUDENT", avatar: "E", status: "Present" },
    ];

    const [attendedStudents] = useState<number[]>(participants.map(p => p.id));

    useEffect(() => {
        let isActive = true;

        // Initialize Jitsi Meet
        const loadJitsi = () => {
            if (!isActive) return;

            if (window.JitsiMeetExternalAPI && jitsiContainerRef.current) {
                // If already initialized, don't do it again
                if (jitsiApiRef.current) return;

                const domain = "meet.jit.si";
                const options = {
                    roomName: `LearnAI-Session-${sessionId}`,
                    width: '100%',
                    height: '100%',
                    parentNode: jitsiContainerRef.current,
                    userInfo: {
                        displayName: user?.name || 'Guest'
                    },
                    configOverwrite: {
                        startWithAudioMuted: false,
                        startWithVideoMuted: false,
                        disableModeratorIndicator: true,
                        startScreenSharing: false,
                        enableEmailInStats: false,
                        prejoinPageEnabled: true
                    },
                    interfaceConfigOverwrite: {
                        DISABLE_JOIN_LEAVE_NOTIFICATIONS: true,
                        TOOLBAR_BUTTONS: [] // Hide native toolbar, use our premium UI
                    }
                };
                const api = new window.JitsiMeetExternalAPI(domain, options);

                api.addEventListeners({
                    videoConferenceJoined: () => toast.success("Successfully connected to Neural Stream"),
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    participantJoined: (data: any) => toast.info(`${data.displayName} has synced`),
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    audioMuteStatusChanged: (data: any) => setIsMuted(data.muted),
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    videoMuteStatusChanged: (data: any) => setIsCamOff(data.muted),
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    screenSharingStatusChanged: (data: any) => setIsSharing(data.on)
                });

                jitsiApiRef.current = api;
            } else {
                // Retry if script not loaded yet
                setTimeout(loadJitsi, 500);
            }
        };

        loadJitsi();

        const engagementInterval = setInterval(() => {
            setEngagement(prev => Math.min(100, Math.max(70, prev + (Math.random() * 10 - 5))));
        }, 5000);

        return () => {
            isActive = false;
            if (jitsiApiRef.current) {
                jitsiApiRef.current.dispose();
                jitsiApiRef.current = null;
            }
            clearInterval(engagementInterval);
        };
    }, [sessionId, user]);

    const toggleMute = () => {
        if (jitsiApiRef.current) jitsiApiRef.current.executeCommand('toggleAudio');
    };

    const toggleCamera = () => {
        if (jitsiApiRef.current) jitsiApiRef.current.executeCommand('toggleVideo');
    };

    const toggleScreenShare = () => {
        if (jitsiApiRef.current) jitsiApiRef.current.executeCommand('toggleShareScreen');
    };

    const handleEndSession = () => {
        toast.info(`Session closed. Cognitive logs saved.`);
        if (jitsiApiRef.current) {
            try {
                jitsiApiRef.current.dispose();
            } catch (e) {
                console.error("Error disposing Jitsi:", e);
            }
            jitsiApiRef.current = null;
        }
        // Use a slight delay to ensure cleanup and provide feedback
        setTimeout(() => {
            const path = user?.role === 'TEACHER' ? '/teacher' : '/dashboard';
            navigate(path);
        }, 1000);
    };

    const chatMessages = [
        { sender: "Sarah Miller", text: "Dr. Kumar, can you explain the last step again?", time: "10:05 AM" },
        { sender: "AI Assistant", text: "Analyzing query... Insight: Sarah is referring to the Higher-Order Component logic.", time: "10:06 AM" },
    ];

    return (
        <div className="h-screen bg-[#0f111a] flex flex-col font-sans text-slate-100 overflow-hidden">
            {/* Header / Nav */}
            <header className="h-16 px-6 border-b border-gray-800 flex items-center justify-between bg-[#161b28]/50 backdrop-blur-md">
                <div className="flex items-center gap-4">
                    <div className="bg-indigo-600 p-2 rounded-xl shadow-lg shadow-indigo-500/20">
                        <Video size={20} className="text-white" />
                    </div>
                    <div>
                        <h1 className="text-sm font-black italic-none uppercase tracking-tighter">Advanced React Patterns - CS101</h1>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Neural Link Active • 00:45:12
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <div className="hidden md:flex items-center gap-2 bg-[#0f111a] border border-gray-800 px-3 py-1.5 rounded-xl">
                        <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                        <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Integrity: High</span>
                    </div>
                    <button onClick={handleEndSession} className="bg-red-500/10 hover:bg-red-500/20 text-red-500 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 border border-red-500/20 transition-all active:scale-95">
                        <PhoneOff size={16} /> Disconnect
                    </button>
                </div>
            </header>

            {/* Main Content Area */}
            <main className="flex-1 flex overflow-hidden">
                <div className="flex-1 p-6 flex flex-col gap-4 relative">
                    {/* Jitsi Meeting Container */}
                    <div className="flex-1 bg-black rounded-[40px] overflow-hidden relative border border-gray-800 shadow-2xl">
                        <div ref={jitsiContainerRef} className="w-full h-full" />

                        {/* AI Insights Overlay */}
                        <div className="absolute top-6 right-6 w-64 bg-[#0f111a]/80 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-3xl pointer-events-none animate-fade-in">
                            <div className="flex items-center gap-2 text-indigo-400 mb-4 font-black text-[10px] uppercase tracking-widest">
                                <Sparkles size={14} /> Neural Analysis
                            </div>
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between items-center mb-1.5">
                                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Engagement Rate</span>
                                        <span className="text-[10px] font-black text-emerald-400">{Math.round(engagement)}%</span>
                                    </div>
                                    <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
                                        <div className="h-full bg-emerald-500 transition-all duration-1000" style={{ width: `${engagement}%` }}></div>
                                    </div>
                                </div>
                                <p className="text-[10px] text-slate-300 leading-relaxed font-medium italic opacity-80">
                                    "Platform AI detects peak cognitive synchronization. Focus remains locked on code demonstrations."
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Bottom Toolbar */}
                    <div className="absolute bottom-10 left-1/2 -translate-x-1/2 bg-[#161b28]/90 backdrop-blur-2xl px-8 py-4 rounded-[32px] border border-white/10 flex items-center gap-6 shadow-3xl">
                        <button onClick={toggleMute} className={`p-4 rounded-2xl transition-all active:scale-90 ${isMuted ? 'bg-red-500 text-white shadow-xl shadow-red-500/30' : 'bg-gray-800 text-slate-300 hover:bg-gray-700'}`}>
                            {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
                        </button>
                        <button onClick={toggleCamera} className={`p-4 rounded-2xl transition-all active:scale-90 ${isCamOff ? 'bg-red-500 text-white shadow-xl shadow-red-500/30' : 'bg-gray-800 text-slate-300 hover:bg-gray-700'}`}>
                            {isCamOff ? <VideoOff size={24} /> : <Video size={24} />}
                        </button>
                        <button onClick={toggleScreenShare} className={`p-4 rounded-2xl transition-all active:scale-90 ${isSharing ? 'bg-emerald-500 text-white shadow-xl shadow-emerald-500/30' : 'bg-gray-800 text-slate-300 hover:bg-gray-700'}`}>
                            <Monitor size={24} />
                        </button>
                        <button className="p-4 bg-gray-800 text-slate-300 hover:bg-gray-700 rounded-2xl transition-all active:scale-90">
                            <Hand size={24} />
                        </button>
                        <div className="h-10 w-[1px] bg-gray-700 mx-1"></div>
                        <button className="p-4 bg-gray-800 text-slate-300 hover:bg-gray-700 rounded-2xl transition-all active:scale-90">
                            <Settings size={24} />
                        </button>
                    </div>
                </div>

                {/* Sidebar */}
                <div className="w-80 border-l border-gray-800 bg-[#161b28] shadow-2xl flex flex-col">
                    <div className="flex border-b border-gray-800">
                        {['chat', 'participants', 'attendance'].map((tab) => (
                            <button
                                key={tab}
                                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                onClick={() => setActiveTab(tab as any)}
                                className={`flex-1 py-5 text-[10px] font-black uppercase tracking-widest transition-all relative ${activeTab === tab ? 'text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
                            >
                                {tab}
                                {activeTab === tab && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500"></div>}
                            </button>
                        ))}
                    </div>

                    <div className="flex-1 overflow-y-auto p-5 custom-scrollbar">
                        {activeTab === 'chat' ? (
                            <div className="space-y-6">
                                {chatMessages.map((m, i) => (
                                    <div key={i} className="animate-fade-in">
                                        <div className="flex justify-between items-center mb-1.5">
                                            <span className={`text-[9px] font-black uppercase tracking-tighter ${m.sender === 'AI Assistant' ? 'text-emerald-400' : 'text-indigo-400'}`}>{m.sender}</span>
                                            <span className="text-[8px] text-slate-600 font-bold">{m.time}</span>
                                        </div>
                                        <p className="text-xs text-slate-300 leading-relaxed bg-[#0f111a]/50 p-3 rounded-2xl border border-white/5">
                                            {m.text}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        ) : activeTab === 'participants' ? (
                            <div className="space-y-4">
                                {participants.map((p) => (
                                    <div key={p.id} className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/5 transition-colors group">
                                        <div className="flex items-center gap-3">
                                            <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-black ${p.role === 'TEACHER' ? 'bg-indigo-600 shadow-lg shadow-indigo-600/20' : 'bg-gray-800 text-slate-400'}`}>
                                                {p.avatar}
                                            </div>
                                            <div>
                                                <h4 className="text-xs font-black text-gray-200">{p.name}</h4>
                                                <span className={`text-[8px] font-black uppercase tracking-widest ${p.status === 'Hand Raised' ? 'text-amber-500' : 'text-slate-500'}`}>
                                                    {p.status}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="space-y-4">
                                <div className="p-4 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 mb-6 font-black uppercase tracking-widest">
                                    <p className="text-[9px] text-indigo-400 mb-1">Session Attendance</p>
                                    <h4 className="text-2xl text-white">{attendedStudents.length} / {participants.length}</h4>
                                </div>
                                {participants.map((p) => (
                                    <div key={p.id} className="flex items-center justify-between p-3 rounded-2xl border border-white/5 bg-[#0f111a]/30">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center text-[10px] font-black text-gray-500">
                                                {p.avatar}
                                            </div>
                                            <h4 className="text-[11px] font-bold text-gray-400">{p.name}</h4>
                                        </div>
                                        <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/40"></div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    {activeTab === 'chat' && (
                        <div className="p-5 bg-[#161b28] border-t border-gray-800">
                            <div className="relative">
                                <input
                                    type="text"
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                    placeholder="Neural input..."
                                    className="w-full bg-[#0f111a] border border-gray-800 rounded-2xl pl-5 pr-12 py-3.5 text-xs focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none text-slate-100 placeholder:text-gray-600 font-medium"
                                />
                                <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 text-indigo-500 hover:text-indigo-400 transition-colors">
                                    <Send size={18} />
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};
