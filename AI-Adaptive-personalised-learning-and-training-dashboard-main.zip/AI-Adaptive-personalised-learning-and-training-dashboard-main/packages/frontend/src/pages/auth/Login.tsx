import { useState } from 'react';
import { AxiosError } from 'axios';
import { useAuth } from '../../context/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import client from '../../api/client';
import { Button } from '../../components/Button';
import { toast } from 'react-toastify';
import { Mail, Lock, Command, ArrowRight, Brain, Target, Shield } from 'lucide-react';

export const Login = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });
    const [isLoading, setIsLoading] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        const { email, password } = formData;


        try {
            const { data } = await client.post('/auth/login', { email, password });
            login(data.token, data.user);

            // Redirect based on role
            if (data.user.role === 'ADMIN') {
                navigate('/admin');
            } else if (data.user.role === 'TEACHER') {
                navigate('/teacher');
            } else {
                navigate('/dashboard');
            }
        } catch (err) {
            const error = err as AxiosError<{ message: string }>;
            toast.error(error.response?.data?.message || 'Login failed');
        } finally {
            setIsLoading(false);
        }
    };



    return (
        <div className="min-h-screen bg-transparent flex font-sans text-slate-900">
            {/* Left Side: Form */}
            <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-20 xl:px-24 relative z-10">
                <div className="mx-auto w-full max-w-sm lg:w-96">
                    <div className="mb-10">
                        <Link to="/" className="flex items-center gap-2 mb-8 text-blue-600 hover:opacity-80 transition-opacity w-fit">
                            <Command size={32} />
                            <span className="text-xl font-bold text-gray-900">AdaptiveLearn</span>
                        </Link>
                        <h2 className="text-4xl font-extrabold text-gray-900 tracking-tight">Welcome back</h2>
                        <p className="mt-3 text-sm text-gray-600">
                            Please sign in to your account.
                        </p>
                    </div>

                    <div className="mt-8">

                        <div className="mt-8">
                            <form className="space-y-6" onSubmit={handleSubmit}>
                                <div>
                                    <label htmlFor="email" className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Email address</label>
                                    <div className="relative rounded-xl shadow-sm">
                                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                            <Mail className="h-5 w-5 text-gray-400" />
                                        </div>
                                        <input
                                            id="email"
                                            name="email"
                                            type="email"
                                            autoComplete="email"
                                            required
                                            className="block w-full pl-10 bg-white border-gray-300 rounded-xl text-gray-900 focus:ring-blue-500 focus:border-blue-500 text-sm py-3 transition-colors placeholder-gray-400 border shadow-sm"
                                            placeholder="you@example.com"
                                            value={formData.email}
                                            onChange={handleChange}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label htmlFor="password" className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Password</label>
                                    <div className="relative rounded-xl shadow-sm">
                                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                            <Lock className="h-5 w-5 text-gray-400" />
                                        </div>
                                        <input
                                            id="password"
                                            name="password"
                                            type="password"
                                            autoComplete="current-password"
                                            required
                                            className="block w-full pl-10 bg-white border-gray-300 rounded-xl text-gray-900 focus:ring-blue-500 focus:border-blue-500 text-sm py-3 transition-colors placeholder-gray-400 border shadow-sm"
                                            placeholder="••••••••"
                                            value={formData.password}
                                            onChange={handleChange}
                                        />
                                    </div>
                                    <div className="flex items-center justify-end mt-2">
                                        <div className="text-sm">
                                            <a href="#" className="font-medium text-blue-600 hover:text-blue-500">
                                                Forgot your password?
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-500/20 transition-all hover:scale-[1.02]" isLoading={isLoading}>
                                        Sign In <ArrowRight className="ml-2 w-4 h-4" />
                                    </Button>
                                </div>
                            </form>

                            <div className="mt-6 text-center">
                                <p className="text-sm text-gray-600">
                                    Don't have an account?{' '}
                                    <Link to="/register" className="font-bold text-blue-600 hover:text-blue-500 transition-colors">
                                        Create one now
                                    </Link>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Side: Feature Showcase (Hidden on Mobile) */}
            <div className="hidden lg:flex relative w-0 flex-1 bg-white items-center justify-center p-12 overflow-hidden border-l border-gray-100">
                {/* Background Blobs */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-blue-100/50 rounded-full blur-3xl -mr-20 -mt-20"></div>
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-100/50 rounded-full blur-3xl -ml-20 -mb-20"></div>

                <div className="relative max-w-lg">
                    <div className="mb-10 animate-fade-in-up">
                        <img src="https://cdni.iconscout.com/illustration/premium/thumb/online-learning-4112613-3408800.png" alt="Learning" className="w-full drop-shadow-xl opacity-90 mx-auto transform hover:scale-105 transition-transform duration-500" />
                    </div>

                    <h2 className="text-3xl font-bold text-gray-900 mb-6">Continue your journey</h2>

                    <div className="space-y-4">
                        <div className="flex items-start gap-4">
                            <div className="p-2 bg-blue-100 rounded-lg text-blue-600 mt-1">
                                <Brain size={20} />
                            </div>
                            <div>
                                <h4 className="font-bold text-gray-900">Adaptive AI</h4>
                                <p className="text-sm text-gray-600">Pick up exactly where you left off with personalized recommendations.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4">
                            <div className="p-2 bg-purple-100 rounded-lg text-purple-600 mt-1">
                                <Target size={20} />
                            </div>
                            <div>
                                <h4 className="font-bold text-gray-900">Track Progress</h4>
                                <p className="text-sm text-gray-600">Visualize your improvements and celebrate your milestones.</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-4">
                            <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600 mt-1">
                                <Shield size={20} />
                            </div>
                            <div>
                                <h4 className="font-bold text-gray-900">Secure & Private</h4>
                                <p className="text-sm text-gray-600">Your data and learning history are always protected.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Google Account Chooser Modal (Same as Register) */}

        </div>
    );
};
