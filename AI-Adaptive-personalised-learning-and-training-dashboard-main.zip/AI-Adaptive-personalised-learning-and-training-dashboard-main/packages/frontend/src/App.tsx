import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Login } from './pages/auth/Login';
import { Register } from './pages/auth/Register';
import { Dashboard } from './pages/dashboard/Dashboard';
import { AssessmentsHub } from './pages/assessment/AssessmentsHub';
import { CodingChallengePage } from './pages/assessment/CodingChallengePage';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { AboutPage, CareerPathsPage, FAQPage, PricingPage, HowAIWorksPage, LegalPage, ContactPage, CertificationsPage } from './pages/public/PublicPages';

import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { CourseDetails } from './pages/course/CourseDetails';
import { UserManagement } from './pages/admin/UserManagement';
import { CourseControl } from './pages/admin/CourseControl';
import { AIControlCenter } from './pages/admin/AIControlCenter';
import { ModelConfig } from './pages/admin/ModelConfig';
import { ModelTesting } from './pages/admin/ModelTesting';
import { DecisionLogs } from './pages/admin/DecisionLogs';
import { AssessmentManager } from './pages/admin/AssessmentManager';
import { SecurityDashboard } from './pages/admin/SecurityDashboard';
import { SecurityLogs } from './pages/admin/SecurityLogs';
import { RecoveryManager } from './pages/admin/RecoveryManager';
import { SystemSettings } from './pages/admin/SystemSettings';
import { AIChatTutor } from './components/chat/AIChatTutor';
import { EmotionMonitor } from './components/chat/EmotionMonitor';
import { MainLayout } from './components/layout/MainLayout';

import { LandingPage } from './pages/LandingPage';
import { Leaderboard } from './pages/Leaderboard';
import { AIInsights } from './pages/dashboard/AIInsights';
import { Performance } from './pages/dashboard/Performance';
import { Modules } from './pages/dashboard/Modules';
import { Achievements } from './pages/dashboard/Achievements';
import { Community } from './pages/dashboard/Community';
import { TeacherDashboard } from './pages/teacher/TeacherDashboard';
import { TeacherRewards } from './pages/teacher/TeacherRewards';
import { TeacherDirectory } from './pages/teacher/TeacherDirectory';
import { TeacherProfile } from './pages/teacher/TeacherProfile';
import { LiveClasses } from './pages/teacher/LiveClasses';
import { WaitingRoom } from './pages/teacher/WaitingRoom';
import { AttendanceReport } from './pages/teacher/AttendanceReport';
import { TeacherAnalytics } from './pages/teacher/TeacherAnalytics';
import { LiveLounge } from './pages/teacher/LiveLounge';
import { Gradebook } from './pages/teacher/Gradebook';
import { IntelligenceConsole } from './pages/admin/IntelligenceConsole';
import { AdvancedStudentIQ } from './pages/student/AdvancedStudentIQ';

const ProtectedRoute = () => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) return <div>Loading...</div>; // Or a nice spinner

  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
};

const AppContent = () => {
  const { user } = useAuth();
  return (
    <>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/career-paths" element={<CareerPathsPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/faq" element={<FAQPage />} />
        <Route path="/how-ai-works" element={<HowAIWorksPage />} />
        <Route path="/legal" element={<LegalPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/certifications" element={<CertificationsPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/demo" element={<Dashboard isDemo={true} />} />

        <Route element={<ProtectedRoute />}>
          <Route element={<MainLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/users" element={<UserManagement />} />
            <Route path="/admin/courses" element={<CourseControl />} />
            <Route path="/admin/assessments" element={<AssessmentManager />} />
            <Route path="/admin/ai" element={<AIControlCenter />} />
            <Route path="/admin/ai/config/:modelId" element={<ModelConfig />} />
            <Route path="/admin/ai/test/:modelId" element={<ModelTesting />} />
            <Route path="/admin/ai/decisions" element={<DecisionLogs />} />
            <Route path="/admin/analytics" element={<AdminDashboard />} />
            <Route path="/admin/security" element={<SecurityDashboard />} />
            <Route path="/admin/security/logs" element={<SecurityLogs />} />
            <Route path="/admin/settings" element={<SystemSettings />} />
            <Route path="/admin/intelligence" element={<IntelligenceConsole />} />
            <Route path="/admin/intelligence/recovery" element={<RecoveryManager />} />
            <Route path="/student/intelligence" element={<AdvancedStudentIQ />} />
            <Route path="/assessments" element={<AssessmentsHub />} />
            <Route path="/challenges/:id" element={<CodingChallengePage />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/courses/:id" element={<CourseDetails />} />
            <Route path="/ai-insights" element={<AIInsights />} />
            <Route path="/performance" element={<Performance />} />
            <Route path="/modules" element={<Modules />} />
            <Route path="/achievements" element={<Achievements />} />
            <Route path="/community" element={<Community />} />
            <Route path="/student/live-classes" element={<LiveClasses />} />
            <Route path="/student/assessments" element={<AssessmentsHub />} />
            <Route path="/teacher" element={<TeacherDashboard />} />
            <Route path="/teacher/rewards" element={<TeacherRewards />} />
            <Route path="/teachers" element={<TeacherDirectory />} />
            <Route path="/teachers/:id" element={<TeacherProfile />} />
            <Route path="/teacher/live-classes" element={<LiveClasses />} />
            <Route path="/virtual-class/waiting-room/:sessionId" element={<WaitingRoom />} />
            <Route path="/teacher/attendance-report/:sessionId" element={<AttendanceReport />} />
            <Route path="/teacher/analytics" element={<TeacherAnalytics />} />
            <Route path="/teacher/live-lounge/:sessionId" element={<LiveLounge />} />
            <Route path="/teacher/gradebook/:classId" element={<Gradebook />} />
          </Route>
        </Route>
      </Routes>
      <AIChatTutor />
      {user?.role === 'STUDENT' && <EmotionMonitor />}
      <ToastContainer position="top-right" autoClose={3000} />
    </>
  );
};

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
