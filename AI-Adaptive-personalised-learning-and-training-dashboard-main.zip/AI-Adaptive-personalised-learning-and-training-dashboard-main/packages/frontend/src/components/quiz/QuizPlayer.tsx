import { useState, useEffect } from 'react';
import { Button } from '../Button';
import client from '../../api/client';
import { toast } from 'react-toastify';

interface Question {
    id: string;
    question: string;
    options: string[];
    correctAnswer: string;
    topic?: string;
}

interface QuizPlayerProps {
    lessonId: string;
    questions: Question[];
    onComplete: () => void;
}

interface QuizResult {
    result: { score: number };
    analysis?: { recommendedDifficulty: string; suggestedTopics: string[] };
}

export const QuizPlayer = ({ lessonId, questions, onComplete }: QuizPlayerProps) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [answers, setAnswers] = useState<Record<string, string>>({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [result, setResult] = useState<QuizResult | null>(null);

    // Proctoring Logic
    useEffect(() => {
        const handleVisibilityChange = () => {
            if (document.hidden && !isSubmitted) {
                toast.warning("⚠️ Proctoring Alert: Tab switching detected! This incident has been logged.");
                // In a real app, we would send this to the backend: 
                // client.post('/proctoring/log', { violation: 'tab_switch' });
            }
        };

        document.addEventListener("visibilitychange", handleVisibilityChange);
        return () => {
            document.removeEventListener("visibilitychange", handleVisibilityChange);
        };
    }, [isSubmitted]);

    const handleSelect = (option: string) => {
        setAnswers({ ...answers, [questions[currentIndex].id]: option });
    };

    const handleNext = () => {
        if (currentIndex < questions.length - 1) {
            setCurrentIndex(currentIndex + 1);
        } else {
            submitQuiz();
        }
    };

    const submitQuiz = async () => {
        setIsSubmitted(true);
        let score = 0;
        const wrongAnswers: string[] = [];
        const topics: Set<string> = new Set();

        questions.forEach(q => {
            if (answers[q.id] === q.correctAnswer) {
                score++;
            } else {
                if (q.topic) wrongAnswers.push(q.topic);
            }
            if (q.topic) topics.add(q.topic);
        });

        const finalScore = Math.round((score / questions.length) * 100);

        try {
            const { data } = await client.post('/courses/quiz', {
                lessonId,
                score: finalScore,
                totalQuestions: questions.length,
                wrongAnswers,
                topic: Array.from(topics).join(', ') // Simplified topic tracking
            });
            setResult(data);
            toast.success(`Quiz Completed! +${finalScore * 10} XP`);
            setTimeout(onComplete, 2000); // Redirect after delay
        } catch {
            toast.error("Failed to submit results");
        }
    };

    if (isSubmitted) {
        return (
            <div className="p-6 bg-white rounded shadow text-center">
                <h3 className="text-2xl font-bold mb-4">Quiz Completed!</h3>
                {result && (
                    <div>
                        <p className="text-xl mb-2">Score: {result.result.score}%</p>
                        {result.analysis && (
                            <div className="bg-blue-50 p-4 rounded text-left">
                                <p className="font-bold">AI Feedback:</p>
                                <p>Recommended Difficulty: {result.analysis.recommendedDifficulty}</p>
                                {result.analysis.suggestedTopics.length > 0 && (
                                    <p>Suggestions: {result.analysis.suggestedTopics.join(', ')}</p>
                                )}
                            </div>
                        )}
                    </div>
                )}
            </div>
        )
    }

    const currentQuestion = questions[currentIndex];

    return (
        <div className="max-w-2xl mx-auto p-6 bg-white rounded shadow">
            <div className="mb-4 flex justify-between">
                <span className="text-gray-500">Question {currentIndex + 1}/{questions.length}</span>
            </div>

            <h3 className="text-xl font-medium mb-6">{currentQuestion.question}</h3>

            <div className="space-y-3 mb-8">
                {currentQuestion.options.map((option) => (
                    <button
                        key={option}
                        onClick={() => handleSelect(option)}
                        className={`w-full p-4 text-left rounded border ${answers[currentQuestion.id] === option
                            ? 'bg-blue-50 border-blue-500'
                            : 'border-gray-200 hover:bg-gray-50'
                            }`}
                    >
                        {option}
                    </button>
                ))}
            </div>

            <div className="flex justify-end">
                <Button
                    onClick={handleNext}
                    disabled={!answers[currentQuestion.id]}
                >
                    {currentIndex === questions.length - 1 ? 'Submit' : 'Next'}
                </Button>
            </div>
        </div>
    );
};
