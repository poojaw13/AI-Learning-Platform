
import { Button } from '../../components/Button';
import { toast } from 'react-toastify';

export const CareerPredictor = () => {
    return (
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h3 className="text-lg font-bold text-gray-900 mb-2">🔮 AI Career Outcome Predictor</h3>
            <p className="text-gray-600 text-sm mb-4">Based on your skill graph, here is your job market fit.</p>

            <div className="space-y-4">
                <div className="flex justify-between items-center">
                    <div>
                        <h4 className="font-bold">Junior React Developer</h4>
                        <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded">High Match (92%)</span>
                    </div>
                    <div className="text-right">
                        <p className="font-bold text-gray-900">$65k - $90k</p>
                        <span className="text-xs text-gray-500">Est. Salary</span>
                    </div>
                </div>

                <div className="flex justify-between items-center opacity-60">
                    <div>
                        <h4 className="font-bold">Senior Full Stack Engineer</h4>
                        <span className="text-xs text-yellow-600 bg-yellow-50 px-2 py-1 rounded">Low Match (24%)</span>
                    </div>
                    <div className="text-right">
                        <p className="font-bold text-gray-900">$120k+</p>
                        <span className="text-xs text-gray-500">Est. Salary</span>
                    </div>
                </div>
            </div>

            <Button variant="secondary" className="w-full mt-6" onClick={() => toast.info("Analyzing skill gaps... Mock")}>
                Generate Gap Analysis
            </Button>
        </div>
    );
};

export const CognitiveLoadMonitor = () => {
    return (
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mt-6">
            <h3 className="text-lg font-bold text-gray-900 mb-2">🧠 Cognitive Load Monitor</h3>
            <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center text-2xl">
                    😊
                </div>
                <div>
                    <p className="font-bold text-green-700">Optimal State</p>
                    <p className="text-xs text-gray-500">Your engagement is high. Keep going!</p>
                </div>
            </div>

            <div className="mt-4 bg-gray-50 p-3 rounded text-sm text-gray-600">
                <span className="font-bold block mb-1">AI Suggestion:</span>
                No breaks needed yet. You are in the flow state.
            </div>
        </div>
    );
};

export const AIResumeBuilder = () => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mt-6">
        <h3 className="text-lg font-bold text-gray-900 mb-2">📄 AI Resume Builder</h3>
        <p className="text-gray-600 text-sm mb-4">Auto-generate a resume based on your mastered skills.</p>
        <Button variant="secondary" className="w-full" onClick={() => toast.success("Resume generated (PDF)!")}>
            Export to PDF
        </Button>
    </div>
);

export const PeerLearningGroup = () => (
    <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-xl shadow-lg text-white mt-6">
        <div className="flex justify-between items-start mb-4">
            <h3 className="font-bold text-lg">👥 Peer Group</h3>
            <span className="bg-white/20 px-2 py-1 rounded text-xs">Active Now</span>
        </div>
        <div className="flex -space-x-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-yellow-200 border-2 border-indigo-500 flex items-center justify-center text-gray-800 text-xs font-bold">JD</div>
            <div className="w-8 h-8 rounded-full bg-green-200 border-2 border-indigo-500 flex items-center justify-center text-gray-800 text-xs font-bold">AS</div>
            <div className="w-8 h-8 rounded-full bg-white/20 border-2 border-indigo-500 flex items-center justify-center text-xs">+3</div>
        </div>
        <p className="text-sm opacity-90 mb-4">Your study group is discussing "Redux Middleware".</p>
        <Button size="sm" className="w-full bg-white text-indigo-600 hover:bg-gray-100">Join Discussion</Button>
    </div>
);
