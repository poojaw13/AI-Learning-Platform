
import React from 'react';

interface StatsCardProps {
    value: string | number;
    subtitle: string;
    icon: React.ElementType;
    badgeValue?: string;
    color?: string; // e.g. 'emerald', 'blue', 'purple', 'orange'
}

export const StatsCard: React.FC<StatsCardProps> = ({
    value,
    subtitle,
    icon: Icon,
    badgeValue,
    color = 'emerald'
}) => {
    // Determine gradient/colors based on prop
    interface Theme { bg: string; iconBg: string; iconColor: string; glow: string; border: string; }
    const colors: { [key: string]: Theme } = {
        emerald: { bg: 'bg-white', iconBg: 'bg-gradient-to-br from-emerald-100 to-teal-100', iconColor: 'text-emerald-600', glow: 'shadow-lg shadow-emerald-500/10 hover:shadow-emerald-500/20', border: 'border-emerald-100' },
        blue: { bg: 'bg-white', iconBg: 'bg-gradient-to-br from-blue-100 to-indigo-100', iconColor: 'text-blue-600', glow: 'shadow-lg shadow-blue-500/10 hover:shadow-blue-500/20', border: 'border-blue-100' },
        orange: { bg: 'bg-white', iconBg: 'bg-gradient-to-br from-orange-100 to-amber-100', iconColor: 'text-orange-600', glow: 'shadow-lg shadow-orange-500/10 hover:shadow-orange-500/20', border: 'border-orange-100' },
        purple: { bg: 'bg-white', iconBg: 'bg-gradient-to-br from-purple-100 to-fuchsia-100', iconColor: 'text-purple-600', glow: 'shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20', border: 'border-purple-100' }
    };

    const theme = colors[color] || colors.emerald;

    return (
        <div className={`${theme.bg} p-5 rounded-2xl border ${theme.border} ${theme.glow} transition-all duration-300 hover:-translate-y-1`}>
            {badgeValue && (
                <div className="flex justify-end mb-2">
                    <span className="text-[10px] font-bold bg-slate-50 text-slate-500 px-2 py-0.5 rounded cursor-default border border-slate-100">
                        {badgeValue}
                    </span>
                </div>
            )}
            <div className="flex items-start justify-between">
                <div>
                    <h3 className={`text-3xl font-bold text-slate-900 tracking-tight`}>
                        {value}
                    </h3>
                    <p className="text-slate-500 text-sm mt-1 font-medium">{subtitle}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${theme.iconBg} ${theme.iconColor} shadow-sm`}>
                    <Icon size={24} />
                </div>
            </div>
            {/* Mock Mini-chart/Progress bar line */}
            <div className="w-full bg-slate-100 h-1.5 mt-5 rounded-full overflow-hidden">
                <div
                    className={`h-full ${theme.iconColor.replace('text', 'bg').replace('600', '500')} transition-all duration-500`}
                    style={{ width: parseInt(value.toString().replace(/[^0-9]/g, '')) === 0 ? '0%' : '65%' }}
                ></div>
            </div>
        </div>
    );
};
