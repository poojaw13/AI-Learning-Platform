import { useState } from 'react';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const WeeklyPlanner = () => {
    const [goals, setGoals] = useState([
        { id: 1, text: 'Complete Python Basics', completed: true },
        { id: 2, text: 'Take 2 Quizzes', completed: false },
        { id: 3, text: 'Chat with AI Tutor', completed: false },
    ]);

    const toggleGoal = (id: number) => {
        setGoals(goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g));
    };

    return (
        <div className="bg-white rounded-lg shadow p-6 h-full">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-gray-900 flex items-center gap-2">
                    📅 Weekly Training Planner
                </h3>
                <span className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded-full font-bold">
                    {Math.round((goals.filter(g => g.completed).length / goals.length) * 100)}% Done
                </span>
            </div>

            <div className="flex justify-between gap-1 mb-6">
                {DAYS.map((day, i) => (
                    <div key={day} className="flex flex-col items-center">
                        <span className="text-[10px] text-gray-400 mb-1">{day}</span>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs border ${i < 2 ? 'bg-green-500 border-green-500 text-white' : 'border-gray-200 text-gray-400'
                            }`}>
                            {i < 2 ? '✓' : ''}
                        </div>
                    </div>
                ))}
            </div>

            <div className="space-y-3">
                {goals.map(goal => (
                    <div
                        key={goal.id}
                        onClick={() => toggleGoal(goal.id)}
                        className="flex items-center gap-3 cursor-pointer group"
                    >
                        <div className={`w-5 h-5 rounded border flex items-center justify-center text-[10px] transition-colors ${goal.completed ? 'bg-blue-600 border-blue-600 text-white' : 'border-gray-300 group-hover:border-blue-400'
                            }`}>
                            {goal.completed && '✓'}
                        </div>
                        <span className={`text-sm ${goal.completed ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                            {goal.text}
                        </span>
                    </div>
                ))}
            </div>

            <button className="mt-6 w-full py-2 border-2 border-dashed border-gray-200 rounded text-gray-400 text-xs hover:border-blue-300 hover:text-blue-500 transition-colors">
                + Add Custom Goal
            </button>
        </div>
    );
};
