
import {
    Radar,
    RadarChart,
    PolarGrid,
    PolarAngleAxis,
    PolarRadiusAxis,
    ResponsiveContainer,
} from 'recharts';

const data = [
    { subject: 'Python', A: 120, fullMark: 150 },
    { subject: 'React', A: 98, fullMark: 150 },
    { subject: 'SQL', A: 86, fullMark: 150 },
    { subject: 'Data Science', A: 99, fullMark: 150 },
    { subject: 'Algorithms', A: 85, fullMark: 150 },
    { subject: 'System Design', A: 65, fullMark: 150 },
];

export const SkillRadarChart = () => {
    return (
        <div style={{ width: '100%', height: '100%', minHeight: '200px' }}>
            <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
                    <PolarGrid stroke="#e5e7eb" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b7280', fontSize: 10 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 150]} tick={false} axisLine={false} />
                    <Radar
                        name="Skills"
                        dataKey="A"
                        stroke="#4f46e5"
                        strokeWidth={2}
                        fill="#6366f1"
                        fillOpacity={0.4}
                    />
                </RadarChart>
            </ResponsiveContainer>
        </div>
    );
};
