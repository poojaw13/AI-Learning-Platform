import React from 'react';
import { Outlet, Link } from 'react-router-dom';

const Layout: React.FC = () => {
    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <aside className="w-64 bg-white border-r border-gray-200 hidden md:block">
                <div className="p-6">
                    <h1 className="text-2xl font-bold text-primary">Adaptive<span className="text-gray-900">Learn</span></h1>
                </div>
                <nav className="mt-6 px-4 space-y-2">
                    <Link to="/dashboard" className="block px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-primary transition-colors">
                        Dashboard
                    </Link>
                    <Link to="/courses" className="block px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-primary transition-colors">
                        My Courses
                    </Link>
                    <Link to="/profile" className="block px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-primary transition-colors">
                        Profile
                    </Link>
                </nav>
            </aside>

            {/* Main Content */}
            <main className="flex-1">
                <header className="bg-white border-b border-gray-200 p-4 flex justify-between items-center">
                    <div className="md:hidden">Menu</div>
                    <div className="font-medium text-gray-700">Welcome back, Student</div>
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold">
                        S
                    </div>
                </header>
                <div className="p-6">
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default Layout;
