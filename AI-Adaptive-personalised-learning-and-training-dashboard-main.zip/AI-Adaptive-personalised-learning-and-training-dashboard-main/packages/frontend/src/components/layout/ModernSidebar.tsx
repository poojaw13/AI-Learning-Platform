
import { NavLink } from 'react-router-dom';
import {
    LayoutDashboard,
    BookOpen,
    BarChart2,
    Award,
    Users,
    Sparkles,
    LogOut,
    AlertCircle,
    Video,
    Trophy
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

import { useEffect, useState } from 'react';
import client from '../../api/client';

export const ModernSidebar = () => {
    const { user, logout } = useAuth();
    const [insightCount, setInsightCount] = useState(0);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                // Fetch AI Insights for badge count
                const insightsRes = await client.get('/analytics/insights');
                if (insightsRes.data) {
                    const total = (insightsRes.data.insights?.length || 0) + (insightsRes.data.performanceInsights?.length || 0);
                    setInsightCount(total);
                }
            } catch (error) {
                console.error("Failed to fetch sidebar stats:", error);
            }
        };

        if (user && user.role !== 'ADMIN' && user.role !== 'TEACHER') {
            fetchStats();
        }
    }, [user]);

    // Role-based Navigation Item Definitions
    // Role-based Navigation Item Definitions
    const studentItems = [
        { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard', badge: '' },
        { icon: Video, label: 'Live Class', path: '/student/live-classes', badge: 'Live' },
        { icon: BookOpen, label: 'My Courses', path: '/performance', badge: '' }, // Updated to match GlassSidebar behavior often used
        { icon: Trophy, label: 'Leaderboard', path: '/leaderboard', badge: '' }, // Added Leaderboard
        { icon: Award, label: 'Assessments', path: '/assessments', badge: '' },
        { icon: Sparkles, label: 'AI Insights', path: '/ai-insights', badge: insightCount > 0 ? insightCount.toString() : '' },
        { icon: BarChart2, label: 'Intelligence Console', path: '/student/intelligence', badge: 'AI' },
        { icon: Users, label: 'Community', path: '/community', badge: '' },
    ];

    const teacherItems = [
        { icon: LayoutDashboard, label: 'Teacher Dashboard', path: '/teacher', badge: '' },
        { icon: Video, label: 'Live Class', path: '/teacher/live-classes', badge: 'Live' },
        { icon: BookOpen, label: 'Course Control', path: '/admin/courses', badge: '' },
        { icon: Award, label: 'Assessments & Exams', path: '/admin/assessments', badge: '' },
        { icon: Sparkles, label: 'AI Control Center', path: '/admin/ai', badge: 'Pro' },
        { icon: BarChart2, label: 'Intelligence Console', path: '/admin/intelligence', badge: 'AI' },
        { icon: AlertCircle, label: 'Security & Integrity', path: '/admin/security', badge: '' },
        { icon: Users, label: 'Community', path: '/community', badge: '' },
    ];

    const adminItems = [
        { icon: LayoutDashboard, label: 'Control Center', path: '/admin', badge: '' },
        { icon: Users, label: 'User Management', path: '/admin/users', badge: '' },
        { icon: BookOpen, label: 'Course Control', path: '/admin/courses', badge: '' },
        { icon: Award, label: 'Assessments & Exams', path: '/admin/assessments', badge: '' },
        { icon: Sparkles, label: 'AI Control Center', path: '/admin/ai', badge: 'Pro' },
        { icon: BarChart2, label: 'Analytics & Reports', path: '/admin/analytics', badge: '' },
        { icon: AlertCircle, label: 'Security & Integrity', path: '/admin/security', badge: '' },
    ];

    // Select items based on role
    let navItems = studentItems;
    if (user?.role === 'ADMIN') {
        navItems = adminItems;
    } else if (user?.role === 'TEACHER') {
        navItems = teacherItems;
    }

    return (
        <aside className="w-64 h-screen bg-[#161b28] border-r border-gray-800 flex flex-col sticky top-0 shrink-0 z-50 shadow-2xl overflow-y-auto">
            {/* Logo */}
            <div className="p-6 flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white">
                    <span className="font-bold text-xl">A</span>
                </div>
                <div>
                    <h1 className="text-white font-black text-lg leading-none tracking-tight italic-none">AdaptiveAI</h1>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400 text-[10px] font-black uppercase tracking-widest">Mastery Hub</span>
                </div>
            </div>

            {/* User Profile Mini */}
            <div className="px-6 mb-6">
                <div className="bg-gray-800/40 p-4 rounded-2xl border border-gray-700/50 flex items-center gap-3 group hover:bg-gray-800/60 transition-all duration-300">
                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-full flex items-center justify-center text-white font-black border border-white/10 shadow-lg">
                        {user?.name?.substring(0, 2).toUpperCase() || 'DU'}
                    </div>
                    <div className="overflow-hidden">
                        <p className="text-sm font-black text-white truncate group-hover:text-emerald-400 transition-colors uppercase tracking-tight">{user?.name || 'Demo User'}</p>
                        <p className="text-[10px] text-gray-500 truncate font-mono tracking-tighter">{user?.email || 'demo@example.com'}</p>
                    </div>
                </div>
                <div className="flex gap-2 mt-2">
                    <NavLink to="/teacher/rewards" className="bg-white/50 text-[10px] font-bold px-2 py-1 rounded-lg text-emerald-700 border border-emerald-100 flex items-center gap-1 hover:bg-emerald-50 transition-colors cursor-pointer">
                        📈 Level {user?.level || 1}
                    </NavLink>
                    <NavLink to="/teachers" className="bg-white/50 text-[10px] font-bold px-2 py-1 rounded-lg text-indigo-700 border border-indigo-100 flex items-center gap-1 hover:bg-indigo-50 transition-colors cursor-pointer">
                        🏆 {user?.role === 'ADMIN' ? 'Admin' : user?.role === 'TEACHER' ? 'Teacher' : 'Student'}
                    </NavLink>
                </div>
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-4 space-y-2">
                {navItems.map((item) => (
                    <NavLink
                        key={item.path}
                        to={item.path}
                        end={item.path === '/teacher' || item.path === '/dashboard' || item.path === '/admin'}
                        className={({ isActive }) =>
                            `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group ${isActive
                                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/20'
                                : 'text-gray-400 hover:text-white hover:bg-white/5'
                            }`
                        }
                    >
                        {({ isActive }) => (
                            <>
                                <item.icon size={20} className={isActive ? 'animate-pulse' : ''} />
                                <span className="flex-1 text-sm font-medium pt-0.5">{item.label}</span>
                                {item.badge && (
                                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full shadow-sm ${isActive ? 'bg-white text-emerald-600' : 'bg-white/80 text-slate-600'
                                        } ${item.badge === 'New' && !isActive ? 'text-blue-600 bg-blue-50' : ''}`}>
                                        {item.badge}
                                    </span>
                                )}
                            </>
                        )}
                    </NavLink>
                ))}
            </nav>

            {/* Quick Actions */}
            <div className="p-6 mt-auto">

                <button onClick={logout} className="flex items-center gap-3 text-red-500 hover:text-red-700 text-sm transition-colors font-bold mt-4 pt-4 border-t border-indigo-50">
                    <LogOut size={18} /> Sign Out
                </button>
            </div>
        </aside>
    );
};
