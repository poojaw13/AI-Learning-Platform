import { Outlet } from 'react-router-dom';
import { GlassSidebar } from './GlassSidebar';
import { TopHeader } from './TopHeader';

export const MainLayout = () => {
    return (
        <div className="flex min-h-screen font-sans bg-transparent">
            {/* Sidebar with Glass Effect */}
            <GlassSidebar />

            <div className="flex-1 flex flex-col min-h-screen ml-0 transition-all duration-300">
                {/* Top Header - Sticky & Glassy */}
                <TopHeader />

                {/* Main Content Area */}
                <main className="flex-1 p-8 overflow-y-auto overflow-x-hidden">
                    <div className="max-w-7xl mx-auto w-full animate-fade-in-up">
                        <Outlet />
                    </div>
                </main>
            </div>
        </div>
    );
};
