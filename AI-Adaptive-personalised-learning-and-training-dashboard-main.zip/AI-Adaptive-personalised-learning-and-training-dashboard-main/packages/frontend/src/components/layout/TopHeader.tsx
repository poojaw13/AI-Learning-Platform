import { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search, Bell, Settings, ChevronRight, User, LogOut, Info, ShieldAlert } from 'lucide-react';
import { toast } from 'react-toastify';

export const TopHeader = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const [showNotifications, setShowNotifications] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [notifications, setNotifications] = useState([
        { id: 1, title: 'New Enrollment', message: 'John Doe joined "Advanced Python"', time: '2m ago', type: 'info', read: false },
        { id: 2, title: 'Performance Alert', message: '3 students struggling with Quiz #4', time: '1h ago', type: 'alert', read: false },
        { id: 3, title: 'AI Training Complete', message: 'Model accuracy improved to 96%', time: '3h ago', type: 'success', read: true },
    ]);

    const notificationRef = useRef<HTMLDivElement>(null);
    const settingsRef = useRef<HTMLDivElement>(null);

    // Close dropdowns on click outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
                setShowNotifications(false);
            }
            if (settingsRef.current && !settingsRef.current.contains(event.target as Node)) {
                setShowSettings(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const markAllRead = () => {
        setNotifications(notifications.map(n => ({ ...n, read: true })));
        toast.success("All notifications marked as read");
    };

    const handleLogout = () => {
        localStorage.clear();
        sessionStorage.clear();
        navigate('/login');
        toast.info("Signed out successfully");
    };

    // Mapping optimized for readability
    const getPageTitle = (path: string) => {
        if (path === '/dashboard') return 'Dashboard';
        if (path.includes('/admin/users')) return 'User Management';
        if (path.includes('/admin/courses')) return 'Course Control';
        if (path.includes('/admin/assessments')) return 'Assessment Manager';
        if (path.includes('/admin/ai/decisions')) return 'AI Decision Logs';
        if (path.includes('/admin/ai/config')) return 'Model Configuration';
        if (path.includes('/admin/ai/test')) return 'Model Diagnostics';
        if (path.includes('/admin/ai')) return 'AI Control Center';
        if (path.includes('/admin/analytics')) return 'Analytics & Reports';
        if (path.includes('/admin/security')) return 'Security & Integrity';
        if (path.includes('/admin/intelligence')) return 'Intelligence Console';
        if (path.includes('/admin/settings')) return 'System Settings';
        if (path.includes('/teacher')) return 'Teacher Dashboard';
        if (path.includes('/student/live-classes')) return 'Live Classes';
        if (path.includes('/performance')) return 'My Courses';
        if (path.includes('/leaderboard')) return 'Leaderboard';
        if (path.includes('/assessments')) return 'Assessments';
        if (path.includes('/ai-insights')) return 'AI Insights';
        if (path.includes('/student/intelligence')) return 'Intelligence Console';
        if (path.includes('/community')) return 'Community';
        if (path.includes('/courses/')) return 'Course Details';
        return 'Dashboard';
    };

    const currentTitle = getPageTitle(location.pathname);
    const unreadCount = notifications.filter(n => !n.read).length;

    return (
        <div className="h-20 px-8 flex items-center justify-between sticky top-0 z-40 transition-all duration-300 backdrop-blur-sm bg-space-950/30 border-b border-white/5">
            {/* Breadcrumb / Page Title */}
            <div className="flex items-center gap-2 text-sm font-medium">
                <span className="text-gray-500">Platform</span>
                <ChevronRight size={14} className="text-gray-600" />
                <span className="text-white font-bold tracking-wide text-lg neon-text-subtle">{currentTitle}</span>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-4">
                {/* Search */}
                <div className="relative group hidden md:block">
                    <Search className="absolute left-3 top-2.5 text-gray-500 group-focus-within:text-neon-blue transition-colors" size={18} />
                    <input
                        type="text"
                        placeholder="Search..."
                        className="glass-input pl-10 pr-4 py-2 w-64 focus:w-80 transition-all"
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                                const query = (e.currentTarget as HTMLInputElement).value;
                                if (query.trim()) {
                                    toast.info(`Searching platform for "${query}"...`);
                                }
                            }
                        }}
                    />
                </div>

                {/* Notifications */}
                <div className="relative" ref={notificationRef}>
                    <button
                        onClick={() => {
                            setShowNotifications(!showNotifications);
                            setShowSettings(false);
                        }}
                        className={`relative p-2 rounded-full hover:bg-white/10 transition-colors border ${showNotifications ? 'bg-white/10 border-white/20 text-white' : 'text-gray-400 border-transparent hover:border-white/5'}`}
                    >
                        <Bell size={20} />
                        {unreadCount > 0 && (
                            <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-neon-pink rounded-full border-2 border-space-950 animate-pulse"></span>
                        )}
                    </button>

                    {showNotifications && (
                        <div className="absolute top-full right-0 mt-3 w-80 glass-card p-0 overflow-hidden animate-slide-up shadow-2xl z-50 border-white/10">
                            <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                                <h3 className="text-sm font-bold text-white">Notifications</h3>
                                <button
                                    onClick={markAllRead}
                                    className="text-[10px] uppercase tracking-widest font-bold text-neon-blue hover:text-white transition-colors"
                                >
                                    Mark all as read
                                </button>
                            </div>
                            <div className="max-h-96 overflow-y-auto">
                                {notifications.length > 0 ? (
                                    notifications.map((n) => (
                                        <div key={n.id} className={`p-4 border-b border-white/5 hover:bg-white/5 transition-colors cursor-pointer group ${!n.read ? 'bg-neon-blue/5' : ''}`}>
                                            <div className="flex gap-3">
                                                <div className={`mt-1 p-1.5 rounded-lg ${n.type === 'alert' ? 'bg-red-500/20 text-red-400' : 'bg-neon-blue/20 text-neon-blue'}`}>
                                                    {n.type === 'alert' ? <ShieldAlert size={14} /> : <Info size={14} />}
                                                </div>
                                                <div className="flex-1">
                                                    <div className="flex justify-between items-start">
                                                        <h4 className={`text-xs font-bold ${n.read ? 'text-gray-300' : 'text-white'}`}>{n.title}</h4>
                                                        <span className="text-[10px] text-gray-500 font-medium">{n.time}</span>
                                                    </div>
                                                    <p className="text-xs text-gray-400 mt-1 leading-relaxed">{n.message}</p>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="p-8 text-center">
                                        <Bell size={32} className="mx-auto text-gray-700 mb-2 opacity-20" />
                                        <p className="text-sm text-gray-500 italic">No new notifications</p>
                                    </div>
                                )}
                            </div>
                            <div className="p-3 text-center bg-white/5">
                                <button className="text-[10px] font-bold text-gray-400 hover:text-white transition-colors uppercase tracking-widest">
                                    View All Activity
                                </button>
                            </div>
                        </div>
                    )}
                </div>

                {/* Settings Dropdown */}
                <div className="relative" ref={settingsRef}>
                    <button
                        onClick={() => {
                            setShowSettings(!showSettings);
                            setShowNotifications(false);
                        }}
                        className={`p-2 rounded-full hover:bg-white/10 transition-colors border ${showSettings ? 'bg-white/10 border-white/20 text-white' : 'text-gray-400 border-transparent hover:border-white/5'}`}
                    >
                        <Settings size={20} />
                    </button>

                    {showSettings && (
                        <div className="absolute top-full right-0 mt-3 w-56 glass-card p-2 animate-slide-up shadow-2xl z-50 border-white/10">
                            <div className="px-3 py-2 border-b border-white/10 mb-2">
                                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Signed in as</p>
                                <p className="text-xs font-bold text-white truncate">Administrator</p>
                            </div>

                            <button
                                onClick={() => { navigate('/admin/settings'); setShowSettings(false); }}
                                className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-300 hover:bg-white/10 hover:text-white transition-all group"
                            >
                                <User size={16} className="text-gray-500 group-hover:text-neon-blue" />
                                My Profile
                            </button>

                            <button
                                onClick={() => { navigate('/admin/security'); setShowSettings(false); }}
                                className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-300 hover:bg-white/10 hover:text-white transition-all group"
                            >
                                <Settings size={16} className="text-gray-500 group-hover:text-neon-blue" />
                                System Settings
                            </button>

                            <div className="h-px bg-white/10 my-2 mx-1"></div>

                            <button
                                onClick={handleLogout}
                                className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-red-400 hover:bg-red-500/10 transition-all group"
                            >
                                <LogOut size={16} />
                                Sign Out
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
