import { useRef, useState, useEffect, useCallback } from 'react';
import Webcam from 'react-webcam';
import client from '../../api/client';
import { toast } from 'react-toastify';

export const EmotionMonitor = () => {
    const webcamRef = useRef<Webcam>(null);
    const [emotion, setEmotion] = useState<string | null>(null);
    const [isEnabled, setIsEnabled] = useState(false);
    const [isCapturing] = useState(false);

    const capture = useCallback(async () => {
        if (webcamRef.current) {
            const imageSrc = webcamRef.current.getScreenshot();
            if (imageSrc) {
                try {
                    const { data } = await client.post('/courses/emotion', { image: imageSrc });
                    setEmotion(data.emotion);

                    // Logic: If user is "Bored" or "Confused", maybe show a helpful toast or tip
                    if (data.emotion === 'Confused') {
                        toast.info("Need help? You can ask the AI Tutor for clarification!", { autoClose: 3000 });
                    }
                } catch (error) {
                    console.error("Emotion analysis failed", error);
                }
            }
        }
    }, [webcamRef]);

    useEffect(() => {
        let interval: ReturnType<typeof setInterval> | undefined;
        if (isEnabled && !isCapturing) {
            interval = setInterval(() => {
                capture();
            }, 15000); // Check every 15 seconds
        }
        return () => clearInterval(interval);
    }, [isEnabled, isCapturing, capture]);

    if (!isEnabled) {
        return (
            <div className="fixed bottom-24 right-6 transition-all">
                <button
                    onClick={() => setIsEnabled(true)}
                    className="bg-gray-800 text-white p-2 rounded-full shadow-lg hover:bg-gray-700 text-xs flex items-center gap-2"
                    title="Enable AI Emotion Monitoring"
                >
                    📷 Enable Focus Monitor
                </button>
            </div>
        );
    }

    return (
        <div className="fixed bottom-24 right-6 w-40 bg-white rounded-lg shadow-xl overflow-hidden border border-gray-200 z-40">
            <div className="bg-gray-800 p-2 text-white text-[10px] flex justify-between items-center">
                <span>AI Focus Monitor</span>
                <button onClick={() => setIsEnabled(false)} className="hover:text-red-400">✕</button>
            </div>
            <div className="relative">
                <Webcam
                    audio={false}
                    ref={webcamRef}
                    screenshotFormat="image/jpeg"
                    className="w-full grayscale opacity-50"
                    videoConstraints={{ width: 160, height: 120, facingMode: "user" }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                    {emotion && (
                        <div className="bg-black/50 text-white px-2 py-1 rounded text-[10px] font-bold">
                            Emotion: {emotion}
                        </div>
                    )}
                </div>
            </div>
            <div className="p-2 text-[10px] text-gray-500 bg-gray-50 flex items-center gap-1">
                <div className={`w-1.5 h-1.5 rounded-full ${emotion === 'Focused' ? 'bg-green-500' : 'bg-yellow-500 font-bold'}`}></div>
                {emotion ? `Detected: ${emotion}` : 'Analyzing...'}
            </div>
        </div>
    );
};
