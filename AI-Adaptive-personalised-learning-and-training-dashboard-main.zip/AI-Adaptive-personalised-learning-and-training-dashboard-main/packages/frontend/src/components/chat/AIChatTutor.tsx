import { useState, useRef, useEffect } from 'react';
import { Button } from '../Button';
import client from '../../api/client'; // Note: Frontend calls Backend, which proxies to AI usually, but for speed let's proxy through backend or direct?
// Let's create a backend proxy for chat to avoid CORS if AI is on different port locally (though enabling CORS on AI solves it).
// Best practice: Frontend -> Backend -> AI Service.

interface Message {
    id: string;
    text: string;
    sender: 'user' | 'bot';
}

export const AIChatTutor = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([
        { id: '1', text: 'Hi! I am your AI Tutor. Ask me anything!', sender: 'bot' }
    ]);
    const [input, setInput] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const bottomRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim()) return;

        const userMsg: Message = { id: Date.now().toString(), text: input, sender: 'user' };
        setMessages(prev => [...prev, userMsg]);
        setInput("");
        setIsLoading(true);

        try {
            // We need a backend proxy for this. Let's assume /api/chat exists or call logic here.
            // For now, let's call the AI service directly or via a new backend route.
            // Let's quickly add a backend route.
            const { data } = await client.post('/courses/chat', { message: userMsg.text });

            const botMsg: Message = { id: (Date.now() + 1).toString(), text: data.reply, sender: 'bot' };
            setMessages(prev => [...prev, botMsg]);
        } catch {
            setMessages(prev => [...prev, { id: Date.now().toString(), text: "Sorry, I'm having trouble connecting.", sender: 'bot' }]);
        } finally {
            setIsLoading(false);
        }
    };

    if (!isOpen) {
        return (
            <button
                onClick={() => setIsOpen(true)}
                className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg flex items-center justify-center text-2xl transition-transform hover:scale-110 z-50"
            >
                🤖
            </button>
        );
    }

    return (
        <div className="fixed bottom-6 right-6 w-80 h-96 bg-white rounded-lg shadow-xl flex flex-col border border-gray-200 z-50 overflow-hidden animate-fade-in-up">
            <div className="bg-blue-600 p-4 flex justify-between items-center text-white">
                <h3 className="font-bold flex items-center gap-2">🤖 AI Tutor</h3>
                <button onClick={() => setIsOpen(false)} className="hover:bg-blue-700 rounded p-1">✕</button>
            </div>

            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-gray-50">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-3 rounded-lg text-sm ${msg.sender === 'user'
                            ? 'bg-blue-600 text-white rounded-br-none'
                            : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-sm'
                            }`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                {isLoading && (
                    <div className="flex justify-start">
                        <div className="bg-white border border-gray-200 p-3 rounded-lg rounded-bl-none shadow-sm text-sm text-gray-400">
                            Thinking...
                        </div>
                    </div>
                )}
                <div ref={bottomRef} />
            </div>

            <div className="p-3 bg-white border-t flex gap-2">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask a question..."
                    className="flex-1 border rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                />
                <Button size="sm" onClick={handleSend} disabled={isLoading}>Send</Button>
            </div>
        </div>
    );
};
